import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";

export const ventureAnalysesTable = pgTable("venture_analyses", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  resultsJson: jsonb("results_json").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type VentureAnalysis = typeof ventureAnalysesTable.$inferSelect;
export type InsertVentureAnalysis = typeof ventureAnalysesTable.$inferInsert;
