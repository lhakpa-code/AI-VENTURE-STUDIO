import { pgTable, text, serial, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { businessesTable } from "./businesses";

export const assessmentsTable = pgTable("assessments", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id, { onDelete: "cascade" }),
  status: text("status").notNull().default("pending"), // pending, completed, failed
  identitySummary: text("identity_summary"),
  strengths: text("strengths").array().notNull().default([]),
  weaknesses: text("weaknesses").array().notNull().default([]),
  opportunities: text("opportunities").array().notNull().default([]),
  threats: text("threats").array().notNull().default([]),
  strengthScore: real("strength_score"),
  weaknessScore: real("weakness_score"),
  opportunityScore: real("opportunity_score"),
  threatScore: real("threat_score"),
  recommendations: text("recommendations").array().notNull().default([]),
  additionalContext: text("additional_context"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertAssessmentSchema = createInsertSchema(assessmentsTable).omit({ id: true, createdAt: true });
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;
export type Assessment = typeof assessmentsTable.$inferSelect;
