import { pgTable, text, serial, timestamp, jsonb } from "drizzle-orm/pg-core";

export const reportsTable = pgTable("reports", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  dataQuality: text("data_quality").notNull(),
  reportJson: jsonb("report_json").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Report = typeof reportsTable.$inferSelect;
export type InsertReport = typeof reportsTable.$inferInsert;
