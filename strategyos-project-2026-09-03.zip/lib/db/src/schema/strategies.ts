import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { businessesTable } from "./businesses";
import { assessmentsTable } from "./assessments";

export const strategiesTable = pgTable("strategies", {
  id: serial("id").primaryKey(),
  businessId: integer("business_id").notNull().references(() => businessesTable.id, { onDelete: "cascade" }),
  assessmentId: integer("assessment_id").references(() => assessmentsTable.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  overview: text("overview"),
  status: text("status").notNull().default("generating"), // generating, active, archived
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const strategyPillarsTable = pgTable("strategy_pillars", {
  id: serial("id").primaryKey(),
  strategyId: integer("strategy_id").notNull().references(() => strategiesTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  priority: integer("priority").notNull().default(1),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const milestonesTable = pgTable("milestones", {
  id: serial("id").primaryKey(),
  pillarId: integer("pillar_id").notNull().references(() => strategyPillarsTable.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  description: text("description"),
  kpi: text("kpi"),           // Key Performance Indicator (e.g. "Monthly Recurring Revenue")
  target: text("target"),     // Specific target (e.g. "$50,000 MRR")
  timeframe: text("timeframe"),
  status: text("status").notNull().default("not_started"), // not_started, in_progress, completed
  order: integer("order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const kpiLogsTable = pgTable("kpi_logs", {
  id: serial("id").primaryKey(),
  milestoneId: integer("milestone_id").notNull().references(() => milestonesTable.id, { onDelete: "cascade" }),
  actualValue: text("actual_value").notNull(),
  note: text("note"),
  loggedAt: timestamp("logged_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertStrategySchema = createInsertSchema(strategiesTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertStrategyPillarSchema = createInsertSchema(strategyPillarsTable).omit({ id: true, createdAt: true });
export const insertMilestoneSchema = createInsertSchema(milestonesTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertKpiLogSchema = createInsertSchema(kpiLogsTable).omit({ id: true, loggedAt: true });

export type InsertStrategy = z.infer<typeof insertStrategySchema>;
export type Strategy = typeof strategiesTable.$inferSelect;
export type StrategyPillar = typeof strategyPillarsTable.$inferSelect;
export type Milestone = typeof milestonesTable.$inferSelect;
export type KpiLog = typeof kpiLogsTable.$inferSelect;
