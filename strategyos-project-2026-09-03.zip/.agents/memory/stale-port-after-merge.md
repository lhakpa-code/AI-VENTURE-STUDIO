---
name: Stale port after task merges
description: EADDRINUSE on the API server after task-agent merges
---
Rule: if the API server workflow fails with EADDRINUSE right after a task merge, a stale server process is still holding the port. Kill it (`fuser -k <port>/tcp`) and restart the workflow.

**Why:** task-agent merges restart workflows, and the old build/start process sometimes survives, keeping the port bound.

**How to apply:** after any merge notification, if the API workflow is FAILED, check for a stale listener before debugging code.
