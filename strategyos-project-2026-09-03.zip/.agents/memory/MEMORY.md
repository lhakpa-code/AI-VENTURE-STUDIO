# Memory Index

- [AI JSON output rendering](ai-json-rendering.md) — LLM JSON fields can come back as objects where strings are expected; render defensively and pin field types in prompts.
- [Stale port after task merges](stale-port-after-merge.md) — task-agent merges can leave a stale api-server process holding the port; kill it before restarting the workflow.
