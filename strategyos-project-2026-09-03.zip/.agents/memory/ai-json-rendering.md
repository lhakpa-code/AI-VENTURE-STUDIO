---
name: AI JSON output rendering
description: Preventing React crashes from LLM JSON fields that vary in shape
---
Rule: never render an AI-generated JSON field directly as a React child; coerce it through a string-normalizing helper (see `asText` in the Venture Studio page), and state explicitly in the prompt that fields must be plain strings ("NOT an object").

**Why:** gpt-4o json_object mode sometimes returns nested objects (e.g. pricing tiers as `{free_tier, premium_tier, ...}`) where a sentence was expected, crashing React with "Objects are not valid as a React child". Saved analyses persist the bad shape, so a prompt fix alone doesn't heal old data.

**How to apply:** any new UI that renders AI response fields — wrap free-text fields in the normalizer and tighten the generating prompt's schema description.
