import { Link, useLocation } from "wouter";
import { Briefcase, LayoutDashboard, Plus, Settings } from "lucide-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      <aside className="w-64 border-r border-border/50 bg-card/30 flex flex-col backdrop-blur-xl">
        <div className="p-6">
          <Link href="/" className="flex items-center gap-2 font-bold text-xl tracking-tight text-white">
            <div className="w-8 h-8 rounded bg-primary flex items-center justify-center text-primary-foreground shadow-[0_0_15px_rgba(93,46,232,0.5)]">
              <Briefcase size={18} />
            </div>
            StrategyOS
          </Link>
        </div>

        <nav className="flex-1 px-4 space-y-2 mt-4">
          <Link
            href="/"
            className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-all ${
              location === "/" || location.startsWith("/businesses") || location.startsWith("/assessments") || location.startsWith("/strategies")
                ? "bg-primary/10 text-primary font-medium"
                : "text-muted-foreground hover:text-foreground hover:bg-white/5"
            }`}
          >
            <LayoutDashboard size={18} />
            Businesses
          </Link>
          <Link
            href="/businesses/new"
            className={`flex items-center gap-3 px-3 py-2.5 rounded-md transition-all ${
              location === "/businesses/new"
                ? "bg-primary/10 text-primary font-medium"
                : "text-muted-foreground hover:text-foreground hover:bg-white/5"
            }`}
          >
            <Plus size={18} />
            New Business
          </Link>
        </nav>

        <div className="p-4 border-t border-border/50">
          <button className="flex items-center gap-3 px-3 py-2.5 rounded-md text-muted-foreground hover:text-foreground hover:bg-white/5 w-full transition-all">
            <Settings size={18} />
            Settings
          </button>
        </div>
      </aside>

      <main className="flex-1 overflow-auto relative">
        {children}
      </main>
    </div>
  );
}
