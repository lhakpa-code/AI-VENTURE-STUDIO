import {
  BrainCircuit, ArrowLeft, Shield, AlertTriangle, TrendingUp,
  Zap, Target, AlertOctagon, Lightbulb, CalendarDays, ChevronRight,
  Info, Clock, History,
} from "lucide-react";
import { useLocation } from "wouter";
import type { FullReport } from "../types/report";
import { SourcesPanel } from "./SourcesPanel";

// ─── Section header helper ─────────────────────────────────────────────────────

function BarChartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M9 21V9" />
    </svg>
  );
}

const SECTION_COLORS: Record<string, string> = {
  violet:  "text-violet-400 bg-violet-500/10 border-violet-500/20",
  red:     "text-red-400    bg-red-500/10    border-red-500/20",
  blue:    "text-blue-400   bg-blue-500/10   border-blue-500/20",
  emerald: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  white:   "text-white/70   bg-white/5       border-white/10",
};

function SectionHeader({ icon: Icon, label, color }: { icon: React.ElementType; label: string; color: string }) {
  const cls = SECTION_COLORS[color] ?? SECTION_COLORS.white;
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className={`w-8 h-8 rounded-lg border flex items-center justify-center ${cls}`}>
        <Icon className="w-4 h-4" />
      </div>
      <h2 className="text-lg font-bold text-white">{label}</h2>
    </div>
  );
}

// ─── SWOT Grid ─────────────────────────────────────────────────────────────────

const QUADRANT_CFG = {
  strengths:     { label: "Strengths",     letter: "S", Icon: Shield,        border: "border-emerald-500/25", headerBg: "bg-emerald-500/8",  dotColor: "bg-emerald-400", titleColor: "text-emerald-300",  sigColor: "text-emerald-400/70",  sigBg: "bg-emerald-500/5 border-emerald-500/15",  desc: "Internal advantages" },
  weaknesses:    { label: "Weaknesses",    letter: "W", Icon: AlertTriangle,  border: "border-amber-500/25",   headerBg: "bg-amber-500/8",    dotColor: "bg-amber-400",   titleColor: "text-amber-300",    sigColor: "text-amber-400/70",    sigBg: "bg-amber-500/5 border-amber-500/15",    desc: "Internal vulnerabilities" },
  opportunities: { label: "Opportunities", letter: "O", Icon: TrendingUp,    border: "border-blue-500/25",    headerBg: "bg-blue-500/8",     dotColor: "bg-blue-400",    titleColor: "text-blue-300",     sigColor: "text-blue-400/70",     sigBg: "bg-blue-500/5 border-blue-500/15",     desc: "External tailwinds" },
  threats:       { label: "Threats",       letter: "T", Icon: Zap,           border: "border-red-500/25",     headerBg: "bg-red-500/8",      dotColor: "bg-red-400",     titleColor: "text-red-300",      sigColor: "text-red-400/70",      sigBg: "bg-red-500/5 border-red-500/15",       desc: "External pressures" },
} as const;

function SwotGrid({ swot }: { swot: FullReport["swot"] }) {
  const keys = ["strengths", "weaknesses", "opportunities", "threats"] as const;
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
      {keys.map((key) => {
        const cfg = QUADRANT_CFG[key];
        const items = swot[key] ?? [];
        const Icon = cfg.Icon;
        return (
          <div key={key} className={`bg-white/[0.02] border ${cfg.border} rounded-2xl overflow-hidden`}>
            <div className={`${cfg.headerBg} border-b ${cfg.border} px-5 py-4 flex items-center gap-3`}>
              <div className={`w-9 h-9 rounded-xl bg-white/5 border ${cfg.border} flex items-center justify-center`}>
                <Icon className={`w-4 h-4 ${cfg.titleColor}`} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className={`text-xl font-black ${cfg.titleColor}`}>{cfg.letter}</span>
                  <span className="text-white font-bold">{cfg.label}</span>
                </div>
                <p className="text-white/35 text-xs">{cfg.desc}</p>
              </div>
            </div>
            <div className="p-5 space-y-6">
              {items.map((item, i) => (
                <div key={i}>
                  <div className="flex gap-2.5 mb-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full mt-2 shrink-0 ${cfg.dotColor}`} />
                    <p className={`text-sm font-bold leading-snug ${cfg.titleColor}`}>{item.title}</p>
                  </div>
                  <p className="text-white/55 text-sm leading-relaxed pl-4 mb-2">{item.detail}</p>
                  {item.strategicSignificance && (
                    <div className={`ml-4 rounded-lg border px-3 py-2 ${cfg.sigBg}`}>
                      <p className={`text-xs font-semibold uppercase tracking-wider mb-0.5 ${cfg.sigColor}`}>Why it matters</p>
                      <p className="text-white/50 text-xs leading-relaxed">{item.strategicSignificance}</p>
                    </div>
                  )}
                  {i < items.length - 1 && <div className="mt-5 border-t border-white/[0.05]" />}
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── ResultView ────────────────────────────────────────────────────────────────

export function ResultView({
  report,
  onNew,
  savedId,
}: {
  report: FullReport;
  onNew: () => void;
  savedId?: number | null;
}) {
  const [, navigate] = useLocation();

  const IMPACT_COLORS: Record<string, string> = {
    High:   "bg-red-500/15 text-red-300 border-red-500/25",
    Medium: "bg-amber-500/15 text-amber-300 border-amber-500/25",
    Low:    "bg-emerald-500/15 text-emerald-300 border-emerald-500/25",
  };
  const TIMEFRAME_COLORS: Record<string, string> = {
    "Immediate (0-6 months)":   "bg-violet-500/15 text-violet-300 border-violet-500/25",
    "Near-term (6-18 months)":  "bg-blue-500/15 text-blue-300 border-blue-500/25",
    "Long-term (18+ months)":   "bg-slate-500/15 text-slate-300 border-slate-500/25",
  };
  const PHASE_COLORS = [
    { bg: "bg-violet-500/10",  border: "border-violet-500/25",  text: "text-violet-300",  num: "bg-violet-500/20 text-violet-300"  },
    { bg: "bg-blue-500/10",    border: "border-blue-500/25",    text: "text-blue-300",    num: "bg-blue-500/20 text-blue-300"    },
    { bg: "bg-emerald-500/10", border: "border-emerald-500/25", text: "text-emerald-300", num: "bg-emerald-500/20 text-emerald-300" },
  ];

  const qualityConfig: Record<string, { label: string; color: string }> = {
    sufficient:   { label: "Research Complete",   color: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
    partial:      { label: "Partial Research",    color: "bg-amber-500/15 text-amber-300 border-amber-500/30" },
    insufficient: { label: "Limited Public Data", color: "bg-red-500/15 text-red-300 border-red-500/30" },
  };
  const qcfg = qualityConfig[report.dataQuality] ?? qualityConfig.partial;

  const priorities = report.strategicPriorities ?? [];
  const risks = report.majorRisks ?? [];
  const opportunities = report.keyOpportunities ?? [];
  const actionPlan = report.actionPlan90Days ?? [];

  return (
    <main className="flex-1 px-4 md:px-8 py-10 w-full max-w-6xl mx-auto space-y-10">

      {/* ── Header ──────────────────────────────────────────────────────────── */}
      <div>
        <button onClick={onNew} className="flex items-center gap-1.5 text-white/35 hover:text-white/65 text-sm mb-5 transition-colors">
          <ArrowLeft className="w-4 h-4" />
          New analysis
        </button>
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold text-white tracking-tight mb-3">{report.companyName}</h1>
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-xs font-semibold rounded-full px-3 py-1 border ${qcfg.color}`}>
                {qcfg.label}
              </span>
              <span className="text-xs font-medium bg-violet-500/8 border border-violet-500/15 text-violet-400/70 rounded-full px-3 py-1">
                3-Agent Pipeline
              </span>
              {report.dataNote && (
                <span className="text-xs text-white/35 flex items-center gap-1">
                  <Info className="w-3 h-3" />
                  {report.dataNote}
                </span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            {savedId != null && (
              <button
                onClick={() => navigate("/history")}
                className="flex items-center gap-2 bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/30 text-emerald-300 font-semibold rounded-xl px-4 py-2.5 text-sm transition-all"
              >
                <History className="w-4 h-4" />
                Saved — view history
              </button>
            )}
            <button onClick={onNew} className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all">
              <BrainCircuit className="w-4 h-4" />
              Analyse another
            </button>
          </div>
        </div>
      </div>

      {/* ── Executive Summary ────────────────────────────────────────────────── */}
      {report.executiveSummary && (
        <section>
          <SectionHeader icon={BrainCircuit} label="Executive Summary" color="violet" />
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-7">
            {report.executiveSummary.split("\n\n").filter(Boolean).map((para, i) => (
              <p key={i} className={`text-white/70 leading-relaxed ${i > 0 ? "mt-4" : ""}`}>{para}</p>
            ))}
          </div>
        </section>
      )}

      {/* ── SWOT ─────────────────────────────────────────────────────────────── */}
      {report.swot && (
        <section>
          <SectionHeader icon={BarChartIcon} label="SWOT Analysis" color="white" />
          <SwotGrid swot={report.swot} />
        </section>
      )}

      {/* ── Strategic Priorities ─────────────────────────────────────────────── */}
      {priorities.length > 0 && (
        <section>
          <SectionHeader icon={Target} label="Top 3 Strategic Priorities" color="violet" />
          <div className="space-y-4">
            {priorities.map((p, i) => (
              <div key={i} className="bg-white/[0.02] border border-white/10 rounded-2xl p-6 flex gap-5">
                <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/25 flex items-center justify-center shrink-0 text-violet-300 font-bold text-lg">
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-white font-bold mb-1.5">{p.title}</h3>
                  <p className="text-white/55 text-sm leading-relaxed mb-3">{p.rationale}</p>
                  <div className="flex items-start gap-2 bg-violet-500/8 border border-violet-500/15 rounded-xl px-4 py-3">
                    <ChevronRight className="w-4 h-4 text-violet-400 mt-0.5 shrink-0" />
                    <p className="text-violet-200/70 text-sm leading-relaxed">{p.keyAction}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ── Risks + Opportunities ────────────────────────────────────────────── */}
      {(risks.length > 0 || opportunities.length > 0) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {risks.length > 0 && (
            <section>
              <SectionHeader icon={AlertOctagon} label="Major Risks" color="red" />
              <div className="space-y-3">
                {risks.map((r, i) => (
                  <div key={i} className="bg-white/[0.02] border border-white/10 rounded-xl p-5">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <h4 className="text-white font-semibold text-sm leading-snug">{r.title}</h4>
                      <span className={`text-xs font-bold rounded-full px-2.5 py-0.5 border shrink-0 ${IMPACT_COLORS[r.impact] ?? IMPACT_COLORS.Medium}`}>
                        {r.impact}
                      </span>
                    </div>
                    <p className="text-white/50 text-sm leading-relaxed mb-3">{r.description}</p>
                    <div className="flex items-start gap-2 bg-white/[0.03] rounded-lg px-3 py-2">
                      <Shield className="w-3.5 h-3.5 text-white/30 mt-0.5 shrink-0" />
                      <p className="text-white/40 text-xs leading-relaxed">{r.mitigation}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}

          {opportunities.length > 0 && (
            <section>
              <SectionHeader icon={Lightbulb} label="Key Opportunities" color="blue" />
              <div className="space-y-3">
                {opportunities.map((o, i) => (
                  <div key={i} className="bg-white/[0.02] border border-white/10 rounded-xl p-5">
                    <div className="flex items-start justify-between gap-3 mb-2">
                      <h4 className="text-white font-semibold text-sm leading-snug">{o.title}</h4>
                      <span className={`text-xs font-semibold rounded-full px-2.5 py-0.5 border shrink-0 whitespace-nowrap ${TIMEFRAME_COLORS[o.timeframe] ?? "bg-blue-500/15 text-blue-300 border-blue-500/25"}`}>
                        {o.timeframe?.replace(" (0-6 months)", "")?.replace(" (6-18 months)", "")?.replace(" (18+ months)", "") ?? o.timeframe}
                      </span>
                    </div>
                    <p className="text-white/50 text-sm leading-relaxed mb-3">{o.description}</p>
                    <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/10 rounded-lg px-3 py-2">
                      <TrendingUp className="w-3.5 h-3.5 text-blue-400/60 mt-0.5 shrink-0" />
                      <p className="text-white/40 text-xs leading-relaxed">{o.advantage}</p>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      )}

      {/* ── 90-Day Action Plan ───────────────────────────────────────────────── */}
      {actionPlan.length > 0 && (
        <section>
          <SectionHeader icon={CalendarDays} label="90-Day Action Plan" color="emerald" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {actionPlan.map((phase, i) => {
              const pc = PHASE_COLORS[i] ?? PHASE_COLORS[0];
              return (
                <div key={i} className={`${pc.bg} border ${pc.border} rounded-2xl p-6`}>
                  <div className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold mb-4 ${pc.num}`}>
                    <Clock className="w-3 h-3" />
                    {phase.phase}
                  </div>
                  <h3 className={`font-bold text-base mb-4 ${pc.text}`}>{phase.focus}</h3>
                  <ul className="space-y-2.5 mb-5">
                    {(phase.actions ?? []).map((action, j) => (
                      <li key={j} className="flex items-start gap-2">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${pc.num}`}>
                          {j + 1}
                        </div>
                        <span className="text-white/60 text-sm leading-relaxed">{action}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="border-t border-white/10 pt-4">
                    <p className="text-xs font-semibold text-white/35 uppercase tracking-wider mb-1.5">Milestone</p>
                    <p className="text-white/60 text-sm leading-relaxed">{phase.milestone}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* ── Evidence & Sources ───────────────────────────────────────────────── */}
      {report.sources && (
        <section>
          <SourcesPanel sources={report.sources} />
        </section>
      )}

      {/* ── CTA ──────────────────────────────────────────────────────────────── */}
      <div className="bg-gradient-to-r from-violet-600/10 to-blue-600/10 border border-violet-500/20 rounded-2xl p-8 text-center">
        <h3 className="text-xl font-bold text-white mb-2">Analyse another company</h3>
        <p className="text-white/40 text-sm mb-5">Generate a strategic intelligence report on any company, startup, or organisation.</p>
        <button onClick={onNew} className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl px-6 py-3 text-sm transition-all mx-auto">
          <BrainCircuit className="w-4 h-4" />
          New analysis
        </button>
      </div>
    </main>
  );
}
