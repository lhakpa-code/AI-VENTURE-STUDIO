import { useLocation } from "wouter";
import { Lightbulb, BarChart3, Layout, Compass, MessageCircle } from "lucide-react";

const TABS = [
  { id: "v1", label: "Idea Strategy Generator", icon: Lightbulb, path: "/" },
  { id: "v2", label: "Financials & Competitor Analysis", icon: BarChart3, path: "/swot" },
  { id: "v3", label: "Landing Page Generator", icon: Layout, path: "/swot", hash: "#landing-page" },
  { id: "v4", label: "Startup Architect", icon: Compass, path: "/architect" },
  { id: "v5", label: "Founder Chat", icon: MessageCircle, path: "/founder-chat", isNew: true },
] as const;

export default function VersionNav() {
  const [location, navigate] = useLocation();

  const activeId = (() => {
    if (location.startsWith("/founder-chat")) return "v5";
    if (location.startsWith("/architect")) return "v4";
    if (location.startsWith("/swot") || location.startsWith("/report")) {
      return typeof window !== "undefined" && window.location.hash === "#landing-page" ? "v3" : "v2";
    }
    return "v1";
  })();

  const handleClick = (tab: (typeof TABS)[number]) => {
    const hash = "hash" in tab ? tab.hash : "";
    const onSwot = location.startsWith("/swot");

    if (hash) {
      // v3: the landing generator lives inside a generated report on /swot.
      if (onSwot) {
        window.location.hash = hash;
        document.getElementById("landing-page")?.scrollIntoView({ behavior: "smooth" });
      } else {
        // No live report — send the user to start an analysis (report includes the generator).
        navigate("/");
      }
      return;
    }
    if (location === tab.path || (tab.path !== "/" && location.startsWith(tab.path))) return;
    navigate(tab.path);
  };

  return (
    <nav className="border-b border-white/[0.06] bg-[#080810]/90 backdrop-blur-md sticky top-0 z-40 overflow-x-auto">
      <div className="flex items-center gap-1 px-4 sm:px-8 min-w-max">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          const active = activeId === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleClick(tab)}
              className={`relative flex items-center gap-2 px-3 sm:px-4 py-3 text-xs sm:text-sm font-medium whitespace-nowrap transition-colors ${
                active ? "text-white" : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <span
                className={`text-[10px] font-bold uppercase tracking-wider rounded px-1.5 py-0.5 border ${
                  active
                    ? "bg-cyan-500/15 text-cyan-300 border-cyan-500/30"
                    : "bg-white/[0.04] text-slate-500 border-white/[0.08]"
                }`}
              >
                {tab.id}
              </span>
              <Icon className={`w-3.5 h-3.5 ${active ? "text-cyan-400" : "text-slate-500"} hidden sm:block`} />
              {tab.label}
              {"isNew" in tab && tab.isNew && (
                <span className="text-[9px] font-bold uppercase tracking-wider bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 text-cyan-300 border border-cyan-500/30 rounded-full px-1.5 py-0.5">
                  New
                </span>
              )}
              {active && (
                <span className="absolute bottom-0 left-2 right-2 h-0.5 rounded-full bg-gradient-to-r from-cyan-400 to-indigo-500" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
