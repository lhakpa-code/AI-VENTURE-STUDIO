import { useState } from "react";
import { FileText, Database, BarChart2, Globe, Users, Info, ChevronDown, ChevronUp } from "lucide-react";
import type { FullReport } from "../types/report";

export function SourcesPanel({ sources }: { sources: FullReport["sources"] }) {
  const [open, setOpen] = useState(false);

  const qualityColor: Record<string, string> = {
    sufficient: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    partial:    "text-amber-400 bg-amber-500/10 border-amber-500/20",
    insufficient: "text-red-400 bg-red-500/10 border-red-500/20",
    full:       "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    limited:    "text-amber-400 bg-amber-500/10 border-amber-500/20",
    none:       "text-red-400 bg-red-500/10 border-red-500/20",
  };

  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen((p) => !p)}
        className="w-full flex items-center justify-between px-6 py-4 hover:bg-white/[0.02] transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
            <FileText className="w-4 h-4 text-white/50" />
          </div>
          <div className="text-left">
            <p className="text-white font-bold text-sm">Evidence & Sources</p>
            <p className="text-white/35 text-xs">Raw findings from Agent 1 and Agent 2</p>
          </div>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>

      {open && (
        <div className="border-t border-white/[0.06] px-6 py-6 grid grid-cols-1 lg:grid-cols-2 gap-8">

          {/* Agent 1: Data Aggregator */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-lg bg-violet-500/15 border border-violet-500/25 flex items-center justify-center">
                <Database className="w-3.5 h-3.5 text-violet-400" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">Agent 1 — Data Aggregator</p>
                <span className={`text-[10px] font-semibold rounded-full px-2 py-0.5 border ${qualityColor[sources.agent1.dataQuality] ?? qualityColor.partial}`}>
                  {sources.agent1.dataQuality}
                </span>
              </div>
            </div>

            {/* SEC Filing */}
            <div className="mb-4">
              <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <FileText className="w-3 h-3" /> SEC Filing
              </p>
              <div className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs
                ${sources.agent1.secFound ? "bg-emerald-500/8 border border-emerald-500/15 text-emerald-300" : "bg-white/[0.03] border border-white/[0.06] text-white/35"}`}>
                <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${sources.agent1.secFound ? "bg-emerald-400" : "bg-white/20"}`} />
                {sources.agent1.secFiling || (sources.agent1.secFound ? "Filing found" : "No public filing found")}
              </div>
            </div>

            {/* Competitors */}
            {sources.agent1.competitors.length > 0 && (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Globe className="w-3 h-3" /> Competitors Identified
                </p>
                <div className="space-y-1.5">
                  {sources.agent1.competitors.map((c, i) => (
                    <div key={i} className="bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2">
                      <p className="text-white/70 text-xs font-semibold">{c.name}</p>
                      <p className="text-white/35 text-xs leading-relaxed">{c.positioning}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Sentiment */}
            {sources.agent1.sentimentSummary && (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Users className="w-3 h-3" /> Sentiment Signal
                </p>
                <p className="text-white/50 text-xs leading-relaxed bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2">
                  {sources.agent1.sentimentSummary}
                </p>
              </div>
            )}

            {/* News Items */}
            {sources.agent1.newsItems.length > 0 && (
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Globe className="w-3 h-3" /> Recent News ({sources.agent1.newsItems.length})
                </p>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {sources.agent1.newsItems.map((n, i) => (
                    <div key={i} className="bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2">
                      <p className="text-white/65 text-xs font-medium leading-snug">{n.headline}</p>
                      <p className="text-white/30 text-[10px] mt-0.5">{n.date} · {n.source}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Agent 2: Quant Analyst */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-lg bg-blue-500/15 border border-blue-500/25 flex items-center justify-center">
                <BarChart2 className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">Agent 2 — Quant Analyst</p>
                <span className={`text-[10px] font-semibold rounded-full px-2 py-0.5 border ${qualityColor[sources.agent2.dataAvailability] ?? qualityColor.limited}`}>
                  {sources.agent2.dataAvailability} data
                </span>
              </div>
            </div>

            {/* Metrics table */}
            {sources.agent2.metrics.length > 0 ? (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <BarChart2 className="w-3 h-3" /> Financial Metrics Extracted
                </p>
                <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-white/[0.06]">
                        <th className="text-left text-white/30 font-semibold px-4 py-2.5">Metric</th>
                        <th className="text-left text-white/30 font-semibold px-4 py-2.5">Value</th>
                        <th className="text-left text-white/30 font-semibold px-4 py-2.5 hidden sm:table-cell">Source</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sources.agent2.metrics.map((m, i) => (
                        <tr key={i} className={`${i < sources.agent2.metrics.length - 1 ? "border-b border-white/[0.04]" : ""}`}>
                          <td className="px-4 py-2.5 text-white/50 font-medium whitespace-nowrap">{m.label}</td>
                          <td className="px-4 py-2.5 text-white/80 font-semibold">{m.value}</td>
                          <td className="px-4 py-2.5 text-white/25 hidden sm:table-cell">{m.source}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl px-4 py-3 mb-4">
                <p className="text-white/30 text-xs">No public financial metrics extracted.</p>
              </div>
            )}

            {/* Company type */}
            {sources.agent2.companyType && sources.agent2.companyType !== "unknown" && (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Company Classification</p>
                <span className="text-xs bg-blue-500/10 border border-blue-500/20 text-blue-300 rounded-full px-3 py-1 capitalize">
                  {sources.agent2.companyType}
                </span>
              </div>
            )}

            {/* Analyst notes */}
            {sources.agent2.notes && (
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Info className="w-3 h-3" /> Analyst Notes
                </p>
                <p className="text-white/40 text-xs leading-relaxed bg-white/[0.02] border border-white/[0.06] rounded-lg px-3 py-2">
                  {sources.agent2.notes}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
