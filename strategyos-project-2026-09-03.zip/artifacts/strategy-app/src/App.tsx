import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Route, Switch, Router as WouterRouter } from 'wouter';

import Home from './pages/home';
import SwotResult from './pages/swot-result';
import HistoryPage from './pages/history';
import ReportViewPage from './pages/report-view';
import VentureStudio from './pages/venture-studio';
import FounderChat from './pages/founder-chat';
import ArchitectPage from './pages/architect';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false, refetchOnWindowFocus: false },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL?.replace(/\/$/, '')}>
          <Switch>
            <Route path="/" component={Home} />
            <Route path="/swot" component={SwotResult} />
            <Route path="/history" component={HistoryPage} />
            <Route path="/report/:id" component={ReportViewPage} />
            <Route path="/venture" component={VentureStudio} />
            <Route path="/founder-chat" component={FounderChat} />
            <Route path="/architect" component={ArchitectPage} />
          </Switch>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
