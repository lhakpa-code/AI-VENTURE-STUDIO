import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { BrainCircuit, History, ArrowLeft, Calendar, ChevronRight, AlertTriangle } from "lucide-react";

interface ReportSummary {
  id: number;
  companyName: string;
  dataQuality: string;
  createdAt: string;
}

const QUALITY_CONFIG: Record<string, { label: string; color: string }> = {
  sufficient:   { label: "Research Complete",   color: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
  partial:      { label: "Partial Research",    color: "bg-amber-500/15 text-amber-300 border-amber-500/30" },
  insufficient: { label: "Limited Public Data", color: "bg-red-500/15 text-red-300 border-red-500/30" },
};

function formatDate(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
}

export default function HistoryPage() {
  const [, navigate] = useLocation();
  const [reports, setReports] = useState<ReportSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/reports")
      .then((r) => {
        if (!r.ok) throw new Error("Failed to load reports");
        return r.json();
      })
      .then((data) => {
        setReports(data);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message ?? "Something went wrong");
        setLoading(false);
      });
  }, []);

  return (
    <div className="min-h-screen bg-[#080810] flex flex-col">
      {/* Header */}
      <header className="flex items-center gap-3 px-8 py-5 border-b border-white/[0.06]">
        <div className="w-8 h-8 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
        </div>
        <span className="font-semibold text-white tracking-tight">StrategyOS</span>
      </header>

      <main className="flex-1 px-4 md:px-8 py-10 w-full max-w-4xl mx-auto">
        {/* Page header */}
        <div className="mb-8">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-1.5 text-white/35 hover:text-white/65 text-sm mb-5 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            New analysis
          </button>
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-violet-600/15 border border-violet-500/25 flex items-center justify-center">
              <History className="w-5 h-5 text-violet-400" />
            </div>
            <h1 className="text-3xl font-bold text-white tracking-tight">Report History</h1>
          </div>
          <p className="text-white/35 text-sm ml-[52px]">Your most recent 20 strategic intelligence reports</p>
        </div>

        {/* Content */}
        {loading && (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-2 border-violet-500/30 border-t-violet-400 rounded-full animate-spin" />
          </div>
        )}

        {error && (
          <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-2xl px-5 py-4">
            <AlertTriangle className="w-5 h-5 text-red-400 shrink-0" />
            <p className="text-red-300 text-sm">{error}</p>
          </div>
        )}

        {!loading && !error && reports.length === 0 && (
          <div className="text-center py-20">
            <div className="w-16 h-16 rounded-2xl bg-white/[0.03] border border-white/10 flex items-center justify-center mx-auto mb-4">
              <History className="w-7 h-7 text-white/20" />
            </div>
            <p className="text-white/35 text-sm mb-5">No reports yet. Run your first analysis to get started.</p>
            <button
              onClick={() => navigate("/")}
              className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all"
            >
              <BrainCircuit className="w-4 h-4" />
              Start analysing
            </button>
          </div>
        )}

        {!loading && !error && reports.length > 0 && (
          <div className="space-y-2">
            {reports.map((r) => {
              const qcfg = QUALITY_CONFIG[r.dataQuality] ?? QUALITY_CONFIG.partial;
              return (
                <button
                  key={r.id}
                  onClick={() => navigate(`/report/${r.id}`)}
                  className="w-full group flex items-center justify-between gap-4 bg-white/[0.02] hover:bg-white/[0.04] border border-white/[0.07] hover:border-white/[0.12] rounded-2xl px-6 py-4 transition-all text-left"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center shrink-0">
                      <BrainCircuit className="w-5 h-5 text-violet-400" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-white font-semibold text-sm leading-snug truncate">{r.companyName}</p>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className={`text-[10px] font-semibold rounded-full px-2 py-0.5 border ${qcfg.color}`}>
                          {qcfg.label}
                        </span>
                        <span className="text-white/30 text-xs flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {formatDate(r.createdAt)} at {formatTime(r.createdAt)}
                        </span>
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-white/20 group-hover:text-white/50 transition-colors shrink-0" />
                </button>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
