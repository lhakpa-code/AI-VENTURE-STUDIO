import { useEffect, useRef, useState } from "react";
import {
  BrainCircuit, MessageCircle, Send, Sparkles, Loader2, RefreshCw,
  Lightbulb, Users, AlertTriangle, Wrench, Globe, Rocket, Wallet,
  Target, TrendingUp, Map, CheckCircle2, Layers, Copy, Check, Download,
  ChevronLeft, ChevronRight, Presentation,
} from "lucide-react";
import VersionNav from "../components/VersionNav";

// ── Types ─────────────────────────────────────────────────────────────────────

interface ChatAnswers {
  idea: string;
  target_customer: string;
  problem: string;
  solution: string;
  monetization: string;
  competitors: string;
  market: string;
  stage: string;
  budget: string;
  goals: string;
}

const EMPTY: ChatAnswers = {
  idea: "", target_customer: "", problem: "", solution: "", monetization: "",
  competitors: "", market: "", stage: "", budget: "", goals: "",
};

interface ChatQuestion {
  key: string;
  text: string;
  icon: typeof Lightbulb;
  options?: string[];
  placeholder: string;
}

const QUESTIONS: ChatQuestion[] = [
  { key: "idea", icon: Lightbulb, text: "Hi! I'm your AI co-founder. Let's draft your company together. First — what's your startup idea?", placeholder: "e.g. An AI animation app for kids…" },
  { key: "target_customer", icon: Users, text: "Great. Who is your target customer?", placeholder: "e.g. Parents of kids aged 5-10…" },
  { key: "problem", icon: AlertTriangle, text: "What problem are you solving for them?", placeholder: "e.g. Kids' creative tools are too complex…" },
  { key: "solution", icon: Wrench, text: "And what is your proposed solution?", placeholder: "e.g. A drag-and-drop animation studio with AI assistance…" },
  { key: "monetization", icon: Wallet, text: "How will you make money?", placeholder: "e.g. Monthly subscription with a free tier…" },
  { key: "competitors", icon: Target, text: "Who are your competitors?", placeholder: "e.g. Toontastic, Scratch, FlipaClip…" },
  { key: "market", icon: Globe, text: "What country/market are you targeting?", placeholder: "e.g. United States, then English-speaking markets…" },
  { key: "stage", icon: Rocket, text: "What stage are you at?", options: ["Idea", "MVP", "Launched"], placeholder: "" },
  { key: "budget", icon: Wallet, text: "What is your current budget?", placeholder: "e.g. $10,000" },
  { key: "goals", icon: TrendingUp, text: "Last one — what are your main goals for the next 90 days?", placeholder: "e.g. Launch the MVP and get 100 paying users…" },
];

const GROWTH_QUESTIONS: ChatQuestion[] = [
  { key: "business", icon: Lightbulb, text: "Welcome back, operator. Let's diagnose your business. First — what does your business do?", placeholder: "e.g. We run an online tutoring service for high schoolers…" },
  { key: "customer", icon: Users, text: "Who are your customers today?", placeholder: "e.g. Parents of teens preparing for exams…" },
  { key: "revenue_model", icon: Wallet, text: "How does the business make money?", placeholder: "e.g. Monthly packages of 8 tutoring sessions…" },
  { key: "monthly_revenue", icon: TrendingUp, text: "What's your current monthly revenue (roughly)?", placeholder: "e.g. $8,000/month" },
  { key: "challenge", icon: AlertTriangle, text: "What's the biggest challenge you're facing right now?", placeholder: "e.g. Growth has stalled and churn is rising…" },
  { key: "marketing", icon: Rocket, text: "What marketing channels are you using today?", placeholder: "e.g. Instagram ads and word of mouth…" },
  { key: "competitors", icon: Target, text: "Who are your main competitors?", placeholder: "e.g. Wyzant, local tutoring centres…" },
  { key: "team_size", icon: Users, text: "How big is your team?", placeholder: "e.g. 3 people — me plus 2 part-time tutors" },
  { key: "goals", icon: Map, text: "Last one — what are your goals for the next 90 days?", placeholder: "e.g. Get back to 15% monthly growth and cut churn in half…" },
];

interface RoadmapPhase { phase?: string; focus?: string; actions?: string[] }
interface Blueprint {
  business_concept: string;
  target_customer: string;
  problem_strength: string;
  value_proposition: string;
  competitive_positioning: string;
  recommended_business_model: string;
  pricing_approach: string;
  go_to_market_strategy: string;
  major_risks: string[];
  recommended_kpis: string[];
  mvp_priorities: string[];
  personalized_roadmap: RoadmapPhase[];
}

type Message = { role: "app" | "user"; text: string };

interface Slide { key: string; title: string; headline: string; bullets: string[] }
interface PitchDeck { slides: Slide[]; pptx_base64: string }

interface GrowthReport {
  current_state_diagnosis: string;
  business_model_recommendation: string;
  marketing_overhaul: string;
  pricing_strategy: string;
  retention_strategy: string;
  competitive_repositioning: string;
  operational_efficiency: string;
  major_risks: string[];
  recommended_kpis: string[];
  turnaround_plan: RoadmapPhase[];
}

type Mode = "startup" | "growth";

// ── Styles ────────────────────────────────────────────────────────────────────

const GLOW_BG =
  "min-h-screen bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.2),rgba(255,255,255,0))] text-slate-100 flex flex-col";
const CARD =
  "bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md shadow-xl";

// ── Markdown export ───────────────────────────────────────────────────────────

const SECTIONS: { key: keyof Blueprint; title: string }[] = [
  { key: "business_concept", title: "Business Concept" },
  { key: "target_customer", title: "Target Customer" },
  { key: "problem_strength", title: "Problem Strength" },
  { key: "value_proposition", title: "Value Proposition" },
  { key: "competitive_positioning", title: "Competitive Positioning" },
  { key: "recommended_business_model", title: "Recommended Business Model" },
  { key: "pricing_approach", title: "Pricing Approach" },
  { key: "go_to_market_strategy", title: "Go-To-Market Strategy" },
];

function blueprintToMarkdown(answers: ChatAnswers, bp: Blueprint): string {
  const lines: string[] = [`# Founder Strategy Blueprint: ${answers.idea}`, ""];
  for (const s of SECTIONS) {
    lines.push(`## ${s.title}`, String(bp[s.key] ?? ""), "");
  }
  lines.push("## Major Risks", ...(bp.major_risks ?? []).map((r) => `- ${r}`), "");
  lines.push("## Recommended KPIs", ...(bp.recommended_kpis ?? []).map((k) => `- ${k}`), "");
  lines.push("## MVP Priorities", ...(bp.mvp_priorities ?? []).map((m, i) => `${i + 1}. ${m}`), "");
  lines.push("## Personalized Roadmap");
  for (const p of bp.personalized_roadmap ?? []) {
    lines.push(`### ${p.phase ?? ""} — ${p.focus ?? ""}`, ...(p.actions ?? []).map((a) => `- ${a}`));
  }
  return lines.join("\n");
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function FounderChatPage() {
  const [mode, setMode] = useState<Mode | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [qIndex, setQIndex] = useState(0);
  const [input, setInput] = useState("");
  const [generating, setGenerating] = useState(false);
  const [blueprint, setBlueprint] = useState<Blueprint | null>(null);
  const [growthReport, setGrowthReport] = useState<GrowthReport | null>(null);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const genIdRef = useRef(0); // invalidates in-flight generations on reset/mode switch

  const questions = mode === "growth" ? GROWTH_QUESTIONS : QUESTIONS;
  const currentQ = questions[qIndex];
  const done = qIndex >= questions.length;

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, generating, blueprint, growthReport]);

  const generate = async (finalAnswers: Record<string, string>, forMode: Mode) => {
    const myGenId = ++genIdRef.current;
    setGenerating(true);
    setError(null);
    try {
      const endpoint = forMode === "growth" ? "/api/architect/growth-report" : "/api/architect/blueprint";
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(finalAnswers),
      });
      const data = await res.json();
      if (myGenId !== genIdRef.current) return; // user reset or switched mode — discard
      if (!res.ok) throw new Error(data.error ?? "Generation failed");
      if (forMode === "growth") setGrowthReport(data);
      else setBlueprint(data);
    } catch (err: any) {
      if (myGenId !== genIdRef.current) return;
      setError(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      if (myGenId === genIdRef.current) setGenerating(false);
    }
  };

  const pickMode = (m: Mode) => {
    genIdRef.current++;
    setMode(m);
    const qs = m === "growth" ? GROWTH_QUESTIONS : QUESTIONS;
    setMessages([{ role: "app", text: qs[0].text }]);
    setAnswers({});
    setQIndex(0);
    setInput("");
    setBlueprint(null);
    setGrowthReport(null);
    setError(null);
  };

  const submitAnswer = (raw: string) => {
    const text = raw.trim();
    if (!text || !currentQ || generating || !mode) return;
    const nextAnswers = { ...answers, [currentQ.key]: text };
    setAnswers(nextAnswers);
    setInput("");

    const next = qIndex + 1;
    const newMessages: Message[] = [...messages, { role: "user", text }];
    if (next < questions.length) {
      newMessages.push({ role: "app", text: questions[next].text });
    } else {
      newMessages.push({
        role: "app",
        text: mode === "growth"
          ? "Perfect — that's everything I need. Drafting your Business Growth Strategy Report now…"
          : "Perfect — that's everything I need. Drafting your Founder Strategy Blueprint now…",
      });
      void generate(nextAnswers, mode);
    }
    setMessages(newMessages);
    setQIndex(next);
  };

  const reset = () => {
    genIdRef.current++;
    setMode(null);
    setGenerating(false);
    setMessages([]);
    setAnswers({});
    setQIndex(0);
    setInput("");
    setBlueprint(null);
    setGrowthReport(null);
    setError(null);
  };

  return (
    <div className={GLOW_BG}>
      <header className="flex items-center gap-3 px-4 sm:px-8 py-5 border-b border-white/[0.06]">
        <div className="w-8 h-8 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
        </div>
        <span className="font-semibold text-white tracking-tight">StrategyOS</span>
        <span className="ml-auto inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
          <MessageCircle className="w-3 h-3" />
          Founder Chat
        </span>
      </header>

      <VersionNav />

      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-8 flex flex-col">
        {mode === null ? (
          /* Landing: pick a flow */
          <div className="space-y-6 my-auto">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-white">Strategy Studio</h2>
              <p className="text-slate-400 text-sm mt-1">Two chat-driven strategy tools. Pick the one that fits where you are.</p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <button
                onClick={() => pickMode("startup")}
                className={`${CARD} p-6 text-left hover:border-cyan-500/50 transition-all group`}
              >
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-4">
                  <Lightbulb className="w-5 h-5 text-cyan-400" />
                </div>
                <h3 className="font-bold text-white group-hover:text-cyan-300 transition-colors">Founder Strategy Blueprint</h3>
                <p className="text-slate-400 text-sm mt-1.5 leading-relaxed">For a new idea, MVP, or early launch. 10 questions → 12-section blueprint → optional investor pitch deck (.pptx).</p>
                <p className="text-cyan-400 text-xs font-semibold mt-3">Start the chat →</p>
              </button>
              <button
                onClick={() => pickMode("growth")}
                className={`${CARD} p-6 text-left hover:border-amber-500/50 transition-all group`}
              >
                <div className="w-10 h-10 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-4">
                  <TrendingUp className="w-5 h-5 text-amber-400" />
                </div>
                <h3 className="font-bold text-white group-hover:text-amber-300 transition-colors">Business Growth Strategy Report</h3>
                <p className="text-slate-400 text-sm mt-1.5 leading-relaxed">For a business already running. 9-question diagnostic → 10-section growth & repositioning report with a 90-day turnaround plan.</p>
                <p className="text-amber-400 text-xs font-semibold mt-3">Start the diagnostic →</p>
              </button>
            </div>
          </div>
        ) : growthReport ? (
          <GrowthReportView report={growthReport} answers={answers} onRestart={reset} />
        ) : blueprint ? (
          <BlueprintView blueprint={blueprint} answers={answers as unknown as ChatAnswers} onRestart={reset} />
        ) : (
          <>
            {/* Chat feed */}
            <div className={`${CARD} flex-1 flex flex-col p-4 sm:p-6 min-h-[420px]`}>
              <div className="flex-1 space-y-4 overflow-y-auto">
                {messages.map((m, i) => (
                  <div key={i} className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}>
                    {m.role === "app" && (
                      <div className="mr-2 mt-1 w-7 h-7 shrink-0 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      </div>
                    )}
                    <div
                      className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                        m.role === "user"
                          ? "bg-gradient-to-r from-cyan-500/20 to-indigo-500/20 border border-cyan-500/30 text-white rounded-br-md"
                          : "bg-slate-950/60 border border-slate-800 text-slate-200 rounded-bl-md"
                      }`}
                    >
                      {m.text}
                    </div>
                  </div>
                ))}

                {generating && (
                  <div className="flex justify-start">
                    <div className="mr-2 mt-1 w-7 h-7 shrink-0 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                      <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                    </div>
                    <div className="rounded-2xl rounded-bl-md px-4 py-3 text-sm bg-slate-950/60 border border-slate-800 text-slate-400">
                      Analysing your answers and drafting the {mode === "growth" ? "growth report" : "blueprint"}… (~20s)
                    </div>
                  </div>
                )}

                {error && (
                  <div className="rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 text-sm px-4 py-3">
                    {error}{" "}
                    <button onClick={() => mode && generate(answers, mode)} className="underline font-semibold">Retry</button>
                  </div>
                )}
                <div ref={bottomRef} />
              </div>

              {/* Input row */}
              {!done && currentQ && (
                currentQ.options ? (
                  <div className="pt-4 flex flex-wrap gap-2 border-t border-white/[0.06] mt-4">
                    {currentQ.options.map((opt) => (
                      <button
                        key={opt}
                        onClick={() => submitAnswer(opt)}
                        className="rounded-full border border-cyan-500/30 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-sm font-medium px-5 py-2.5 transition-all"
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="pt-4 flex items-end gap-2 border-t border-white/[0.06] mt-4">
                    <textarea
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); submitAnswer(input); }
                      }}
                      placeholder={currentQ.placeholder}
                      rows={1}
                      autoFocus
                      className="flex-1 rounded-xl bg-slate-950/60 border border-slate-800 focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 text-slate-100 placeholder:text-slate-600 text-sm px-4 py-3 resize-none transition-all"
                    />
                    <button
                      onClick={() => submitAnswer(input)}
                      disabled={!input.trim()}
                      className="shrink-0 w-11 h-11 rounded-xl bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 flex items-center justify-center disabled:opacity-40 hover:opacity-90 transition-all"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                )
              )}
            </div>

            <p className="text-center text-xs text-slate-600 mt-3">
              Question {Math.min(qIndex + 1, questions.length)} of {questions.length} · Your answers become a {mode === "growth" ? "Business Growth Strategy Report" : "Founder Strategy Blueprint"}
            </p>
          </>
        )}
      </main>
    </div>
  );
}

// ── Blueprint view ────────────────────────────────────────────────────────────

// ── Growth report view ────────────────────────────────────────────────────────

const GROWTH_SECTIONS: { key: keyof GrowthReport; title: string; icon: typeof Target }[] = [
  { key: "current_state_diagnosis", title: "Current-State Diagnosis", icon: AlertTriangle },
  { key: "business_model_recommendation", title: "Business Model Recommendation", icon: Layers },
  { key: "marketing_overhaul", title: "Marketing Overhaul", icon: Rocket },
  { key: "pricing_strategy", title: "Pricing Strategy", icon: Wallet },
  { key: "retention_strategy", title: "Retention Strategy", icon: Users },
  { key: "competitive_repositioning", title: "Competitive Repositioning", icon: Target },
  { key: "operational_efficiency", title: "Operational Efficiency", icon: Wrench },
];

function growthReportToMarkdown(answers: Record<string, string>, r: GrowthReport): string {
  const lines: string[] = [`# Business Growth Strategy Report: ${answers.business ?? ""}`, ""];
  for (const s of GROWTH_SECTIONS) {
    lines.push(`## ${s.title}`, String(r[s.key] ?? ""), "");
  }
  lines.push("## Major Risks", ...(r.major_risks ?? []).map((x) => `- ${x}`), "");
  lines.push("## Recommended KPIs", ...(r.recommended_kpis ?? []).map((x) => `- ${x}`), "");
  lines.push("## 90-Day Turnaround Plan");
  for (const p of r.turnaround_plan ?? []) {
    lines.push(`### ${p.phase ?? ""} — ${p.focus ?? ""}`, ...(p.actions ?? []).map((a) => `- ${a}`));
  }
  return lines.join("\n");
}

function GrowthReportView({ report, answers, onRestart }: {
  report: GrowthReport;
  answers: Record<string, string>;
  onRestart: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const today = new Date().toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

  const copyReport = async () => {
    try {
      await navigator.clipboard.writeText(growthReportToMarkdown(answers, report));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard unavailable */ }
  };

  const exportReport = () => {
    const blob = new Blob([growthReportToMarkdown(answers, report)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "business-growth-strategy-report.md";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      className="relative rounded-lg border-2 border-amber-500/40 bg-[#0a1a2f] p-5 sm:p-8 space-y-6"
      style={{
        backgroundImage:
          "linear-gradient(rgba(34,211,238,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.06) 1px, transparent 1px), linear-gradient(rgba(34,211,238,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.035) 1px, transparent 1px)",
        backgroundSize: "96px 96px, 96px 96px, 24px 24px, 24px 24px",
      }}
    >
      {[
        "top-2 left-2 border-t-2 border-l-2",
        "top-2 right-2 border-t-2 border-r-2",
        "bottom-2 left-2 border-b-2 border-l-2",
        "bottom-2 right-2 border-b-2 border-r-2",
      ].map((pos) => (
        <div key={pos} className={`pointer-events-none absolute w-5 h-5 border-cyan-400/70 ${pos}`} />
      ))}

      {/* Title block */}
      <div className="border border-amber-500/40 divide-y divide-amber-500/30 bg-[#0a1a2f]/80">
        <div className="flex flex-wrap items-center justify-between gap-4 px-4 py-3">
          <div>
            <p className="text-[10px] uppercase tracking-[0.25em] text-amber-400/80">Venture Studio · Drawing No. BGR-001</p>
            <h2 className="text-2xl font-bold text-white tracking-wide uppercase">Business Growth Strategy Report</h2>
          </div>
          <span className="inline-flex items-center gap-2 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-cyan-300 border border-cyan-400/50 bg-cyan-500/10">
            <CheckCircle2 className="w-3 h-3" /> Diagnostic Complete
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-amber-500/30 text-xs">
          <div className="px-4 py-2"><p className="text-amber-400/70 uppercase text-[10px] tracking-widest">Business</p><p className="text-slate-200 truncate">{(answers.business ?? "").slice(0, 60)}</p></div>
          <div className="px-4 py-2"><p className="text-amber-400/70 uppercase text-[10px] tracking-widest">Revenue</p><p className="text-slate-200 truncate">{(answers.monthly_revenue ?? "").slice(0, 30)}</p></div>
          <div className="px-4 py-2"><p className="text-amber-400/70 uppercase text-[10px] tracking-widest">Team</p><p className="text-slate-200 truncate">{(answers.team_size ?? "").slice(0, 30)}</p></div>
          <div className="px-4 py-2"><p className="text-amber-400/70 uppercase text-[10px] tracking-widest">Date</p><p className="text-slate-200">{today}</p></div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-wrap items-center gap-2 justify-end">
        <button
          onClick={copyReport}
          className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 rounded-full px-4 py-2 transition-all"
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          {copied ? "Copied!" : "Copy"}
        </button>
        <button
          onClick={exportReport}
          className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-500/20 rounded-full px-4 py-2 transition-all"
        >
          <Download className="w-3.5 h-3.5" /> Export
        </button>
        <button
          onClick={onRestart}
          className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300 bg-white/[0.04] border border-white/[0.08] hover:border-slate-600 rounded-full px-4 py-2 transition-all"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Start over
        </button>
      </div>

      {/* Prose sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {GROWTH_SECTIONS.map(({ key, title, icon: Icon }) => (
          <section key={key} className={`${CARD} p-5 ${key === "current_state_diagnosis" ? "md:col-span-2" : ""}`}>
            <div className="flex items-center gap-2.5 mb-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                <Icon className="w-4 h-4 text-amber-400" />
              </div>
              <h3 className="text-sm font-bold text-white">{title}</h3>
            </div>
            <p className="text-slate-300 text-sm leading-relaxed">{String(report[key] ?? "")}</p>
          </section>
        ))}
      </div>

      {/* Major risks */}
      {report.major_risks?.length > 0 && (
        <section className={`${CARD} p-5`}>
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-red-400" />
            </div>
            <h3 className="text-sm font-bold text-white">Major Risks</h3>
          </div>
          <ul className="space-y-2">
            {report.major_risks.map((r, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400 mt-0.5 shrink-0" /> {r}
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* KPIs */}
      {report.recommended_kpis?.length > 0 && (
        <section className={`${CARD} p-5`}>
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
            </div>
            <h3 className="text-sm font-bold text-white">Recommended KPIs</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {report.recommended_kpis.map((k) => (
              <span key={k} className="text-xs text-indigo-200 bg-indigo-500/10 border border-indigo-500/20 rounded-full px-3 py-1">{k}</span>
            ))}
          </div>
        </section>
      )}

      {/* Turnaround plan */}
      {report.turnaround_plan?.length > 0 && (
        <section className={`${CARD} p-5 sm:p-6`}>
          <div className="flex items-center gap-2.5 mb-4">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <Map className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-sm font-bold text-white">90-Day Turnaround Plan</h3>
          </div>
          <div className="space-y-5 sm:pl-3 sm:border-l sm:border-slate-800">
            {report.turnaround_plan.map((p, i) => (
              <div key={i}>
                <div className="flex items-center gap-2.5 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-300 bg-emerald-500/10 border border-emerald-500/30 rounded-full px-2.5 py-0.5">
                    {p.phase ?? `Phase ${i + 1}`}
                  </span>
                  <span className="text-sm font-semibold text-white">{p.focus}</span>
                </div>
                <ul className="space-y-1.5">
                  {(p.actions ?? []).map((a, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-slate-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" /> {a}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

// ── Pitch deck carousel ───────────────────────────────────────────────────────

function PitchDeckView({ deck, companyName, onClose }: { deck: PitchDeck; companyName: string; onClose: () => void }) {
  const [idx, setIdx] = useState(0);
  const slide = deck.slides[idx];
  const total = deck.slides.length;

  const downloadPptx = () => {
    const bytes = Uint8Array.from(atob(deck.pptx_base64), (c) => c.charCodeAt(0));
    const blob = new Blob([bytes], { type: "application/vnd.openxmlformats-officedocument.presentationml.presentation" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${companyName.replace(/\s+/g, "-")}-pitch-deck.pptx`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[10px] uppercase tracking-[0.2em] text-amber-400/80">Investor Pitch Deck</p>
          <h3 className="text-lg font-bold text-white">{companyName}</h3>
        </div>
        <div className="flex gap-2">
          <button
            onClick={downloadPptx}
            className="inline-flex items-center gap-2 text-xs font-semibold text-amber-300 bg-amber-500/10 border border-amber-500/30 hover:bg-amber-500/20 rounded-full px-4 py-2 transition-all"
          >
            <Download className="w-3.5 h-3.5" /> Download .pptx
          </button>
          <button
            onClick={onClose}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300 bg-white/[0.04] border border-white/[0.08] hover:border-slate-600 rounded-full px-4 py-2 transition-all"
          >
            ← Back to blueprint
          </button>
        </div>
      </div>

      {/* Slide viewer */}
      <div
        className="relative rounded-lg border border-cyan-500/30 bg-[#0a1a2f] overflow-hidden"
        style={{
          backgroundImage:
            "linear-gradient(rgba(34,211,238,0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.05) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      >
        {/* Slide header strip */}
        <div className="bg-[#0d2340] border-b border-cyan-500/20 px-6 py-3">
          <p className="text-[10px] uppercase tracking-[0.25em] text-cyan-400/70">
            Slide {idx + 1} of {total} · {slide?.title}
          </p>
          <p className="text-lg font-bold text-white mt-0.5">{slide?.headline}</p>
        </div>

        {/* Slide body */}
        <div className="px-6 py-6 min-h-[280px]">
          {idx === 0 ? (
            // Cover slide — centred
            <div className="flex flex-col items-center justify-center h-48 text-center gap-3">
              <p className="text-2xl font-bold text-white">{companyName}</p>
              <p className="text-cyan-300 text-base">{slide?.headline}</p>
              <div className="flex flex-wrap justify-center gap-3 mt-2">
                {(slide?.bullets ?? []).map((b, i) => (
                  <span key={i} className="text-xs bg-cyan-500/10 border border-cyan-500/20 text-cyan-200 rounded-full px-3 py-1">{b}</span>
                ))}
              </div>
            </div>
          ) : (
            <ul className="space-y-3">
              {(slide?.bullets ?? []).map((b, i) => (
                <li key={i} className="flex items-start gap-3 text-sm text-slate-200">
                  <span className="mt-0.5 shrink-0 w-5 h-5 rounded bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-[11px] font-bold flex items-center justify-center">{i + 1}</span>
                  {b}
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Amber bottom accent */}
        <div className="h-1 bg-gradient-to-r from-amber-500/80 via-amber-400/40 to-transparent" />
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setIdx(Math.max(0, idx - 1))}
          disabled={idx === 0}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-300 bg-white/[0.04] border border-white/[0.08] hover:border-slate-600 rounded-full px-4 py-2 disabled:opacity-30 transition-all"
        >
          <ChevronLeft className="w-3.5 h-3.5" /> Previous
        </button>

        {/* Dot indicators */}
        <div className="flex gap-1.5">
          {deck.slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setIdx(i)}
              className={`rounded-full transition-all ${i === idx ? "w-5 h-2 bg-cyan-400" : "w-2 h-2 bg-slate-700 hover:bg-slate-500"}`}
            />
          ))}
        </div>

        <button
          onClick={() => setIdx(Math.min(total - 1, idx + 1))}
          disabled={idx === total - 1}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-300 bg-white/[0.04] border border-white/[0.08] hover:border-slate-600 rounded-full px-4 py-2 disabled:opacity-30 transition-all"
        >
          Next <ChevronRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
}

const SECTION_ICONS: Record<string, typeof Target> = {
  business_concept: Lightbulb,
  target_customer: Users,
  problem_strength: AlertTriangle,
  value_proposition: Sparkles,
  competitive_positioning: Target,
  recommended_business_model: Layers,
  pricing_approach: Wallet,
  go_to_market_strategy: Rocket,
};

function BlueprintView({ blueprint, answers, onRestart }: {
  blueprint: Blueprint;
  answers: ChatAnswers;
  onRestart: () => void;
}) {
  const [copied, setCopied] = useState(false);
  const [deckState, setDeckState] = useState<"idle" | "form" | "generating" | "done">("idle");
  const [deckCompany, setDeckCompany] = useState(answers.idea.slice(0, 60));
  const [deckTagline, setDeckTagline] = useState("");
  const [deckAsk, setDeckAsk] = useState("");
  const [deckError, setDeckError] = useState<string | null>(null);
  const [deck, setDeck] = useState<PitchDeck | null>(null);

  const generateDeck = async () => {
    if (!deckCompany.trim() || !deckAsk.trim()) return;
    setDeckState("generating");
    setDeckError(null);
    try {
      const res = await fetch("/api/architect/pitch-deck", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ company_name: deckCompany, tagline: deckTagline, funding_ask: deckAsk, blueprint }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Generation failed");
      setDeck(data as PitchDeck);
      setDeckState("done");
    } catch (err: any) {
      setDeckError(err?.message ?? "Something went wrong. Please try again.");
      setDeckState("form");
    }
  };

  if (deckState === "done" && deck) {
    return <PitchDeckView deck={deck} companyName={deckCompany} onClose={() => setDeckState("idle")} />;
  }

  const copyBlueprint = async () => {
    try {
      await navigator.clipboard.writeText(blueprintToMarkdown(answers, blueprint));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard unavailable */ }
  };

  const exportBlueprint = () => {
    const blob = new Blob([blueprintToMarkdown(answers, blueprint)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "founder-strategy-blueprint.md";
    a.click();
    URL.revokeObjectURL(url);
  };

  const today = new Date().toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

  return (
    <div
      className="relative rounded-lg border-2 border-cyan-500/40 bg-[#0a1a2f] p-5 sm:p-8 space-y-6"
      style={{
        backgroundImage:
          "linear-gradient(rgba(34,211,238,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.06) 1px, transparent 1px), linear-gradient(rgba(34,211,238,0.035) 1px, transparent 1px), linear-gradient(90deg, rgba(34,211,238,0.035) 1px, transparent 1px)",
        backgroundSize: "96px 96px, 96px 96px, 24px 24px, 24px 24px",
      }}
    >
      {/* Corner crop marks */}
      {[
        "top-2 left-2 border-t-2 border-l-2",
        "top-2 right-2 border-t-2 border-r-2",
        "bottom-2 left-2 border-b-2 border-l-2",
        "bottom-2 right-2 border-b-2 border-r-2",
      ].map((pos) => (
        <div key={pos} className={`pointer-events-none absolute w-5 h-5 border-amber-400/70 ${pos}`} />
      ))}

      {/* Title block */}
      <div className="border border-cyan-500/40 divide-y divide-cyan-500/30 bg-[#0a1a2f]/80">
        <div className="flex flex-wrap items-center justify-between gap-4 px-4 py-3">
          <div>
            <p className="text-[10px] uppercase tracking-[0.25em] text-cyan-400/80">Venture Studio · Drawing No. FSB-001</p>
            <h2 className="text-2xl font-bold text-white tracking-wide uppercase">Founder Strategy Blueprint</h2>
          </div>
          <span className="inline-flex items-center gap-2 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-amber-300 border border-amber-400/50 bg-amber-500/10">
            <CheckCircle2 className="w-3 h-3" /> Approved Draft
          </span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-x divide-cyan-500/30 text-xs">
          <div className="px-4 py-2"><p className="text-cyan-400/70 uppercase text-[10px] tracking-widest">Project</p><p className="text-slate-200 truncate">{answers.idea.slice(0, 60)}</p></div>
          <div className="px-4 py-2"><p className="text-cyan-400/70 uppercase text-[10px] tracking-widest">Stage</p><p className="text-slate-200">{answers.stage}</p></div>
          <div className="px-4 py-2"><p className="text-cyan-400/70 uppercase text-[10px] tracking-widest">Budget</p><p className="text-slate-200 truncate">{answers.budget.slice(0, 30)}</p></div>
          <div className="px-4 py-2"><p className="text-cyan-400/70 uppercase text-[10px] tracking-widest">Date</p><p className="text-slate-200">{today}</p></div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Pitch deck CTA */}
        <button
          onClick={() => setDeckState(deckState === "form" ? "idle" : "form")}
          className="inline-flex items-center gap-2 text-sm font-semibold text-amber-200 bg-amber-500/10 border border-amber-500/40 hover:bg-amber-500/20 rounded-lg px-5 py-2.5 transition-all"
        >
          <Presentation className="w-4 h-4" />
          🎤 Generate Investor Pitch Deck
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={copyBlueprint}
            className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 rounded-full px-4 py-2 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? "Copied!" : "Copy"}
          </button>
          <button
            onClick={exportBlueprint}
            className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-500/20 rounded-full px-4 py-2 transition-all"
          >
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button
            onClick={onRestart}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300 bg-white/[0.04] border border-white/[0.08] hover:border-slate-600 rounded-full px-4 py-2 transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Start over
          </button>
        </div>
      </div>

      {/* Pitch deck mini-form */}
      {(deckState === "form" || deckState === "generating") && (
        <div className="border border-amber-500/30 bg-amber-500/5 rounded-xl p-5 space-y-4">
          <p className="text-sm font-semibold text-amber-200">Two quick questions to personalise the deck:</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] uppercase tracking-widest text-amber-400/80 mb-1">Company / Product name *</label>
              <input
                value={deckCompany}
                onChange={(e) => setDeckCompany(e.target.value)}
                placeholder="e.g. AnimateKids"
                className="w-full rounded-lg bg-slate-950/60 border border-slate-800 focus:border-amber-500/50 focus:outline-none text-slate-100 placeholder:text-slate-600 text-sm px-3 py-2"
              />
            </div>
            <div>
              <label className="block text-[11px] uppercase tracking-widest text-amber-400/80 mb-1">Funding ask *</label>
              <input
                value={deckAsk}
                onChange={(e) => setDeckAsk(e.target.value)}
                placeholder="e.g. $500,000 pre-seed"
                className="w-full rounded-lg bg-slate-950/60 border border-slate-800 focus:border-amber-500/50 focus:outline-none text-slate-100 placeholder:text-slate-600 text-sm px-3 py-2"
              />
            </div>
          </div>
          <div>
            <label className="block text-[11px] uppercase tracking-widest text-amber-400/80 mb-1">Tagline <span className="text-slate-500 normal-case">(optional — AI writes one if blank)</span></label>
            <input
              value={deckTagline}
              onChange={(e) => setDeckTagline(e.target.value)}
              placeholder="e.g. Where kids bring stories to life"
              className="w-full rounded-lg bg-slate-950/60 border border-slate-800 focus:border-amber-500/50 focus:outline-none text-slate-100 placeholder:text-slate-600 text-sm px-3 py-2"
            />
          </div>
          {deckError && <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg px-3 py-2">{deckError}</p>}
          <button
            onClick={generateDeck}
            disabled={!deckCompany.trim() || !deckAsk.trim() || deckState === "generating"}
            className="inline-flex items-center gap-2 text-sm font-semibold text-amber-200 bg-amber-500/20 border border-amber-500/40 hover:bg-amber-500/30 rounded-lg px-5 py-2.5 disabled:opacity-40 transition-all"
          >
            {deckState === "generating" ? <Loader2 className="w-4 h-4 animate-spin" /> : <Presentation className="w-4 h-4" />}
            {deckState === "generating" ? "Drafting deck… (~30s)" : "Build my pitch deck"}
          </button>
        </div>
      )}

      {/* Prose sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SECTIONS.map(({ key, title }) => {
          const Icon = SECTION_ICONS[key] ?? Target;
          return (
            <section key={key} className={`${CARD} p-5`}>
              <div className="flex items-center gap-2.5 mb-2.5">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                  <Icon className="w-4 h-4 text-cyan-400" />
                </div>
                <h3 className="text-sm font-bold text-white">{title}</h3>
              </div>
              <p className="text-slate-300 text-sm leading-relaxed">{String(blueprint[key] ?? "")}</p>
            </section>
          );
        })}
      </div>

      {/* Major risks */}
      {blueprint.major_risks?.length > 0 && (
        <section className={`${CARD} p-5`}>
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
            </div>
            <h3 className="text-sm font-bold text-white">Major Risks</h3>
          </div>
          <ul className="space-y-2">
            {blueprint.major_risks.map((r, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400 mt-0.5 shrink-0" /> {r}
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* KPIs */}
      {blueprint.recommended_kpis?.length > 0 && (
        <section className={`${CARD} p-5`}>
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-indigo-400" />
            </div>
            <h3 className="text-sm font-bold text-white">Recommended KPIs</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {blueprint.recommended_kpis.map((k) => (
              <span key={k} className="text-xs text-indigo-200 bg-indigo-500/10 border border-indigo-500/20 rounded-full px-3 py-1">{k}</span>
            ))}
          </div>
        </section>
      )}

      {/* MVP priorities */}
      {blueprint.mvp_priorities?.length > 0 && (
        <section className={`${CARD} p-5`}>
          <div className="flex items-center gap-2.5 mb-3">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <h3 className="text-sm font-bold text-white">MVP Priorities</h3>
          </div>
          <ol className="space-y-2">
            {blueprint.mvp_priorities.map((m, i) => (
              <li key={i} className="flex items-start gap-2.5 text-sm text-slate-300">
                <span className="mt-0.5 w-6 h-6 shrink-0 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[11px] font-bold flex items-center justify-center">{i + 1}</span>
                {m}
              </li>
            ))}
          </ol>
        </section>
      )}

      {/* Roadmap */}
      {blueprint.personalized_roadmap?.length > 0 && (
        <section className={`${CARD} p-5 sm:p-6`}>
          <div className="flex items-center gap-2.5 mb-4">
            <div className="w-8 h-8 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
              <Map className="w-4 h-4 text-violet-400" />
            </div>
            <h3 className="text-sm font-bold text-white">Personalized Roadmap</h3>
          </div>
          <div className="space-y-5 sm:pl-3 sm:border-l sm:border-slate-800">
            {blueprint.personalized_roadmap.map((p, i) => (
              <div key={i}>
                <div className="flex items-center gap-2.5 mb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-violet-300 bg-violet-500/10 border border-violet-500/30 rounded-full px-2.5 py-0.5">
                    {p.phase ?? `Phase ${i + 1}`}
                  </span>
                  <span className="text-sm font-semibold text-white">{p.focus}</span>
                </div>
                <ul className="space-y-1.5">
                  {(p.actions ?? []).map((a, j) => (
                    <li key={j} className="flex items-start gap-2 text-sm text-slate-400">
                      <CheckCircle2 className="w-3.5 h-3.5 text-violet-400 mt-0.5 shrink-0" /> {a}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
