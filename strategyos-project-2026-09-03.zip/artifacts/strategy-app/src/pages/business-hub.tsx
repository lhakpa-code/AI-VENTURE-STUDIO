import { useParams, Link } from "wouter";
import {
  useGetBusiness, getGetBusinessQueryKey,
  useGetBusinessBriefing, getGetBusinessBriefingQueryKey,
  useListAssessments, getListAssessmentsQueryKey,
  useListStrategies, getListStrategiesQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  BrainCircuit, Route, Plus, ArrowLeft, Target, ArrowRight,
  ShieldAlert, TrendingUp, Activity, AlertTriangle, CheckCircle2,
  Flame, Zap, ChevronRight, BarChart2, Clock, Lightbulb,
} from "lucide-react";
import { format } from "date-fns";

const URGENCY_CONFIG = {
  high: {
    border: "border-red-500/40",
    bg: "bg-red-500/5",
    badge: "bg-red-500/15 text-red-400 border-red-500/30",
    dot: "bg-red-500",
    icon: Flame,
    iconClass: "text-red-400",
  },
  medium: {
    border: "border-amber-500/40",
    bg: "bg-amber-500/5",
    badge: "bg-amber-500/15 text-amber-400 border-amber-500/30",
    dot: "bg-amber-500",
    icon: AlertTriangle,
    iconClass: "text-amber-400",
  },
  low: {
    border: "border-border/40",
    bg: "bg-card/30",
    badge: "bg-muted/30 text-muted-foreground border-border/30",
    dot: "bg-muted-foreground",
    icon: ChevronRight,
    iconClass: "text-muted-foreground",
  },
};

export default function BusinessHub() {
  const params = useParams();
  const id = Number(params.id);

  const { data: business, isLoading: isBusinessLoading } = useGetBusiness(id, {
    query: { enabled: !!id, queryKey: getGetBusinessQueryKey(id) }
  });

  const { data: briefing, isLoading: isBriefingLoading } = useGetBusinessBriefing(id, {
    query: { enabled: !!id, queryKey: getGetBusinessBriefingQueryKey(id) }
  });

  const { data: assessments, isLoading: isAssessmentsLoading } = useListAssessments(id, {
    query: { enabled: !!id, queryKey: getListAssessmentsQueryKey(id) }
  });

  const { data: strategies, isLoading: isStrategiesLoading } = useListStrategies(id, {
    query: { enabled: !!id, queryKey: getListStrategiesQueryKey(id) }
  });

  if (isBusinessLoading || isBriefingLoading) {
    return (
      <div className="p-8 space-y-8 max-w-6xl mx-auto">
        <div className="h-12 w-64 bg-muted animate-pulse rounded" />
        <div className="h-40 bg-card animate-pulse rounded-xl" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => <div key={i} className="h-28 bg-card animate-pulse rounded-xl" />)}
        </div>
        <div className="h-[300px] bg-card animate-pulse rounded-xl" />
      </div>
    );
  }

  if (!business) return <div className="p-8">Business not found.</div>;

  const healthScore = briefing?.healthScore ?? 0;
  const executionRate = Math.round(briefing?.executionRate ?? 0);
  const healthColor =
    healthScore >= 70 ? "text-emerald-400" :
    healthScore >= 45 ? "text-amber-400" :
    "text-red-400";
  const healthRingColor =
    healthScore >= 70 ? "border-emerald-500/40" :
    healthScore >= 45 ? "border-amber-500/40" :
    "border-red-500/40";

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <Link href="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Portfolio
          </Link>
          <div className="flex items-center gap-3">
            <h1 className="text-4xl font-bold tracking-tight">{business.name}</h1>
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20 text-xs px-2 py-0.5 rounded font-mono uppercase tracking-wider">
              {business.stage}
            </Badge>
          </div>
          <p className="text-muted-foreground mt-2 max-w-2xl">
            {business.description || "No description provided."}
          </p>
        </div>
        <div className="flex gap-3 shrink-0">
          <Button asChild variant="outline" className="bg-card/50 backdrop-blur border-border/50 hover:bg-card">
            <Link href={`/businesses/${id}/assess`}>
              <BrainCircuit className="w-4 h-4 mr-2" />
              Re-assess
            </Link>
          </Button>
          <Button asChild className="bg-primary text-primary-foreground shadow-[0_0_15px_rgba(93,46,232,0.4)] hover:bg-primary/90">
            <Link href={`/businesses/${id}/strategies/new`}>
              <Route className="w-4 h-4 mr-2" />
              New Strategy
            </Link>
          </Button>
        </div>
      </div>

      {/* CSO BRIEFING — the centrepiece */}
      <Card className="bg-gradient-to-br from-primary/10 via-card/80 to-card border-primary/30 shadow-[0_0_30px_rgba(93,46,232,0.12)]">
        <CardContent className="p-6 md:p-8">
          <div className="flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0 mt-0.5">
              <BrainCircuit className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-3">
                <p className="text-xs font-semibold uppercase tracking-widest text-primary/70">
                  AI Chief Strategy Officer
                </p>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                <p className="text-xs text-muted-foreground">Active</p>
              </div>
              <p className="text-foreground leading-relaxed text-base">
                {briefing?.csoBriefingText ?? "Loading strategic briefing..."}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 4 Metric Tiles */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Health Score */}
        <Card className="bg-card/50 backdrop-blur border-border/50">
          <CardContent className="p-5 flex flex-col items-start gap-3">
            <div className="flex items-center gap-2 w-full justify-between">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Health Score</p>
              <Activity className="w-4 h-4 text-muted-foreground/50" />
            </div>
            <div className={`w-14 h-14 rounded-full border-4 ${healthRingColor} flex items-center justify-center`}>
              <span className={`text-xl font-bold font-mono ${healthColor}`}>{healthScore}</span>
            </div>
            <p className="text-xs text-muted-foreground leading-tight">
              {healthScore >= 70 ? "Strong position" : healthScore >= 45 ? "Needs attention" : "Critical stage"}
            </p>
          </CardContent>
        </Card>

        {/* Execution Rate */}
        <Card className="bg-card/50 backdrop-blur border-border/50">
          <CardContent className="p-5 flex flex-col gap-3">
            <div className="flex items-center gap-2 w-full justify-between">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Execution</p>
              <TrendingUp className="w-4 h-4 text-muted-foreground/50" />
            </div>
            <p className="text-3xl font-bold font-mono text-foreground">{executionRate}<span className="text-lg text-muted-foreground">%</span></p>
            <div className="space-y-1.5">
              <div className="w-full bg-background rounded-full h-1.5 overflow-hidden border border-border/50">
                <div
                  className={`h-full transition-all ${executionRate >= 70 ? 'bg-emerald-500' : executionRate >= 30 ? 'bg-primary' : 'bg-amber-500'}`}
                  style={{ width: `${executionRate}%` }}
                />
              </div>
              <p className="text-xs text-muted-foreground">
                {briefing?.completedMilestones ?? 0}/{briefing?.totalMilestones ?? 0} actions done
              </p>
            </div>
          </CardContent>
        </Card>

        {/* KPIs Measured */}
        <Card className="bg-card/50 backdrop-blur border-border/50">
          <CardContent className="p-5 flex flex-col gap-3">
            <div className="flex items-center gap-2 w-full justify-between">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">KPIs Logged</p>
              <BarChart2 className="w-4 h-4 text-muted-foreground/50" />
            </div>
            <p className="text-3xl font-bold font-mono text-foreground">
              {briefing?.kpisWithLogs ?? 0}
              <span className="text-lg text-muted-foreground ml-1">/ {(briefing?.kpisWithLogs ?? 0) + (briefing?.kpisPendingLog ?? 0)}</span>
            </p>
            <p className="text-xs text-muted-foreground leading-tight">
              {(briefing?.kpisPendingLog ?? 0) > 0
                ? <span className="text-amber-400">{briefing?.kpisPendingLog} KPI{briefing!.kpisPendingLog !== 1 ? "s" : ""} need a value logged</span>
                : "All KPIs measured"
              }
            </p>
          </CardContent>
        </Card>

        {/* Active Risks */}
        <Card className="bg-card/50 backdrop-blur border-border/50">
          <CardContent className="p-5 flex flex-col gap-3">
            <div className="flex items-center gap-2 w-full justify-between">
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium">Active Risks</p>
              <ShieldAlert className="w-4 h-4 text-muted-foreground/50" />
            </div>
            <p className={`text-3xl font-bold font-mono ${(briefing?.activeRisks ?? 0) > 0 ? 'text-red-400' : 'text-emerald-400'}`}>
              {briefing?.activeRisks ?? 0}
            </p>
            <p className="text-xs text-muted-foreground leading-tight">
              {(briefing?.riskRadar?.length ?? 0)} items on radar
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Priorities + Risk Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Priorities */}
        <Card className="bg-card/50 backdrop-blur border-border/50">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-primary" />
              <CardTitle className="text-base">This Week's Priorities</CardTitle>
            </div>
            <p className="text-xs text-muted-foreground">Actions I recommend you focus on right now</p>
          </CardHeader>
          <CardContent className="space-y-3">
            {!briefing?.weeklyPriorities?.length ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-emerald-500 opacity-60" />
                No pending priorities — all clear.
              </div>
            ) : (
              briefing.weeklyPriorities.map((p) => {
                const urgency = p.urgency as keyof typeof URGENCY_CONFIG;
                const cfg = URGENCY_CONFIG[urgency] ?? URGENCY_CONFIG.low;
                const Icon = cfg.icon;
                return (
                  <div key={p.milestoneId} className={`rounded-xl border p-4 ${cfg.border} ${cfg.bg}`}>
                    <div className="flex items-start gap-3">
                      <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${cfg.iconClass}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-medium leading-snug">{p.title}</p>
                          <Badge variant="outline" className={`text-[10px] shrink-0 ${cfg.badge}`}>
                            {urgency}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{p.reason}</p>
                        {(p.kpi || p.timeframe) && (
                          <div className="flex flex-wrap gap-2 mt-2">
                            {p.kpi && (
                              <span className="text-xs text-blue-300/80 bg-blue-500/10 border border-blue-500/20 rounded px-2 py-0.5">
                                KPI: {p.kpi}
                              </span>
                            )}
                            {p.timeframe && (
                              <span className="text-xs text-amber-300/80 bg-amber-500/10 border border-amber-500/20 rounded px-2 py-0.5">
                                {p.timeframe}
                              </span>
                            )}
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground/50 mt-1.5 uppercase tracking-wider font-mono">{p.pillarTitle}</p>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        {/* Risk Radar */}
        <Card className="bg-card/50 backdrop-blur border-border/50">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-primary" />
              <CardTitle className="text-base">Risk Radar</CardTitle>
            </div>
            <p className="text-xs text-muted-foreground">Threats and weaknesses I'm monitoring — with countermoves</p>
          </CardHeader>
          <CardContent className="space-y-3">
            {!briefing?.riskRadar?.length ? (
              <div className="text-center py-8 text-muted-foreground text-sm">
                <ShieldAlert className="w-8 h-8 mx-auto mb-2 opacity-30" />
                Run an assessment to populate the risk radar.
              </div>
            ) : (
              briefing.riskRadar.map((risk) => {
                const urgency = risk.urgency as keyof typeof URGENCY_CONFIG;
                const cfg = URGENCY_CONFIG[urgency] ?? URGENCY_CONFIG.low;
                return (
                  <div key={risk.id} className={`rounded-xl border p-4 ${cfg.border} ${cfg.bg}`}>
                    <div className="flex items-start gap-3">
                      <span className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${cfg.dot}`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className="text-sm font-medium leading-snug">{risk.text}</p>
                          <Badge variant="outline" className={`text-[10px] shrink-0 uppercase tracking-wider ${cfg.badge}`}>
                            {risk.category === "threat" ? "threat" : "weakness"}
                          </Badge>
                        </div>
                        {risk.countermove && (
                          <div className="flex items-start gap-1.5 mt-2">
                            <Lightbulb className="w-3 h-3 text-primary/60 mt-0.5 shrink-0" />
                            <p className="text-xs text-muted-foreground leading-relaxed">{risk.countermove}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>
      </div>

      {/* Strategies + Assessments Tabs */}
      <Tabs defaultValue="strategies" className="w-full">
        <TabsList className="bg-card/50 border border-border/50 p-1">
          <TabsTrigger value="strategies" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
            Active Strategies
          </TabsTrigger>
          <TabsTrigger value="assessments" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
            Assessments
          </TabsTrigger>
          <TabsTrigger value="profile" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary">
            Business Profile
          </TabsTrigger>
        </TabsList>

        <TabsContent value="strategies" className="mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold tracking-tight">Growth Roadmaps</h2>
            <Button asChild size="sm" className="bg-primary/10 text-primary hover:bg-primary/20 border border-primary/20">
              <Link href={`/businesses/${id}/strategies/new`}>
                <Plus className="w-4 h-4 mr-2" /> New Strategy
              </Link>
            </Button>
          </div>

          {isStrategiesLoading ? (
            <div className="space-y-4">
              {[1, 2].map(i => <div key={i} className="h-24 bg-card animate-pulse rounded-xl" />)}
            </div>
          ) : strategies?.length === 0 ? (
            <div className="text-center p-12 border border-dashed border-border/50 rounded-xl bg-card/20">
              <Route className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium">No strategies generated yet</h3>
              <p className="text-muted-foreground mt-2 max-w-sm mx-auto text-sm">
                Turn your SWOT insights into an actionable roadmap.
              </p>
              <Button asChild className="mt-4">
                <Link href={`/businesses/${id}/strategies/new`}>Generate First Strategy</Link>
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {strategies?.map((strategy) => (
                <Link key={strategy.id} href={`/strategies/${strategy.id}`}>
                  <Card className="group hover:border-primary/50 transition-colors cursor-pointer bg-card/50 backdrop-blur border-border/50">
                    <CardContent className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-1 group-hover:bg-primary/20 transition-colors">
                          <Target className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <h3 className="text-lg font-semibold">{strategy.title}</h3>
                          <p className="text-muted-foreground text-sm line-clamp-1 mt-1">
                            {strategy.overview || "Roadmap generated by StrategyOS."}
                          </p>
                          <p className="text-xs text-muted-foreground mt-2 font-mono uppercase tracking-wider">
                            {format(new Date(strategy.createdAt), "MMM d, yyyy")}
                          </p>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-primary transition-colors transform group-hover:translate-x-1 shrink-0" />
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="assessments" className="mt-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold tracking-tight">Intelligence Assessments</h2>
            <Button asChild size="sm" variant="outline">
              <Link href={`/businesses/${id}/assess`}>
                <BrainCircuit className="w-4 h-4 mr-2" /> Re-run Assessment
              </Link>
            </Button>
          </div>

          {isAssessmentsLoading ? (
            <div className="space-y-4">
              {[1, 2].map(i => <div key={i} className="h-24 bg-card animate-pulse rounded-xl" />)}
            </div>
          ) : assessments?.length === 0 ? (
            <div className="text-center p-12 border border-dashed border-border/50 rounded-xl bg-card/20">
              <BrainCircuit className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium">No assessments run</h3>
              <p className="text-muted-foreground mt-2 max-w-sm mx-auto text-sm">
                Run an AI assessment to uncover strengths, weaknesses, and opportunities.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {assessments?.map((assessment) => {
                const avgScore = assessment.strengthScore && assessment.weaknessScore && assessment.opportunityScore && assessment.threatScore
                  ? Math.round((assessment.strengthScore + assessment.weaknessScore + assessment.opportunityScore + assessment.threatScore) / 4)
                  : null;
                return (
                  <Link key={assessment.id} href={`/assessments/${assessment.id}`}>
                    <Card className="group hover:border-primary/50 transition-colors cursor-pointer bg-card/50 backdrop-blur border-border/50">
                      <CardContent className="p-6 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-full border-2 border-primary/20 flex items-center justify-center shrink-0 bg-background">
                            <span className="text-lg font-bold font-mono text-primary">{avgScore ?? '--'}</span>
                          </div>
                          <div>
                            <h3 className="font-semibold">Assessment Report</h3>
                            <p className="text-xs text-muted-foreground mt-1 font-mono uppercase tracking-wider">
                              {format(new Date(assessment.createdAt), "MMM d, yyyy • h:mm a")}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          {assessment.recommendations && (
                            <span>{assessment.recommendations.length} insights</span>
                          )}
                          <ArrowRight className="w-5 h-5 group-hover:text-primary transition-colors transform group-hover:translate-x-1" />
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="profile" className="mt-6">
          <Card className="bg-card/50 backdrop-blur border-border/50">
            <CardContent className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                { label: "Industry", value: business.industry },
                { label: "Stage", value: business.stage },
                { label: "Target Market", value: business.targetMarket },
                { label: "Team Size", value: business.teamSize },
                { label: "Revenue Range", value: business.revenueRange },
                { label: "Main Goal", value: business.mainGoal },
              ].map(({ label, value }) => (
                <div key={label}>
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium mb-1">{label}</p>
                  <p className="text-foreground font-medium">{value || "—"}</p>
                </div>
              ))}
              {business.description && (
                <div className="md:col-span-2">
                  <p className="text-xs text-muted-foreground uppercase tracking-wider font-medium mb-1">Description</p>
                  <p className="text-foreground leading-relaxed">{business.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
