import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import {
  Rocket, DollarSign, Presentation, Layout, Megaphone,
  ChevronRight, Loader2, AlertTriangle, ArrowLeft,
  TrendingUp, Users, Mail, Linkedin, Target, Zap,
  BarChart3, CheckCircle2, Code2, Globe, Building2,
  Clock, ChevronDown, Download,
} from "lucide-react";
import jsPDF from "jspdf";

// ── Helpers ───────────────────────────────────────────────────────────────────

/** AI responses occasionally return objects/arrays where a string is expected.
 *  Render them safely instead of crashing React. */
function asText(v: unknown): string {
  if (v == null) return "";
  if (typeof v === "string") return v;
  if (typeof v === "number" || typeof v === "boolean") return String(v);
  if (Array.isArray(v)) return v.map(asText).filter(Boolean).join(" • ");
  if (typeof v === "object") {
    return Object.entries(v as Record<string, unknown>)
      .map(([k, val]) => `${k.replace(/_/g, " ")}: ${asText(val)}`)
      .join(" • ");
  }
  return "";
}

const titleCase = (s: string) =>
  s.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());

/** Renders an AI text field in the Venture Kit style: plain strings as a
 *  paragraph; object answers (e.g. pricing tiers) as labeled sub-cards. */
function SmartText({ value }: { value: unknown }) {
  if (value == null) return null;
  if (typeof value === "object" && !Array.isArray(value)) {
    const entries = Object.entries(value as Record<string, unknown>);
    return (
      <div className="space-y-2">
        {entries.map(([k, v]) => (
          <div key={k} className="rounded-lg px-3 py-2.5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <p className="text-[11px] uppercase tracking-wider text-indigo-300 font-semibold mb-0.5">{titleCase(k)}</p>
            <p className="text-sm text-white/70 leading-relaxed">{asText(v)}</p>
          </div>
        ))}
      </div>
    );
  }
  if (Array.isArray(value)) {
    return (
      <ul className="space-y-1.5">
        {value.map((v, i) => (
          <li key={i} className="text-sm text-white/70 leading-relaxed">• {asText(v)}</li>
        ))}
      </ul>
    );
  }
  return <p className="text-sm text-white/70 leading-relaxed">{asText(value)}</p>;
}

// ── Types ─────────────────────────────────────────────────────────────────────

interface VentureInput {
  company_name: string;
  business_description: string;
  target_market: string;
  pricing_tier: string;
}

interface BusinessModel {
  recommended_model?: string;
  monetization_streams?: string[];
  pricing_strategy?: string;
  unit_economics?: string;
}

interface FinancialYear {
  revenue?: number;
  cogs?: number;
  opex?: number;
  net_profit?: number;
  paid_customers?: number;
}

interface FinancialModel {
  year_1?: FinancialYear;
  year_2?: FinancialYear;
  year_3?: FinancialYear;
  key_assumptions?: string[];
}

interface PitchSlide {
  slide_number?: number;
  title?: string;
  headline?: string;
  bullet_points?: string[];
}

interface PitchDeck {
  slides?: PitchSlide[];
  [key: string]: unknown;
}

interface KeyScreen {
  title?: string;
  components?: string[];
  key_actions?: string[];
}

interface PrototypeSpec {
  core_user_flow?: string[];
  key_screens?: KeyScreen[];
  html_mockup_snippet?: string;
}

interface ColdEmail {
  subject?: string;
  body?: string;
}

interface LinkedInMessage {
  message?: string;
  follow_up?: string;
}

interface GtmCampaign {
  ideal_customer_profile?: string;
  cold_email_sequence?: ColdEmail[];
  linkedin_outreach_sequence?: LinkedInMessage[];
  launch_channels?: string[];
}

interface VentureResults {
  businessModel?: BusinessModel;
  financialModel?: FinancialModel;
  pitchDeck?: PitchDeck;
  prototypeSpec?: PrototypeSpec;
  gtmCampaign?: GtmCampaign;
}

interface PipelineStatus {
  businessModel: "idle" | "loading" | "done" | "error";
  financialModel: "idle" | "loading" | "done" | "error";
  pitchDeck: "idle" | "loading" | "done" | "error";
  prototypeSpec: "idle" | "loading" | "done" | "error";
  gtmCampaign: "idle" | "loading" | "done" | "error";
}

interface SavedAnalysis {
  id: number;
  companyName: string;
  resultsJson: VentureResults;
  createdAt: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function fmt(n?: number) {
  if (n == null) return "—";
  if (Math.abs(n) >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}M`;
  if (Math.abs(n) >= 1_000) return `$${(n / 1_000).toFixed(0)}K`;
  return `$${n.toLocaleString()}`;
}

function fmtCustomers(n?: number) {
  if (n == null) return "—";
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toLocaleString();
}

function fmtRelativeTime(iso: string): string {
  const diffMs = Date.now() - new Date(iso).getTime();
  const diffMins = Math.floor(diffMs / 60_000);
  if (diffMins < 1) return "just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays < 7) return `${diffDays}d ago`;
  return new Date(iso).toLocaleDateString();
}

// ── Sub-components ────────────────────────────────────────────────────────────

function StatusDot({ status }: { status: "idle" | "loading" | "done" | "error" }) {
  if (status === "loading") return <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-400" />;
  if (status === "done")    return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />;
  if (status === "error")   return <AlertTriangle className="w-3.5 h-3.5 text-red-400" />;
  return <div className="w-3.5 h-3.5 rounded-full border border-white/20" />;
}

// ── Tab: Business Model ───────────────────────────────────────────────────────

function BusinessModelTab({ data }: { data?: BusinessModel }) {
  if (!data) return <EmptyTab label="Business Model" />;
  return (
    <div className="space-y-5">
      {data.recommended_model && (
        <div className="rounded-xl p-5" style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)" }}>
          <p className="text-xs text-indigo-400 font-semibold uppercase tracking-wider mb-1">Recommended Model</p>
          <p className="text-2xl font-bold text-white">{asText(data.recommended_model)}</p>
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {data.monetization_streams?.length && (
          <div className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <div className="flex items-center gap-2 mb-3">
              <DollarSign className="w-4 h-4 text-emerald-400" />
              <p className="text-sm font-semibold text-white">Monetization Streams</p>
            </div>
            <ul className="space-y-2">
              {data.monetization_streams.map((s, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                  <span className="mt-0.5 shrink-0 w-5 h-5 rounded-full bg-emerald-500/10 text-emerald-400 text-xs flex items-center justify-center font-bold">{i + 1}</span>
                  {asText(s)}
                </li>
              ))}
            </ul>
          </div>
        )}
        {data.pricing_strategy && (
          <div className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <div className="flex items-center gap-2 mb-3">
              <Target className="w-4 h-4 text-indigo-400" />
              <p className="text-sm font-semibold text-white">Pricing Strategy</p>
            </div>
            <SmartText value={data.pricing_strategy} />
          </div>
        )}
        {data.unit_economics && (
          <div className="rounded-xl p-5 md:col-span-2" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-amber-400" />
              <p className="text-sm font-semibold text-white">Unit Economics</p>
            </div>
            <SmartText value={data.unit_economics} />
          </div>
        )}
      </div>
    </div>
  );
}

// ── Tab: Financial Model ──────────────────────────────────────────────────────

function FinancialModelTab({ data }: { data?: FinancialModel }) {
  if (!data) return <EmptyTab label="Financial Model" />;
  const years = [
    { label: "Year 1", d: data.year_1 },
    { label: "Year 2", d: data.year_2 },
    { label: "Year 3", d: data.year_3 },
  ];
  const rows: { key: keyof FinancialYear; label: string; color: string }[] = [
    { key: "revenue",        label: "Revenue",         color: "text-emerald-400" },
    { key: "cogs",           label: "COGS",            color: "text-red-400" },
    { key: "opex",           label: "OpEx",            color: "text-amber-400" },
    { key: "net_profit",     label: "Net Profit",      color: "text-indigo-400" },
    { key: "paid_customers", label: "Paid Customers",  color: "text-white/80" },
  ];
  return (
    <div className="space-y-5">
      <div className="overflow-x-auto rounded-xl" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
        <table className="w-full text-sm">
          <thead>
            <tr style={{ background: "rgba(255,255,255,0.04)", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
              <th className="text-left px-5 py-3 text-white/40 font-medium w-40">Metric</th>
              {years.map(y => (
                <th key={y.label} className="text-right px-5 py-3 text-white/70 font-semibold">{y.label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, ri) => (
              <tr key={row.key} style={{ borderBottom: ri < rows.length - 1 ? "1px solid rgba(255,255,255,0.04)" : "none" }}>
                <td className="px-5 py-3.5 text-white/50 font-medium">{row.label}</td>
                {years.map(y => (
                  <td key={y.label} className={`px-5 py-3.5 text-right font-semibold tabular-nums ${row.color}`}>
                    {row.key === "paid_customers"
                      ? fmtCustomers(y.d?.[row.key] as number | undefined)
                      : fmt(y.d?.[row.key] as number | undefined)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {data.key_assumptions?.length && (
        <div className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <p className="text-sm font-semibold text-white mb-3">Key Assumptions</p>
          <ul className="space-y-2">
            {data.key_assumptions.map((a, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-white/70">
                <ChevronRight className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                {a}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

// ── Tab: Pitch Deck ───────────────────────────────────────────────────────────

function PitchDeckTab({ data }: { data?: PitchDeck }) {
  if (!data) return <EmptyTab label="Pitch Deck" />;
  const slides: PitchSlide[] = Array.isArray(data.slides)
    ? data.slides
    : (Object.values(data).find(v => Array.isArray(v)) as PitchSlide[] | undefined) ?? [];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
      {slides.map((slide, i) => (
        <div key={i} className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-3 mb-3">
            <span className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold text-indigo-300"
              style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.25)" }}>
              {slide.slide_number ?? i + 1}
            </span>
            <p className="text-sm font-semibold text-white/80">{slide.title}</p>
          </div>
          {slide.headline && (
            <p className="text-base font-bold text-white mb-3 leading-snug">{slide.headline}</p>
          )}
          {slide.bullet_points?.length && (
            <ul className="space-y-1.5">
              {slide.bullet_points.map((bp, j) => (
                <li key={j} className="flex items-start gap-2 text-sm text-white/60">
                  <span className="mt-2 w-1 h-1 rounded-full bg-indigo-400 shrink-0" />
                  {bp}
                </li>
              ))}
            </ul>
          )}
        </div>
      ))}
    </div>
  );
}

// ── Tab: Prototype Spec ───────────────────────────────────────────────────────

function PrototypeSpecTab({ data }: { data?: PrototypeSpec }) {
  const [showCode, setShowCode] = useState(false);
  if (!data) return <EmptyTab label="Prototype Spec" />;
  return (
    <div className="space-y-5">
      {data.core_user_flow?.length && (
        <div className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Zap className="w-4 h-4 text-amber-400" />
            <p className="text-sm font-semibold text-white">Core User Flow</p>
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            {data.core_user_flow.map((step, i) => (
              <div key={i} className="flex items-center gap-2">
                <div className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-white/80"
                  style={{ background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.08)" }}>
                  <span className="text-xs text-indigo-400 font-bold">{i + 1}</span>
                  {step}
                </div>
                {i < data.core_user_flow!.length - 1 && (
                  <ChevronRight className="w-3.5 h-3.5 text-white/20 shrink-0" />
                )}
              </div>
            ))}
          </div>
        </div>
      )}
      {data.key_screens?.length && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.key_screens.map((screen, i) => (
            <div key={i} className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
              <div className="flex items-center gap-2 mb-3">
                <Layout className="w-4 h-4 text-indigo-400" />
                <p className="text-sm font-semibold text-white">{screen.title ?? `Screen ${i + 1}`}</p>
              </div>
              {screen.components?.length && (
                <div className="mb-3">
                  <p className="text-xs text-white/30 uppercase tracking-wider mb-1.5">Components</p>
                  <ul className="space-y-1">
                    {screen.components.map((c, j) => (
                      <li key={j} className="text-xs text-white/60 flex items-start gap-1.5">
                        <span className="mt-1.5 w-1 h-1 rounded-full bg-white/30 shrink-0" />{c}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              {screen.key_actions?.length && (
                <div>
                  <p className="text-xs text-white/30 uppercase tracking-wider mb-1.5">Key Actions</p>
                  <ul className="space-y-1">
                    {screen.key_actions.map((a, j) => (
                      <li key={j} className="text-xs text-white/60 flex items-start gap-1.5">
                        <ChevronRight className="w-3 h-3 text-indigo-400 shrink-0 mt-0.5" />{a}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {data.html_mockup_snippet && (
        <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center justify-between px-4 py-3"
            style={{ background: "rgba(255,255,255,0.04)", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
            <div className="flex items-center gap-2">
              <Code2 className="w-4 h-4 text-indigo-400" />
              <p className="text-sm font-semibold text-white">Dashboard Wireframe</p>
            </div>
            <div className="flex gap-1.5 rounded-lg p-1" style={{ background: "rgba(255,255,255,0.05)" }}>
              {(["preview", "code"] as const).map(v => (
                <button key={v}
                  onClick={() => setShowCode(v === "code")}
                  className="px-2.5 py-1 rounded text-xs transition-all"
                  style={{ background: (showCode ? v === "code" : v === "preview") ? "rgba(255,255,255,0.1)" : "transparent",
                    color: (showCode ? v === "code" : v === "preview") ? "#fff" : "rgba(255,255,255,0.35)" }}>
                  {v.charAt(0).toUpperCase() + v.slice(1)}
                </button>
              ))}
            </div>
          </div>
          {showCode ? (
            <pre className="p-4 text-xs text-white/60 overflow-x-auto" style={{ background: "rgba(0,0,0,0.3)", maxHeight: 400 }}>
              {data.html_mockup_snippet}
            </pre>
          ) : (
            <iframe
              srcDoc={`<!DOCTYPE html><html><head><script src="https://cdn.tailwindcss.com"></script></head><body class="bg-gray-950 p-6">${data.html_mockup_snippet}</body></html>`}
              sandbox="allow-scripts"
              className="w-full border-0"
              style={{ height: 400, background: "#030712" }}
              title="Wireframe preview"
            />
          )}
        </div>
      )}
    </div>
  );
}

// ── Tab: GTM Campaign ─────────────────────────────────────────────────────────

function GtmCampaignTab({ data }: { data?: GtmCampaign }) {
  const [emailIdx, setEmailIdx] = useState(0);
  if (!data) return <EmptyTab label="GTM Campaign" />;
  const emails = data.cold_email_sequence ?? [];
  const linkedin = data.linkedin_outreach_sequence ?? [];
  return (
    <div className="space-y-5">
      {data.ideal_customer_profile && (
        <div className="rounded-xl p-5" style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)" }}>
          <div className="flex items-center gap-2 mb-2">
            <Users className="w-4 h-4 text-indigo-400" />
            <p className="text-sm font-semibold text-white">Ideal Customer Profile</p>
          </div>
          <p className="text-sm text-white/70 leading-relaxed">{data.ideal_customer_profile}</p>
        </div>
      )}
      {data.launch_channels?.length && (
        <div className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-2 mb-3">
            <Rocket className="w-4 h-4 text-emerald-400" />
            <p className="text-sm font-semibold text-white">Top Launch Channels</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {data.launch_channels.map((c, i) => (
              <span key={i} className="rounded-lg px-3 py-1.5 text-sm text-emerald-300 font-medium"
                style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.2)" }}>
                #{i + 1} {c}
              </span>
            ))}
          </div>
        </div>
      )}
      {emails.length > 0 && (
        <div className="rounded-xl overflow-hidden" style={{ border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-3 px-5 py-3.5"
            style={{ background: "rgba(255,255,255,0.04)", borderBottom: "1px solid rgba(255,255,255,0.07)" }}>
            <Mail className="w-4 h-4 text-blue-400" />
            <p className="text-sm font-semibold text-white flex-1">Cold Email Sequence</p>
            <div className="flex gap-1">
              {emails.map((_, i) => (
                <button key={i} onClick={() => setEmailIdx(i)}
                  className="px-2.5 py-1 rounded text-xs transition-all"
                  style={{ background: emailIdx === i ? "rgba(99,102,241,0.3)" : "rgba(255,255,255,0.05)",
                    color: emailIdx === i ? "#a5b4fc" : "rgba(255,255,255,0.35)",
                    border: `1px solid ${emailIdx === i ? "rgba(99,102,241,0.4)" : "rgba(255,255,255,0.08)"}` }}>
                  Email {i + 1}
                </button>
              ))}
            </div>
          </div>
          <div className="p-5">
            {emails[emailIdx] && (
              <>
                {emails[emailIdx].subject && (
                  <div className="mb-4">
                    <p className="text-xs text-white/30 uppercase tracking-wider mb-1">Subject Line</p>
                    <p className="text-sm font-semibold text-white">{emails[emailIdx].subject}</p>
                  </div>
                )}
                {emails[emailIdx].body && (
                  <div>
                    <p className="text-xs text-white/30 uppercase tracking-wider mb-1">Body</p>
                    <p className="text-sm text-white/70 leading-relaxed whitespace-pre-line">{emails[emailIdx].body}</p>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      )}
      {linkedin.length > 0 && (
        <div className="rounded-xl p-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}>
          <div className="flex items-center gap-2 mb-4">
            <Linkedin className="w-4 h-4 text-blue-400" />
            <p className="text-sm font-semibold text-white">LinkedIn Outreach</p>
          </div>
          <div className="space-y-4">
            {linkedin.map((msg, i) => (
              <div key={i} className="rounded-lg p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <p className="text-xs text-indigo-400 font-semibold uppercase tracking-wider mb-2">
                  {i === 0 ? "Connection Request" : "Follow-up"}
                </p>
                {msg.message && <p className="text-sm text-white/70 mb-2 leading-relaxed">{msg.message}</p>}
                {msg.follow_up && (
                  <>
                    <p className="text-xs text-white/30 uppercase tracking-wider mb-1">Follow-up</p>
                    <p className="text-sm text-white/60 leading-relaxed">{msg.follow_up}</p>
                  </>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ── Empty state ───────────────────────────────────────────────────────────────

function EmptyTab({ label }: { label: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="w-12 h-12 rounded-xl flex items-center justify-center mb-3"
        style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
        <Loader2 className="w-5 h-5 text-white/20" />
      </div>
      <p className="text-white/30 text-sm">{label} not generated yet</p>
    </div>
  );
}

// ── Saved Analyses Panel ──────────────────────────────────────────────────────

function SavedAnalysesPanel({
  analyses,
  loading,
  onSelect,
}: {
  analyses: SavedAnalysis[];
  loading: boolean;
  onSelect: (a: SavedAnalysis) => void;
}) {
  const [open, setOpen] = useState(true);

  return (
    <div className="rounded-2xl overflow-hidden" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
      <button
        onClick={() => setOpen(v => !v)}
        className="w-full flex items-center justify-between px-5 py-4 text-left"
        style={{ borderBottom: open ? "1px solid rgba(255,255,255,0.07)" : "none" }}
      >
        <div className="flex items-center gap-2">
          <Clock className="w-4 h-4 text-indigo-400" />
          <span className="text-sm font-semibold text-white">Saved Analyses</span>
          {!loading && analyses.length > 0 && (
            <span className="rounded-full px-2 py-0.5 text-xs font-medium text-indigo-300"
              style={{ background: "rgba(99,102,241,0.2)" }}>
              {analyses.length}
            </span>
          )}
        </div>
        <ChevronDown
          className="w-4 h-4 text-white/30 transition-transform"
          style={{ transform: open ? "rotate(180deg)" : "rotate(0deg)" }}
        />
      </button>

      {open && (
        <div className="divide-y" style={{ "--tw-divide-opacity": 1 } as React.CSSProperties}>
          {loading && (
            <div className="px-5 py-6 flex items-center justify-center">
              <Loader2 className="w-4 h-4 animate-spin text-white/30" />
            </div>
          )}
          {!loading && analyses.length === 0 && (
            <div className="px-5 py-6 text-center">
              <p className="text-sm text-white/25">No saved analyses yet. Run your first venture analysis above.</p>
            </div>
          )}
          {!loading && analyses.map(a => (
            <button
              key={a.id}
              onClick={() => onSelect(a)}
              className="w-full flex items-center justify-between px-5 py-3.5 text-left transition-all group"
              style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}
              onMouseEnter={e => (e.currentTarget.style.background = "rgba(99,102,241,0.07)")}
              onMouseLeave={e => (e.currentTarget.style.background = "transparent")}
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0"
                  style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.25)" }}>
                  <Rocket className="w-3.5 h-3.5 text-indigo-400" />
                </div>
                <div className="min-w-0">
                  <p className="text-sm font-medium text-white truncate">{a.companyName}</p>
                  <p className="text-xs text-white/35 mt-0.5">{fmtRelativeTime(a.createdAt)}</p>
                </div>
              </div>
              <ChevronRight className="w-3.5 h-3.5 text-white/20 group-hover:text-indigo-400 transition-colors shrink-0 ml-2" />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────

const TABS = [
  { key: "businessModel",  label: "Business Model",  icon: Building2 },
  { key: "financialModel", label: "Financials",       icon: BarChart3 },
  { key: "pitchDeck",      label: "Pitch Deck",       icon: Presentation },
  { key: "prototypeSpec",  label: "Prototype",        icon: Layout },
  { key: "gtmCampaign",    label: "GTM Campaign",     icon: Megaphone },
] as const;

type TabKey = typeof TABS[number]["key"];

export default function VentureStudio() {
  const [, navigate] = useLocation();

  const [input, setInput] = useState<VentureInput>({
    company_name: "",
    business_description: "",
    target_market: "",
    pricing_tier: "Subscription SaaS",
  });

  const [status, setStatus] = useState<PipelineStatus>({
    businessModel: "idle", financialModel: "idle",
    pitchDeck: "idle",     prototypeSpec: "idle",
    gtmCampaign: "idle",
  });

  const [results, setResults] = useState<VentureResults>({});
  const [activeTab, setActiveTab] = useState<TabKey>("businessModel");
  const [hasRun, setHasRun] = useState(false);
  const [savedLabel, setSavedLabel] = useState<string | null>(null);

  // History
  const [analyses, setAnalyses] = useState<SavedAnalysis[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);

  const fetchHistory = useCallback(async () => {
    try {
      const res = await fetch("/api/venture/history");
      if (res.ok) setAnalyses(await res.json());
    } catch {
      // silently ignore
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  const isRunning = Object.values(status).some(s => s === "loading");
  const allDone   = hasRun && Object.values(status).every(s => s === "done" || s === "error");

  async function saveAnalysis(companyName: string, finalResults: VentureResults) {
    try {
      await fetch("/api/venture/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ companyName, results: finalResults }),
      });
      setSavedLabel("Saved ✓");
      setTimeout(() => setSavedLabel(null), 3000);
      await fetchHistory();
    } catch {
      // silently ignore save errors
    }
  }

  async function runPipeline() {
    if (!input.company_name.trim() || !input.business_description.trim() || !input.target_market.trim()) return;
    setHasRun(true);
    setSavedLabel(null);

    // Reset
    setStatus({ businessModel: "loading", financialModel: "loading", pitchDeck: "loading", prototypeSpec: "loading", gtmCampaign: "loading" });
    setResults({});

    const body = JSON.stringify(input);
    const headers = { "Content-Type": "application/json" };
    const collected: VentureResults = {};

    async function call(endpoint: string, key: keyof VentureResults, statusKey: keyof PipelineStatus) {
      try {
        const res = await fetch(`/api/venture/${endpoint}`, { method: "POST", headers, body });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        collected[key] = data as any;
        setResults(prev => ({ ...prev, [key]: data }));
        setStatus(prev => ({ ...prev, [statusKey]: "done" }));
      } catch {
        setStatus(prev => ({ ...prev, [statusKey]: "error" }));
      }
    }

    // Fire all 5 in parallel
    await Promise.all([
      call("business-model",  "businessModel",  "businessModel"),
      call("financial-model", "financialModel", "financialModel"),
      call("pitch-deck",      "pitchDeck",      "pitchDeck"),
      call("prototype-spec",  "prototypeSpec",  "prototypeSpec"),
      call("gtm-campaign",    "gtmCampaign",    "gtmCampaign"),
    ]);

    // Auto-save if at least one tab succeeded
    const anySuccess = Object.values(collected).some(v => v != null);
    if (anySuccess) {
      await saveAnalysis(input.company_name, collected);
    }
  }

  function restoreAnalysis(a: SavedAnalysis) {
    setResults(a.resultsJson);
    setStatus({
      businessModel:  a.resultsJson.businessModel  ? "done" : "error",
      financialModel: a.resultsJson.financialModel ? "done" : "error",
      pitchDeck:      a.resultsJson.pitchDeck      ? "done" : "error",
      prototypeSpec:  a.resultsJson.prototypeSpec  ? "done" : "error",
      gtmCampaign:    a.resultsJson.gtmCampaign    ? "done" : "error",
    });
    setHasRun(true);
    setActiveTab("businessModel");
    setInput(prev => ({ ...prev, company_name: a.companyName }));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const canRun = input.company_name.trim() && input.business_description.trim() && input.target_market.trim();

  const [exporting, setExporting] = useState(false);

  async function exportPDF() {
    setExporting(true);
    try {
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageW = 210;
      const pageH = 297;
      const margin = 18;
      const contentW = pageW - margin * 2;
      let y = margin;

      // ── colour palette ──────────────────────────────────────────────────────
      const INDIGO  = [79, 70, 229]  as [number, number, number];
      const DARK    = [15, 23, 42]   as [number, number, number];
      const MID     = [51, 65, 85]   as [number, number, number];
      const LIGHT   = [148, 163, 184] as [number, number, number];
      const WHITE   = [255, 255, 255] as [number, number, number];
      const EMERALD = [16, 185, 129] as [number, number, number];
      const AMBER   = [245, 158, 11] as [number, number, number];

      const companyName = input.company_name || "Venture";

      // ── helpers ─────────────────────────────────────────────────────────────
      function checkPage(needed = 10) {
        if (y + needed > pageH - margin) {
          doc.addPage();
          y = margin;
          drawPageBg();
        }
      }

      function drawPageBg() {
        doc.setFillColor(...DARK);
        doc.rect(0, 0, pageW, pageH, "F");
      }

      function sectionHeading(title: string, icon: string) {
        checkPage(16);
        // pill background
        doc.setFillColor(...INDIGO);
        doc.roundedRect(margin, y, contentW, 10, 2, 2, "F");
        doc.setTextColor(...WHITE);
        doc.setFontSize(9);
        doc.setFont("helvetica", "bold");
        doc.text(`${icon}  ${title.toUpperCase()}`, margin + 4, y + 6.5);
        y += 14;
      }

      function subHeading(title: string) {
        checkPage(8);
        doc.setTextColor(...INDIGO);
        doc.setFontSize(8);
        doc.setFont("helvetica", "bold");
        doc.text(title.toUpperCase(), margin, y);
        y += 5;
      }

      function bodyText(text: string, indent = 0) {
        doc.setTextColor(...LIGHT);
        doc.setFontSize(8.5);
        doc.setFont("helvetica", "normal");
        const lines = doc.splitTextToSize(text, contentW - indent);
        for (const line of lines) {
          checkPage(5);
          doc.text(line, margin + indent, y);
          y += 4.5;
        }
      }

      function bullet(text: string, color: [number, number, number] = EMERALD) {
        checkPage(5);
        doc.setFillColor(...color);
        doc.circle(margin + 2.5, y - 1.5, 1, "F");
        doc.setTextColor(...LIGHT);
        doc.setFontSize(8.5);
        doc.setFont("helvetica", "normal");
        const lines = doc.splitTextToSize(text, contentW - 8);
        doc.text(lines[0], margin + 6, y);
        y += 4.5;
        for (let i = 1; i < lines.length; i++) {
          checkPage(5);
          doc.text(lines[i], margin + 6, y);
          y += 4.5;
        }
      }

      function spacer(h = 4) { y += h; }

      function keyValue(key: string, value: string) {
        checkPage(6);
        doc.setTextColor(...MID);
        doc.setFontSize(7.5);
        doc.setFont("helvetica", "bold");
        doc.text(key + ":", margin, y);
        doc.setTextColor(...LIGHT);
        doc.setFont("helvetica", "normal");
        const val = doc.splitTextToSize(value, contentW - 30);
        doc.text(val[0], margin + 30, y);
        y += 4.5;
        for (let i = 1; i < val.length; i++) {
          checkPage(5);
          doc.text(val[i], margin + 30, y);
          y += 4.5;
        }
      }

      // ── Cover page ───────────────────────────────────────────────────────────
      drawPageBg();

      // hero gradient strip
      doc.setFillColor(49, 46, 129);
      doc.rect(0, 0, pageW, 70, "F");

      // logo circle
      doc.setFillColor(...INDIGO);
      doc.circle(pageW / 2, 32, 14, "F");
      doc.setTextColor(...WHITE);
      doc.setFontSize(18);
      doc.setFont("helvetica", "bold");
      doc.text("VS", pageW / 2, 35, { align: "center" });

      // title
      doc.setFontSize(22);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(...WHITE);
      doc.text(companyName, pageW / 2, 82, { align: "center" });

      doc.setFontSize(11);
      doc.setTextColor(...LIGHT);
      doc.setFont("helvetica", "normal");
      doc.text("Venture Studio Kit", pageW / 2, 91, { align: "center" });

      // divider
      doc.setDrawColor(...INDIGO);
      doc.setLineWidth(0.5);
      doc.line(margin + 20, 97, pageW - margin - 20, 97);

      // meta
      doc.setFontSize(8);
      doc.setTextColor(...MID);
      const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
      doc.text(`Generated ${date}  ·  5-Section Venture Analysis`, pageW / 2, 104, { align: "center" });

      // table of contents
      y = 118;
      const sections = [
        "1.  Business Model",
        "2.  Financial Projections",
        "3.  Pitch Deck Outline",
        "4.  Prototype Specification",
        "5.  Go-To-Market Campaign",
      ];
      doc.setFontSize(8.5);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(...LIGHT);
      doc.text("Contents", pageW / 2, y, { align: "center" });
      y += 6;
      doc.setFont("helvetica", "normal");
      doc.setTextColor(...MID);
      for (const s of sections) {
        doc.text(s, pageW / 2, y, { align: "center" });
        y += 5.5;
      }

      // ── Section 1: Business Model ────────────────────────────────────────────
      doc.addPage(); drawPageBg(); y = margin;
      sectionHeading("1. Business Model", "◈");

      const bm = results.businessModel;
      if (bm) {
        if (bm.recommended_model) {
          subHeading("Recommended Model");
          doc.setTextColor(...WHITE);
          doc.setFontSize(13);
          doc.setFont("helvetica", "bold");
          checkPage(8);
          doc.text(bm.recommended_model, margin, y);
          y += 8;
        }
        if (bm.pricing_strategy) {
          subHeading("Pricing Strategy");
          bodyText(bm.pricing_strategy);
          spacer(3);
        }
        if (bm.unit_economics) {
          subHeading("Unit Economics");
          bodyText(bm.unit_economics);
          spacer(3);
        }
        if (bm.monetization_streams?.length) {
          subHeading("Monetization Streams");
          for (const s of bm.monetization_streams) bullet(s, EMERALD);
          spacer(3);
        }
      } else {
        bodyText("Business model data not available.");
      }

      // ── Section 2: Financial Model ───────────────────────────────────────────
      checkPage(20); spacer(6);
      sectionHeading("2. Financial Projections", "◈");

      const fm = results.financialModel;
      if (fm) {
        // Table header
        checkPage(30);
        const colX = [margin, margin + 40, margin + 80, margin + 120];
        const colHeaders = ["Metric", "Year 1", "Year 2", "Year 3"];
        doc.setFillColor(30, 41, 59);
        doc.rect(margin, y, contentW, 8, "F");
        doc.setTextColor(...LIGHT);
        doc.setFontSize(8);
        doc.setFont("helvetica", "bold");
        colHeaders.forEach((h, i) => doc.text(h, colX[i] + (i === 0 ? 2 : 0), y + 5.5));
        y += 9;

        const years = [fm.year_1, fm.year_2, fm.year_3];
        const rows: { label: string; key: keyof FinancialYear; color: [number,number,number]; formatter: (n?: number) => string }[] = [
          { label: "Revenue",        key: "revenue",        color: EMERALD, formatter: fmt },
          { label: "COGS",           key: "cogs",           color: [239,68,68], formatter: fmt },
          { label: "OpEx",           key: "opex",           color: AMBER, formatter: fmt },
          { label: "Net Profit",     key: "net_profit",     color: INDIGO, formatter: fmt },
          { label: "Paid Customers", key: "paid_customers", color: LIGHT, formatter: fmtCustomers },
        ];
        rows.forEach((row, ri) => {
          checkPage(8);
          if (ri % 2 === 0) {
            doc.setFillColor(21, 32, 50);
            doc.rect(margin, y - 0.5, contentW, 7.5, "F");
          }
          doc.setTextColor(...LIGHT);
          doc.setFontSize(8);
          doc.setFont("helvetica", "normal");
          doc.text(row.label, colX[0] + 2, y + 4.5);
          doc.setTextColor(...row.color);
          doc.setFont("helvetica", "bold");
          years.forEach((yr, yi) => {
            const val = yr?.[row.key] as number | undefined;
            doc.text(row.formatter(val), colX[yi + 1], y + 4.5);
          });
          y += 8;
        });
        spacer(4);

        if (fm.key_assumptions?.length) {
          subHeading("Key Assumptions");
          for (const a of fm.key_assumptions) bullet(a, INDIGO);
        }
      } else {
        bodyText("Financial model data not available.");
      }

      // ── Section 3: Pitch Deck ────────────────────────────────────────────────
      doc.addPage(); drawPageBg(); y = margin;
      sectionHeading("3. Pitch Deck Outline", "◈");

      const pd = results.pitchDeck;
      if (pd) {
        const slides: PitchSlide[] = Array.isArray(pd.slides)
          ? pd.slides
          : (Object.values(pd).find(v => Array.isArray(v)) as PitchSlide[] | undefined) ?? [];

        for (const slide of slides) {
          checkPage(16);
          // slide number badge
          doc.setFillColor(49, 46, 129);
          doc.roundedRect(margin, y, 8, 6, 1, 1, "F");
          doc.setTextColor(...WHITE);
          doc.setFontSize(7);
          doc.setFont("helvetica", "bold");
          doc.text(String(slide.slide_number ?? ""), margin + 4, y + 4.3, { align: "center" });

          doc.setTextColor(...WHITE);
          doc.setFontSize(9);
          doc.setFont("helvetica", "bold");
          doc.text(slide.title ?? "", margin + 11, y + 4.3);
          y += 8;

          if (slide.headline) {
            doc.setTextColor(...LIGHT);
            doc.setFontSize(8.5);
            doc.setFont("helvetica", "italic");
            const lines = doc.splitTextToSize(slide.headline, contentW - 4);
            for (const l of lines) { checkPage(5); doc.text(l, margin + 2, y); y += 4.5; }
          }
          if (slide.bullet_points?.length) {
            for (const bp of slide.bullet_points) bullet(bp, INDIGO);
          }
          spacer(3);
        }
      } else {
        bodyText("Pitch deck data not available.");
      }

      // ── Section 4: Prototype Spec ────────────────────────────────────────────
      doc.addPage(); drawPageBg(); y = margin;
      sectionHeading("4. Prototype Specification", "◈");

      const ps = results.prototypeSpec;
      if (ps) {
        if (ps.core_user_flow?.length) {
          subHeading("Core User Flow");
          const steps = ps.core_user_flow.map((s, i) => `${i + 1}. ${s}`).join("  →  ");
          bodyText(steps);
          spacer(3);
        }
        if (ps.key_screens?.length) {
          subHeading("Key Screens");
          for (const screen of ps.key_screens) {
            checkPage(10);
            doc.setTextColor(...WHITE);
            doc.setFontSize(8.5);
            doc.setFont("helvetica", "bold");
            doc.text(screen.title ?? "Screen", margin, y);
            y += 5;
            if (screen.components?.length) {
              doc.setTextColor(...MID);
              doc.setFontSize(7.5);
              doc.setFont("helvetica", "bold");
              doc.text("Components:", margin + 2, y);
              y += 4;
              for (const c of screen.components) bullet(c, INDIGO);
            }
            if (screen.key_actions?.length) {
              doc.setTextColor(...MID);
              doc.setFontSize(7.5);
              doc.setFont("helvetica", "bold");
              checkPage(5);
              doc.text("Actions:", margin + 2, y);
              y += 4;
              for (const a of screen.key_actions) bullet(a, AMBER);
            }
            spacer(3);
          }
        }
      } else {
        bodyText("Prototype specification not available.");
      }

      // ── Section 5: GTM Campaign ──────────────────────────────────────────────
      doc.addPage(); drawPageBg(); y = margin;
      sectionHeading("5. Go-To-Market Campaign", "◈");

      const gtm = results.gtmCampaign;
      if (gtm) {
        if (gtm.ideal_customer_profile) {
          subHeading("Ideal Customer Profile");
          bodyText(gtm.ideal_customer_profile);
          spacer(3);
        }
        if (gtm.launch_channels?.length) {
          subHeading("Top Launch Channels");
          for (const c of gtm.launch_channels) bullet(c, EMERALD);
          spacer(3);
        }
        if (gtm.cold_email_sequence?.length) {
          subHeading("Cold Email Sequence");
          for (let i = 0; i < gtm.cold_email_sequence.length; i++) {
            const email = gtm.cold_email_sequence[i];
            checkPage(12);
            keyValue(`Email ${i + 1} Subject`, email.subject ?? "");
            if (email.body) bodyText(email.body, 6);
            spacer(3);
          }
        }
        if (gtm.linkedin_outreach_sequence?.length) {
          subHeading("LinkedIn Outreach");
          for (let i = 0; i < gtm.linkedin_outreach_sequence.length; i++) {
            const msg = gtm.linkedin_outreach_sequence[i];
            const label = i === 0 ? "Connection Request" : "Follow-up";
            checkPage(10);
            doc.setTextColor(...INDIGO);
            doc.setFontSize(8);
            doc.setFont("helvetica", "bold");
            doc.text(label, margin, y);
            y += 4.5;
            if (msg.message) bodyText(msg.message, 4);
            if (msg.follow_up) { bodyText("Follow-up: " + msg.follow_up, 4); }
            spacer(3);
          }
        }
      } else {
        bodyText("GTM campaign data not available.");
      }

      // ── Footer on every page ─────────────────────────────────────────────────
      const totalPages = (doc as any).internal.getNumberOfPages();
      for (let p = 1; p <= totalPages; p++) {
        doc.setPage(p);
        doc.setFillColor(20, 30, 50);
        doc.rect(0, pageH - 10, pageW, 10, "F");
        doc.setTextColor(...MID);
        doc.setFontSize(7);
        doc.setFont("helvetica", "normal");
        doc.text(`${companyName} · Venture Studio Kit`, margin, pageH - 3.5);
        doc.text(`${p} / ${totalPages}`, pageW - margin, pageH - 3.5, { align: "right" });
      }

      const slug = companyName.replace(/\s+/g, "-").replace(/[^a-zA-Z0-9-]/g, "");
      doc.save(`${slug}-venture-kit.pdf`);
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="min-h-screen" style={{ background: "#080c14" }}>

      {/* ── Header ── */}
      <header className="flex items-center justify-between px-6 py-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="flex items-center gap-3">
          <button onClick={() => navigate("/")}
            className="flex items-center gap-1.5 text-sm text-white/40 hover:text-white/70 transition-colors">
            <ArrowLeft className="w-4 h-4" />Back
          </button>
          <span className="text-white/15">|</span>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: "rgba(99,102,241,0.2)", border: "1px solid rgba(99,102,241,0.35)" }}>
              <Rocket className="w-4 h-4 text-indigo-400" />
            </div>
            <span className="text-white font-semibold text-sm">Venture Studio</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {savedLabel && (
            <span className="text-xs font-medium text-emerald-400 flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {savedLabel}
            </span>
          )}
          {allDone && (
            <button
              onClick={exportPDF}
              disabled={exporting}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all"
              style={{
                background: exporting ? "rgba(255,255,255,0.05)" : "rgba(99,102,241,0.2)",
                border: "1px solid rgba(99,102,241,0.35)",
                color: exporting ? "rgba(255,255,255,0.25)" : "#a5b4fc",
                cursor: exporting ? "not-allowed" : "pointer",
              }}
              onMouseEnter={e => { if (!exporting) e.currentTarget.style.background = "rgba(99,102,241,0.35)"; }}
              onMouseLeave={e => { if (!exporting) e.currentTarget.style.background = "rgba(99,102,241,0.2)"; }}
            >
              {exporting
                ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                : <Download className="w-3.5 h-3.5" />}
              {exporting ? "Exporting…" : "Export PDF"}
            </button>
          )}
          <div className="flex items-center gap-2 rounded-full px-3 py-1"
            style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}>
            <Globe className="w-3.5 h-3.5 text-indigo-400" />
            <span className="text-xs text-white/50 font-medium">5-Agent Pipeline</span>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-10 space-y-8">

        {/* ── Hero ── */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-white">AI Venture Studio</h1>
          <p className="text-white/40 max-w-xl mx-auto">
            Enter your venture and five specialist AI agents build your full business kit — model, financials, pitch deck, prototype, and GTM — simultaneously.
          </p>
        </div>

        {/* ── Input form ── */}
        <div className="rounded-2xl p-6 space-y-5" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)" }}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs text-white/40 font-medium uppercase tracking-wider mb-2">Company / Venture Name</label>
              <input
                value={input.company_name}
                onChange={e => setInput(p => ({ ...p, company_name: e.target.value }))}
                placeholder="e.g. Acme AI, NovaTech, PulseHealth"
                className="w-full rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
                onFocus={e => (e.currentTarget.style.borderColor = "rgba(99,102,241,0.5)")}
                onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
              />
            </div>
            <div>
              <label className="block text-xs text-white/40 font-medium uppercase tracking-wider mb-2">Target Market</label>
              <input
                value={input.target_market}
                onChange={e => setInput(p => ({ ...p, target_market: e.target.value }))}
                placeholder="e.g. Series B SaaS founders, SMBs in healthcare"
                className="w-full rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 outline-none transition-all"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
                onFocus={e => (e.currentTarget.style.borderColor = "rgba(99,102,241,0.5)")}
                onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
              />
            </div>
          </div>
          <div>
            <label className="block text-xs text-white/40 font-medium uppercase tracking-wider mb-2">Business Description</label>
            <textarea
              value={input.business_description}
              onChange={e => setInput(p => ({ ...p, business_description: e.target.value }))}
              placeholder="Describe what the business does, the core problem it solves, and its primary value proposition..."
              rows={3}
              className="w-full rounded-xl px-4 py-3 text-sm text-white placeholder-white/20 outline-none resize-none transition-all"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
              onFocus={e => (e.currentTarget.style.borderColor = "rgba(99,102,241,0.5)")}
              onBlur={e => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
            />
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex-1">
              <label className="block text-xs text-white/40 font-medium uppercase tracking-wider mb-2">Pricing Model</label>
              <select
                value={input.pricing_tier}
                onChange={e => setInput(p => ({ ...p, pricing_tier: e.target.value }))}
                className="w-full rounded-xl px-4 py-3 text-sm text-white/80 outline-none transition-all"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)" }}
              >
                {["Subscription SaaS", "Usage-Based", "Freemium", "Marketplace", "Enterprise Licensing", "Transactional"].map(t => (
                  <option key={t} value={t} style={{ background: "#1e293b" }}>{t}</option>
                ))}
              </select>
            </div>
            <button
              onClick={runPipeline}
              disabled={!canRun || isRunning}
              className="flex items-center justify-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white transition-all mt-auto"
              style={{ background: canRun && !isRunning ? "#4f46e5" : "rgba(255,255,255,0.07)",
                color: canRun && !isRunning ? "#fff" : "rgba(255,255,255,0.25)",
                cursor: canRun && !isRunning ? "pointer" : "not-allowed" }}
              onMouseEnter={e => { if (canRun && !isRunning) e.currentTarget.style.background = "#4338ca"; }}
              onMouseLeave={e => { if (canRun && !isRunning) e.currentTarget.style.background = "#4f46e5"; }}
            >
              {isRunning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Rocket className="w-4 h-4" />}
              {isRunning ? "Running 5 agents…" : "Run Venture Analysis"}
            </button>
          </div>
        </div>

        {/* ── Pipeline progress (shown while running or done) ── */}
        {hasRun && (
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {TABS.map(tab => {
              const s = status[tab.key];
              return (
                <div key={tab.key} className="rounded-xl p-3 flex flex-col items-center gap-2 text-center"
                  style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${s === "done" ? "rgba(16,185,129,0.2)" : s === "error" ? "rgba(239,68,68,0.2)" : "rgba(255,255,255,0.07)"}` }}>
                  <StatusDot status={s} />
                  <span className="text-xs text-white/50">{tab.label}</span>
                </div>
              );
            })}
          </div>
        )}

        {/* ── Results tabs ── */}
        {hasRun && (
          <div className="rounded-2xl overflow-hidden" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)" }}>
            {/* Tab bar */}
            <div className="flex overflow-x-auto" style={{ borderBottom: "1px solid rgba(255,255,255,0.07)", background: "rgba(255,255,255,0.02)" }}>
              {TABS.map(tab => {
                const s = status[tab.key];
                const active = activeTab === tab.key;
                return (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className="flex items-center gap-2 px-4 py-3.5 text-sm font-medium transition-all whitespace-nowrap shrink-0"
                    style={{
                      color: active ? "#fff" : "rgba(255,255,255,0.35)",
                      borderBottom: active ? "2px solid #6366f1" : "2px solid transparent",
                      background: active ? "rgba(99,102,241,0.06)" : "transparent",
                    }}
                  >
                    <tab.icon className="w-3.5 h-3.5" />
                    {tab.label}
                    {s === "done"    && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 ml-1" />}
                    {s === "loading" && <Loader2 className="w-3 h-3 animate-spin ml-1 text-indigo-400" />}
                    {s === "error"   && <span className="w-1.5 h-1.5 rounded-full bg-red-400 ml-1" />}
                  </button>
                );
              })}
            </div>

            {/* Tab content */}
            <div className="p-6">
              {activeTab === "businessModel"  && <BusinessModelTab  data={results.businessModel} />}
              {activeTab === "financialModel" && <FinancialModelTab data={results.financialModel} />}
              {activeTab === "pitchDeck"      && <PitchDeckTab      data={results.pitchDeck} />}
              {activeTab === "prototypeSpec"  && <PrototypeSpecTab  data={results.prototypeSpec} />}
              {activeTab === "gtmCampaign"    && <GtmCampaignTab    data={results.gtmCampaign} />}
            </div>
          </div>
        )}

        {/* ── Saved Analyses ── */}
        <SavedAnalysesPanel
          analyses={analyses}
          loading={historyLoading}
          onSelect={restoreAnalysis}
        />

      </div>
    </div>
  );
}
