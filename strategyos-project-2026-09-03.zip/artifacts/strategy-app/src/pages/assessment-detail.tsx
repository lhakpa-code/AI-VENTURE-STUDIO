import { useParams, Link } from "wouter";
import { useGetAssessment, getGetAssessmentQueryKey, useGetBusiness, getGetBusinessQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, BrainCircuit, Route, ShieldAlert, Target, Zap, Shield, TrendingUp } from "lucide-react";
import { format } from "date-fns";

const ScoreRing = ({ score, label, colorClass, icon: Icon }: { score: number, label: string, colorClass: string, icon: any }) => {
  const normalizedScore = Math.max(0, Math.min(100, score || 0));
  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (normalizedScore / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative w-24 h-24 flex items-center justify-center">
        {/* Background circle */}
        <svg className="w-full h-full transform -rotate-90 absolute inset-0">
          <circle
            cx="48"
            cy="48"
            r={radius}
            stroke="currentColor"
            strokeWidth="8"
            fill="transparent"
            className="text-muted/50"
          />
          {/* Progress circle */}
          <circle
            cx="48"
            cy="48"
            r={radius}
            stroke="currentColor"
            strokeWidth="8"
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            className={`transition-all duration-1000 ease-out ${colorClass}`}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-xl font-bold font-mono">{normalizedScore}</span>
        </div>
      </div>
      <div className="flex items-center gap-1.5 text-sm font-medium">
        <Icon className={`w-4 h-4 ${colorClass}`} />
        {label}
      </div>
    </div>
  );
};

export default function AssessmentDetail() {
  const params = useParams();
  const id = Number(params.id);

  const { data: assessment, isLoading: isAssessmentLoading } = useGetAssessment(id, {
    query: { enabled: !!id, queryKey: getGetAssessmentQueryKey(id) }
  });

  const businessId = assessment?.businessId;

  const { data: business, isLoading: isBusinessLoading } = useGetBusiness(businessId as number, {
    query: { enabled: !!businessId, queryKey: getGetBusinessQueryKey(businessId as number) }
  });

  if (isAssessmentLoading || isBusinessLoading) {
    return (
      <div className="p-8 max-w-5xl mx-auto space-y-8">
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
        <div className="h-48 bg-card animate-pulse rounded-xl" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="h-64 bg-card animate-pulse rounded-xl" />
          <div className="h-64 bg-card animate-pulse rounded-xl" />
        </div>
      </div>
    );
  }

  if (!assessment || !business) return <div className="p-8 text-center text-muted-foreground">Assessment not found.</div>;

  return (
    <div className="p-8 max-w-5xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          <Link href={`/businesses/${business.id}`} className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4 transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to {business.name}
          </Link>
          <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
            <BrainCircuit className="w-8 h-8 text-primary" />
            Intelligence Assessment
          </h1>
          <p className="text-muted-foreground mt-2 flex items-center gap-2">
            Generated on <span className="font-mono uppercase text-xs">{format(new Date(assessment.createdAt), 'MMM d, yyyy')}</span>
            {assessment.status === 'pending' && <Badge variant="outline" className="ml-2 bg-amber-500/10 text-amber-500">Analyzing...</Badge>}
          </p>
        </div>
        <div>
          <Button asChild className="bg-primary text-primary-foreground shadow-[0_0_15px_rgba(93,46,232,0.4)] hover:bg-primary/90">
            <Link href={`/businesses/${business.id}/strategies/new?assessmentId=${assessment.id}`}>
              <Route className="w-4 h-4 mr-2" />
              Generate Strategy from Assessment
            </Link>
          </Button>
        </div>
      </div>

      <Card className="bg-card/50 backdrop-blur border-primary/20 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px] -mr-32 -mt-32 pointer-events-none" />
        <CardContent className="p-8 relative">
          <h2 className="text-xl font-bold mb-4">Identity Summary</h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            {assessment.identitySummary || "No summary generated."}
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-10 pt-8 border-t border-border/50">
            <ScoreRing score={assessment.strengthScore || 0} label="Strengths" colorClass="text-emerald-400" icon={Shield} />
            <ScoreRing score={assessment.weaknessScore || 0} label="Weaknesses" colorClass="text-amber-400" icon={Target} />
            <ScoreRing score={assessment.opportunityScore || 0} label="Opportunities" colorClass="text-blue-400" icon={TrendingUp} />
            <ScoreRing score={assessment.threatScore || 0} label="Threats" colorClass="text-rose-400" icon={ShieldAlert} />
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Strengths */}
        <Card className="bg-card/50 border-emerald-500/20">
          <CardHeader className="pb-3 border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-emerald-400">
              <Shield className="w-5 h-5" /> Strengths
            </CardTitle>
            <CardDescription>Internal advantages and capabilities.</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            {assessment.strengths && assessment.strengths.length > 0 ? (
              <ul className="space-y-4">
                {assessment.strengths.map((item, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="text-emerald-400 mt-1 font-mono text-xs">0{i+1}</span>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground text-sm italic">No data.</p>
            )}
          </CardContent>
        </Card>

        {/* Weaknesses */}
        <Card className="bg-card/50 border-amber-500/20">
          <CardHeader className="pb-3 border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-amber-400">
              <Target className="w-5 h-5" /> Weaknesses
            </CardTitle>
            <CardDescription>Internal areas needing improvement.</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            {assessment.weaknesses && assessment.weaknesses.length > 0 ? (
              <ul className="space-y-4">
                {assessment.weaknesses.map((item, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="text-amber-400 mt-1 font-mono text-xs">0{i+1}</span>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground text-sm italic">No data.</p>
            )}
          </CardContent>
        </Card>

        {/* Opportunities */}
        <Card className="bg-card/50 border-blue-500/20">
          <CardHeader className="pb-3 border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-blue-400">
              <TrendingUp className="w-5 h-5" /> Opportunities
            </CardTitle>
            <CardDescription>External chances for growth.</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            {assessment.opportunities && assessment.opportunities.length > 0 ? (
              <ul className="space-y-4">
                {assessment.opportunities.map((item, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="text-blue-400 mt-1 font-mono text-xs">0{i+1}</span>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground text-sm italic">No data.</p>
            )}
          </CardContent>
        </Card>

        {/* Threats */}
        <Card className="bg-card/50 border-rose-500/20">
          <CardHeader className="pb-3 border-b border-border/50">
            <CardTitle className="flex items-center gap-2 text-rose-400">
              <ShieldAlert className="w-5 h-5" /> Threats
            </CardTitle>
            <CardDescription>External risks to mitigate.</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            {assessment.threats && assessment.threats.length > 0 ? (
              <ul className="space-y-4">
                {assessment.threats.map((item, i) => (
                  <li key={i} className="flex gap-3">
                    <span className="text-rose-400 mt-1 font-mono text-xs">0{i+1}</span>
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground text-sm italic">No data.</p>
            )}
          </CardContent>
        </Card>
      </div>

      {assessment.recommendations && assessment.recommendations.length > 0 && (
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-primary">
              <Zap className="w-5 h-5" /> Strategic Recommendations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-4">
              {assessment.recommendations.map((rec, i) => (
                <li key={i} className="flex items-start gap-3 bg-card/50 p-4 rounded-lg border border-border/50">
                  <div className="w-6 h-6 rounded-full bg-primary/20 text-primary flex items-center justify-center flex-shrink-0 text-sm font-mono mt-0.5">
                    {i+1}
                  </div>
                  <span className="text-foreground leading-relaxed">{rec}</span>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
