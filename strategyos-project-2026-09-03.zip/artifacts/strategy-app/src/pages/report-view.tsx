import { useEffect, useState } from "react";
import { useLocation, useParams } from "wouter";
import { BrainCircuit, AlertTriangle, ArrowLeft } from "lucide-react";
import type { FullReport } from "../types/report";
import { ResultView } from "../components/ResultView";
import VersionNav from "../components/VersionNav";

export default function ReportViewPage() {
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const reportId = params.id;

  const [report, setReport] = useState<FullReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!reportId) { setError("No report ID"); setLoading(false); return; }
    fetch(`/api/reports/${reportId}`)
      .then((r) => {
        if (!r.ok) throw new Error(r.status === 404 ? "Report not found" : "Failed to load report");
        return r.json();
      })
      .then((data) => {
        // data.reportJson holds the FullReport
        setReport(data.reportJson as FullReport);
        setLoading(false);
      })
      .catch((err) => {
        setError(err.message ?? "Something went wrong");
        setLoading(false);
      });
  }, [reportId]);

  return (
    <div className="min-h-screen bg-[#080810] flex flex-col">
      {/* Header */}
      <header className="flex items-center gap-3 px-8 py-5 border-b border-white/[0.06]">
        <div className="w-8 h-8 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
        </div>
        <span className="font-semibold text-white tracking-tight">StrategyOS</span>
      </header>

      <VersionNav />

      {loading && (
        <div className="flex-1 flex items-center justify-center">
          <div className="w-10 h-10 border-2 border-violet-500/30 border-t-violet-400 rounded-full animate-spin" />
        </div>
      )}

      {!loading && error && (
        <div className="flex-1 flex flex-col items-center justify-center px-4 gap-6">
          <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
            <AlertTriangle className="w-8 h-8 text-red-400" />
          </div>
          <div className="text-center">
            <h2 className="text-xl font-bold text-white mb-2">Report not found</h2>
            <p className="text-white/40 text-sm max-w-sm">{error}</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => navigate("/history")}
              className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-xl px-5 py-2.5 text-sm font-medium transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              View history
            </button>
            <button
              onClick={() => navigate("/")}
              className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all"
            >
              <BrainCircuit className="w-4 h-4" />
              New analysis
            </button>
          </div>
        </div>
      )}

      {!loading && !error && report && (
        <ResultView
          report={report}
          onNew={() => navigate("/")}
          savedId={Number(reportId)}
        />
      )}
    </div>
  );
}
