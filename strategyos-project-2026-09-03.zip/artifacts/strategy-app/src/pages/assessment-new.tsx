import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { 
  useGetBusiness, 
  getGetBusinessQueryKey,
  useCreateAssessment,
  getListAssessmentsQueryKey,
  getGetBusinessDashboardQueryKey
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { BrainCircuit, Loader2, ArrowLeft, Zap } from "lucide-react";
import { Link } from "wouter";

const LOADING_STEPS = [
  "Analyzing business identity...",
  "Evaluating market positioning...",
  "Identifying critical strengths...",
  "Uncovering hidden weaknesses...",
  "Scanning for market opportunities...",
  "Assessing competitive threats...",
  "Synthesizing strategic recommendations...",
  "Finalizing assessment...",
];

export default function AssessmentNew() {
  const params = useParams();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const [context, setContext] = useState("");
  const [loadingStepIndex, setLoadingStepIndex] = useState(0);

  const { data: business, isLoading: isLoadingBusiness } = useGetBusiness(id, {
    query: { enabled: !!id, queryKey: getGetBusinessQueryKey(id) }
  });

  const createAssessment = useCreateAssessment();

  // Handle loading steps animation
  useEffect(() => {
    if (!createAssessment.isPending) return;
    
    const interval = setInterval(() => {
      setLoadingStepIndex((prev) => (prev < LOADING_STEPS.length - 1 ? prev + 1 : prev));
    }, 2000);
    
    return () => clearInterval(interval);
  }, [createAssessment.isPending]);

  const handleRunAssessment = () => {
    if (!id) return;
    setLoadingStepIndex(0);
    createAssessment.mutate(
      { id, data: { additionalContext: context } },
      {
        onSuccess: (assessment) => {
          queryClient.invalidateQueries({ queryKey: getListAssessmentsQueryKey(id) });
          queryClient.invalidateQueries({ queryKey: getGetBusinessDashboardQueryKey(id) });
          setLocation(`/assessments/${assessment.id}`);
        }
      }
    );
  };

  if (isLoadingBusiness) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-100px)]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!business) return <div className="p-8">Business not found.</div>;

  if (createAssessment.isPending) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] max-w-lg mx-auto text-center space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 blur-[50px] rounded-full w-32 h-32" />
          <div className="relative w-32 h-32 bg-card border border-primary/20 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(93,46,232,0.3)]">
            <BrainCircuit className="w-12 h-12 text-primary animate-pulse" />
          </div>
        </div>
        
        <div className="space-y-2">
          <h2 className="text-2xl font-bold font-mono tracking-tight text-white">
            Running Intelligence Engine
          </h2>
          <p className="text-primary h-6 transition-all duration-300">
            {LOADING_STEPS[loadingStepIndex]}
          </p>
        </div>
        
        <div className="w-full bg-card rounded-full h-1.5 overflow-hidden">
          <div 
            className="bg-primary h-full transition-all duration-500 ease-out"
            style={{ width: `${Math.max(10, (loadingStepIndex / (LOADING_STEPS.length - 1)) * 100)}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="mb-8">
        <Link href={`/businesses/${id}`} className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Hub
        </Link>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <Zap className="text-primary w-8 h-8" />
          New Assessment
        </h1>
        <p className="text-muted-foreground mt-2">
          Run a comprehensive AI analysis of {business.name}. Add any recent context or specific challenges you're facing to get more accurate insights.
        </p>
      </div>

      <Card className="bg-card/50 backdrop-blur border-border/50">
        <CardHeader>
          <CardTitle>Situational Context (Optional)</CardTitle>
          <CardDescription>
            What's happening right now? (e.g., "We just lost our biggest client," "We're launching a new product next month," or "Cash flow is tightening.")
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Textarea 
            placeholder="Enter situational context..."
            className="min-h-[150px] bg-background/50 text-base"
            value={context}
            onChange={(e) => setContext(e.target.value)}
          />
          
          <Button 
            size="lg" 
            onClick={handleRunAssessment}
            className="w-full text-lg h-14 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(93,46,232,0.4)]"
          >
            <BrainCircuit className="w-5 h-5 mr-2" />
            Analyze My Business
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
