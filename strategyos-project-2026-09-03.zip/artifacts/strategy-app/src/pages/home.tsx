import { useState } from "react";
import { useLocation } from "wouter";
import { BrainCircuit, ArrowRight, Sparkles, Search, Database, Bot, Rocket } from "lucide-react";
import VersionNav from "../components/VersionNav";

const EXAMPLES = ["Apple", "Stripe", "Monzo", "SpaceX", "Binance", "ByteDance", "Patagonia"];

export default function Home() {
  const [, navigate] = useLocation();
  const [companyName, setCompanyName] = useState("");
  const [targetMarket, setTargetMarket] = useState("");
  const [description, setDescription] = useState("");

  const canSubmit = companyName.trim().length > 0;

  const handleSubmit = () => {
    if (!canSubmit) return;
    const params = new URLSearchParams({ company: companyName.trim() });
    const context = [
      targetMarket.trim() && `Target market: ${targetMarket.trim()}`,
      description.trim() && `Description: ${description.trim()}`,
    ].filter(Boolean).join(". ");
    if (context) params.set("context", context);
    navigate(`/swot?${params.toString()}`);
  };

  return (
    <div className="min-h-screen bg-[#080810] flex flex-col">
      {/* Header */}
      <header className="flex items-center gap-3 px-8 py-5 border-b border-white/[0.06]">
        <div className="w-8 h-8 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
        </div>
        <span className="font-semibold text-white tracking-tight">StrategyOS</span>
        <div className="ml-auto flex items-center gap-3">
          <button
            onClick={() => navigate("/venture")}
            className="flex items-center gap-1.5 text-xs font-semibold text-indigo-300/70 hover:text-indigo-300 transition-colors rounded-full px-3 py-1"
            style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.15)" }}
          >
            <Rocket className="w-3 h-3" />
            Venture Studio
          </button>
          <span className="text-[11px] font-semibold text-violet-400/60 uppercase tracking-widest bg-violet-500/8 border border-violet-500/15 rounded-full px-3 py-1">
            3-Agent Pipeline
          </span>
        </div>
      </header>

      <VersionNav />

      {/* Main */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 py-16">
        <div className="w-full max-w-2xl">

          {/* Badge */}
          <div className="flex justify-center mb-8">
            <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/20 rounded-full px-4 py-1.5">
              <Sparkles className="w-3.5 h-3.5 text-violet-400" />
              <span className="text-violet-300 text-xs font-semibold tracking-widest uppercase">Chief Strategy Officer Intelligence</span>
            </div>
          </div>

          {/* Headline */}
          <h1 className="text-center text-5xl md:text-6xl font-bold text-white tracking-tight leading-[1.1] mb-5">
            AI Venture Studio<br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-violet-400 via-purple-400 to-blue-400">
              for any company
            </span>
          </h1>
          <p className="text-center text-white/45 text-lg leading-relaxed mb-12 max-w-lg mx-auto">
            Three specialised AI agents research SEC filings, financial metrics, and competitive intelligence — then a CSO-level AI synthesises it into a full strategic report.
          </p>

          {/* Form */}
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-6 shadow-2xl">
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Company name */}
                <div>
                  <label className="block text-xs text-white/40 mb-2 font-medium uppercase tracking-wider">Company / Venture Name</label>
                  <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter" && canSubmit) handleSubmit(); }}
                      placeholder="e.g. Stripe, Tesla, Acme AI..."
                      autoFocus
                      className="w-full bg-white/5 border border-white/10 rounded-xl pl-11 pr-4 py-3.5 text-white placeholder-white/25 outline-none focus:border-violet-500/60 focus:ring-2 focus:ring-violet-500/10 transition-all text-base"
                    />
                  </div>
                </div>

                {/* Target market */}
                <div>
                  <label className="block text-xs text-white/40 mb-2 font-medium uppercase tracking-wider">Target Market</label>
                  <input
                    type="text"
                    value={targetMarket}
                    onChange={(e) => setTargetMarket(e.target.value)}
                    onKeyDown={(e) => { if (e.key === "Enter" && canSubmit) handleSubmit(); }}
                    placeholder="e.g. SMBs in healthcare, Gen-Z consumers..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder-white/25 outline-none focus:border-violet-500/60 focus:ring-2 focus:ring-violet-500/10 transition-all text-base"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs text-white/40 mb-2 font-medium uppercase tracking-wider">Business Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what the business does, the core problem it solves, and its primary value proposition..."
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/25 outline-none focus:border-violet-500/60 transition-all text-sm resize-none"
                />
              </div>

              {/* Submit */}
              <button
                onClick={handleSubmit}
                disabled={!canSubmit}
                className="w-full flex items-center justify-center gap-2.5 bg-violet-600 hover:bg-violet-500 disabled:bg-white/5 disabled:text-white/20 disabled:cursor-not-allowed text-white font-semibold rounded-xl px-6 py-3.5 transition-all duration-200 text-base shadow-[0_0_30px_rgba(139,92,246,0.25)] hover:shadow-[0_0_40px_rgba(139,92,246,0.4)]"
              >
                <BrainCircuit className="w-4 h-4" />
                Run Strategic Analysis
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Examples */}
          <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
            <span className="text-white/25 text-xs">Try:</span>
            {EXAMPLES.map((ex) => (
              <button
                key={ex}
                onClick={() => { setCompanyName(ex); }}
                className="text-xs text-white/35 hover:text-white/70 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.07] rounded-full px-3 py-1 transition-all"
              >
                {ex}
              </button>
            ))}
          </div>

          {/* Pipeline cards */}
          <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              {
                icon: Database,
                num: "01",
                title: "Data Aggregator",
                desc: "Searches SEC 10-K/10-Q filings, recent news, Glassdoor/Reddit sentiment, and competitive positioning.",
                color: "text-violet-400",
                bg: "bg-violet-500/10 border-violet-500/20",
              },
              {
                icon: Search,
                num: "02",
                title: "Quant Analyst",
                desc: "Extracts hard numbers — revenue, growth rates, margins, burn rate, stock trends, and peer benchmarks.",
                color: "text-blue-400",
                bg: "bg-blue-500/10 border-blue-500/20",
              },
              {
                icon: Bot,
                num: "03",
                title: "CSO Synthesis",
                desc: "A senior consultant AI takes the verified data pack and produces SWOT, priorities, risks, and a 90-day plan.",
                color: "text-emerald-400",
                bg: "bg-emerald-500/10 border-emerald-500/20",
              },
            ].map(({ icon: Icon, num, title, desc, color, bg }) => (
              <div key={title} className="bg-white/[0.02] border border-white/[0.07] rounded-xl p-5">
                <div className="flex items-center gap-2.5 mb-3">
                  <div className={`w-8 h-8 rounded-lg border flex items-center justify-center ${bg}`}>
                    <Icon className={`w-4 h-4 ${color}`} />
                  </div>
                  <span className="text-white/20 text-xs font-mono font-bold">{num}</span>
                </div>
                <p className="text-white font-semibold text-sm mb-1">{title}</p>
                <p className="text-white/40 text-xs leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
