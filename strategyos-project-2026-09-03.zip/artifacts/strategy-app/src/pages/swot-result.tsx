import { useEffect, useState, useRef, useMemo, useCallback } from "react";
import { useLocation } from "wouter";
import VersionNav from "../components/VersionNav";
import {
  BrainCircuit, ArrowLeft, Shield, AlertTriangle, TrendingUp, Zap,
  Loader2, RotateCcw, CheckCircle2, Clock, Target, AlertOctagon,
  Lightbulb, CalendarDays, ChevronRight, Info, Database, Search, Bot,
  ChevronDown, ChevronUp, FileText, BarChart2, Users, Globe,
  Pencil, Trash2, ArrowUpCircle, X, Sparkles, FlaskConical,
  TriangleAlert, CircleCheck, Minus, RefreshCcw, History,
  Download, ExternalLink, Code2, MonitorSmartphone, Share2, Copy, Check,
} from "lucide-react";
import html2canvas from "html2canvas";
import type {
  FullReport, SwotItem, SSEEvent, RefineUpdates, CompetitorProfile,
  ConfidenceScore, BusinessScore, CategoryScore, ScoreRating, HealthGrade,
} from "../types/report";

// Unused import removed: QuickWin is now string[]

// ─── Confidence Badge ─────────────────────────────────────────────────────────

const CONFIDENCE_CFG: Record<ConfidenceScore, { label: string; dot: string; badge: string; Icon: typeof CircleCheck }> = {
  high:   { label: "High confidence",   dot: "bg-emerald-400", badge: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400", Icon: CircleCheck },
  medium: { label: "Medium confidence", dot: "bg-amber-400",   badge: "bg-amber-500/10 border-amber-500/20 text-amber-400",     Icon: Minus },
  low:    { label: "Low — flagged",     dot: "bg-red-400",     badge: "bg-red-500/10 border-red-500/20 text-red-400",           Icon: TriangleAlert },
};

function ConfidenceBadge({ score }: { score: ConfidenceScore }) {
  const cfg = CONFIDENCE_CFG[score] ?? CONFIDENCE_CFG.medium;
  const Ic = cfg.Icon;
  return (
    <span className={`inline-flex items-center gap-1 text-[10px] font-semibold rounded-full px-2 py-0.5 border ${cfg.badge}`}>
      <Ic className="w-2.5 h-2.5" />
      {score}
    </span>
  );
}

function CitationBadge({ citation }: { citation: string }) {
  if (!citation || citation === "Agent inference (low confidence)") return null;
  return (
    <span className="inline-flex items-center gap-1 text-[10px] text-white/30 bg-white/[0.03] border border-white/[0.06] rounded px-1.5 py-0.5 max-w-full truncate">
      <FileText className="w-2.5 h-2.5 shrink-0" />
      {citation}
    </span>
  );
}

// ─── Agent Pipeline Loading UI ────────────────────────────────────────────────

type AgentPhase = "idle" | "running" | "complete";
interface AgentState { phase: AgentPhase; label: string; role: string; currentDetail: string; summary: Record<string, string> }

const AGENT_DEFAULTS = {
  1: { label: "Data Aggregator & Grounding",      role: "SEC filings · News · Sentiment · Competitive intelligence", Icon: Database, color: "text-violet-300", iconBg: "bg-violet-500/15 border-violet-500/25", border: "border-violet-500/25" },
  2: { label: "Quantitative Financial Analyst",   role: "Revenue · Margins · Growth rate · Stock / Funding",        Icon: Search,   color: "text-blue-300",   iconBg: "bg-blue-500/15 border-blue-500/25",   border: "border-blue-500/25" },
  3: { label: "Senior Consultant Synthesis",      role: "Structured SWOT · Citations · Competitive matrix",         Icon: Bot,      color: "text-emerald-300",iconBg: "bg-emerald-500/15 border-emerald-500/25",border: "border-emerald-500/25" },
} as const;

function AgentCard({ n, state }: { n: 1|2|3; state: AgentState }) {
  const def = AGENT_DEFAULTS[n];
  const Icon = def.Icon;
  const idle = state.phase === "idle", running = state.phase === "running", done = state.phase === "complete";
  return (
    <div className={`rounded-2xl border transition-all duration-500 overflow-hidden ${done ? `bg-white/[0.03] ${def.border}` : running ? `bg-white/[0.04] ${def.border}` : "bg-white/[0.015] border-white/[0.06]"}`}>
      <div className="px-5 py-4 flex items-start gap-4">
        <div className="relative shrink-0 mt-0.5">
          <div className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all duration-500 ${done || running ? def.iconBg : "bg-white/5 border-white/10"}`}>
            <Icon className={`w-5 h-5 transition-colors duration-500 ${done || running ? def.color : "text-white/20"}`} />
          </div>
          {done && <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full flex items-center justify-center"><CheckCircle2 className="w-3 h-3 text-white" /></div>}
          {running && <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-[#080810] rounded-full flex items-center justify-center"><Loader2 className={`w-3.5 h-3.5 animate-spin ${def.color}`} /></div>}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <span className={`text-xs font-bold rounded-full px-2 py-0.5 border ${done ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : running ? `${def.iconBg} ${def.color}` : "bg-white/5 border-white/10 text-white/25"}`}>
              Agent {n}
            </span>
          </div>
          <p className={`font-bold text-sm transition-colors duration-500 ${done || running ? "text-white" : "text-white/30"}`}>{state.label || def.label}</p>
          <p className={`text-xs transition-colors duration-500 ${done || running ? "text-white/40" : "text-white/15"}`}>{state.role || def.role}</p>
          {running && state.currentDetail && (
            <div className="mt-2.5 flex items-center gap-1.5">
              <div className="w-1 h-1 rounded-full bg-white/40 animate-pulse" />
              <p className="text-xs text-white/55">{state.currentDetail}</p>
            </div>
          )}
          {done && Object.keys(state.summary).length > 0 && (
            <div className="mt-2.5 flex flex-wrap gap-1.5">
              {Object.entries(state.summary).map(([k, v]) => (
                <div key={k} className="flex items-center gap-1 bg-white/5 border border-white/10 rounded-full px-2.5 py-0.5">
                  <span className="text-white/35 text-[10px] font-medium">{k}:</span>
                  <span className="text-white/65 text-[10px] font-semibold">{v}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function makeDefaultAgents(): Record<1|2|3, AgentState> {
  return {
    1: { phase: "idle", label: AGENT_DEFAULTS[1].label, role: AGENT_DEFAULTS[1].role, currentDetail: "", summary: {} },
    2: { phase: "idle", label: AGENT_DEFAULTS[2].label, role: AGENT_DEFAULTS[2].role, currentDetail: "", summary: {} },
    3: { phase: "idle", label: AGENT_DEFAULTS[3].label, role: AGENT_DEFAULTS[3].role, currentDetail: "", summary: {} },
  };
}

function LoadingView({ companyName, agents }: { companyName: string; agents: Record<1|2|3, AgentState> }) {
  const running = Object.values(agents).filter(a => a.phase === "running").length;
  const done = Object.values(agents).filter(a => a.phase === "complete").length;
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 py-12 gap-8">
      <div className="text-center">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-violet-600/10 border border-violet-500/20 flex items-center justify-center">
            <BrainCircuit className="w-6 h-6 text-violet-400" />
          </div>
          {running > 0 && (
            <div className="flex items-center gap-1.5 bg-violet-500/10 border border-violet-500/20 rounded-full px-3 py-1">
              <Loader2 className="w-3.5 h-3.5 text-violet-400 animate-spin" />
              <span className="text-violet-300 text-xs font-semibold">{running > 1 ? `${running} agents running in parallel` : "Agent running"}</span>
            </div>
          )}
        </div>
        <h2 className="text-2xl font-bold text-white mb-1.5">Analysing {companyName}</h2>
        <p className="text-white/35 text-sm">{done === 0 ? "Spinning up the intelligence pipeline..." : done === 3 ? "Finalising your report..." : `${done} of 3 agents complete`}</p>
      </div>
      <div className="w-full max-w-md">
        <div className="h-1 bg-white/5 rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-violet-500 to-blue-500 rounded-full transition-all duration-1000" style={{ width: `${Math.round((done / 3) * 100)}%` }} />
        </div>
      </div>
      <div className="w-full max-w-md space-y-3">
        {([1, 2, 3] as const).map(n => <AgentCard key={n} n={n} state={agents[n]} />)}
      </div>
      <p className="text-white/20 text-xs">This usually takes 60–90 seconds</p>
    </div>
  );
}

// ─── Error View ───────────────────────────────────────────────────────────────

function ErrorView({ error, onRetry }: { error: string; onRetry: () => void }) {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-4 gap-6">
      <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center">
        <AlertTriangle className="w-8 h-8 text-red-400" />
      </div>
      <div className="text-center">
        <h2 className="text-xl font-bold text-white mb-2">Analysis failed</h2>
        <p className="text-white/40 text-sm max-w-sm">{error}</p>
      </div>
      <button onClick={onRetry} className="flex items-center gap-2 bg-white/5 hover:bg-white/10 border border-white/10 text-white rounded-xl px-5 py-2.5 text-sm font-medium transition-all">
        <RotateCcw className="w-4 h-4" />Try again
      </button>
    </div>
  );
}

// ─── Section Header ───────────────────────────────────────────────────────────

const SECTION_COLORS: Record<string, string> = {
  violet:  "text-violet-400 bg-violet-500/10 border-violet-500/20",
  red:     "text-red-400    bg-red-500/10    border-red-500/20",
  blue:    "text-blue-400   bg-blue-500/10   border-blue-500/20",
  emerald: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  white:   "text-white/70   bg-white/5       border-white/10",
  amber:   "text-amber-400  bg-amber-500/10  border-amber-500/20",
};

function SectionHeader({ icon: Icon, label, color, action }: { icon: React.ElementType; label: string; color: string; action?: React.ReactNode }) {
  const cls = SECTION_COLORS[color] ?? SECTION_COLORS.white;
  return (
    <div className="flex items-center gap-3 mb-5">
      <div className={`w-8 h-8 rounded-lg border flex items-center justify-center ${cls}`}><Icon className="w-4 h-4" /></div>
      <h2 className="text-lg font-bold text-white flex-1">{label}</h2>
      {action}
    </div>
  );
}

// ─── SWOT Grid with Edit Mode ─────────────────────────────────────────────────

const QUADRANT_CFG = {
  strengths:     { label: "Strengths",     letter: "S", Icon: Shield,        border: "border-emerald-500/25", headerBg: "bg-emerald-500/8",  dot: "bg-emerald-400", titleColor: "text-emerald-300",  sigColor: "text-emerald-400/70",  sigBg: "bg-emerald-500/5 border-emerald-500/15",  desc: "Internal advantages" },
  weaknesses:    { label: "Weaknesses",    letter: "W", Icon: AlertTriangle,  border: "border-amber-500/25",   headerBg: "bg-amber-500/8",    dot: "bg-amber-400",   titleColor: "text-amber-300",    sigColor: "text-amber-400/70",    sigBg: "bg-amber-500/5 border-amber-500/15",    desc: "Internal vulnerabilities" },
  opportunities: { label: "Opportunities", letter: "O", Icon: TrendingUp,    border: "border-blue-500/25",    headerBg: "bg-blue-500/8",     dot: "bg-blue-400",    titleColor: "text-blue-300",     sigColor: "text-blue-400/70",     sigBg: "bg-blue-500/5 border-blue-500/15",     desc: "External tailwinds" },
  threats:       { label: "Threats",       letter: "T", Icon: Zap,           border: "border-red-500/25",     headerBg: "bg-red-500/8",      dot: "bg-red-400",     titleColor: "text-red-300",      sigColor: "text-red-400/70",      sigBg: "bg-red-500/5 border-red-500/15",       desc: "External pressures" },
} as const;

interface ItemEdit { removed: boolean; elevated: boolean; editedPoint?: string }
type SwotEdits = Record<string, ItemEdit>;

function SwotItemCard({
  item, quadrant, idx, editMode, edit,
  onRemove, onRestore, onElevate, onEditPoint,
}: {
  item: SwotItem;
  quadrant: keyof typeof QUADRANT_CFG;
  idx: number;
  editMode: boolean;
  edit: ItemEdit;
  onRemove: () => void;
  onRestore: () => void;
  onElevate: () => void;
  onEditPoint: (v: string) => void;
}) {
  const cfg = QUADRANT_CFG[quadrant];
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(item.point);
  const isLow = item.confidence_score === "low";

  if (edit.removed) {
    return (
      <div className="flex items-center gap-3 opacity-40 py-2">
        <span className="text-xs text-white/30 line-through flex-1">{item.point}</span>
        <button onClick={onRestore} className="text-xs text-white/40 hover:text-white/70 bg-white/5 rounded px-2 py-0.5">Restore</button>
      </div>
    );
  }

  const displayPoint = edit.editedPoint ?? item.point;

  return (
    <div className={`relative transition-all duration-300 ${isLow && !editMode ? "opacity-70" : ""} ${edit.elevated ? "order-first" : ""}`}>
      {/* Low-confidence warning strip */}
      {isLow && (
        <div className="flex items-center gap-1.5 mb-1.5 bg-red-500/8 border border-red-500/15 rounded-lg px-3 py-1.5">
          <TriangleAlert className="w-3 h-3 text-red-400 shrink-0" />
          <p className="text-red-300/70 text-[10px]">Limited data support — review before including in executive report</p>
        </div>
      )}

      {edit.elevated && (
        <div className="flex items-center gap-1 mb-1.5">
          <ArrowUpCircle className="w-3 h-3 text-violet-400" />
          <span className="text-[10px] text-violet-400 font-semibold">Elevated</span>
        </div>
      )}

      {/* Point */}
      <div className="flex gap-2.5 mb-1.5">
        <span className={`w-1.5 h-1.5 rounded-full mt-2 shrink-0 ${cfg.dot}`} />
        {editing ? (
          <div className="flex-1">
            <textarea
              value={draft}
              onChange={e => setDraft(e.target.value)}
              rows={2}
              className="w-full bg-white/5 border border-violet-500/30 rounded-lg px-3 py-2 text-white text-sm resize-none outline-none focus:border-violet-500/60"
            />
            <div className="flex gap-2 mt-1.5">
              <button onClick={() => { onEditPoint(draft); setEditing(false); }} className="text-xs bg-violet-600 text-white rounded px-3 py-1">Save</button>
              <button onClick={() => { setDraft(item.point); setEditing(false); }} className="text-xs text-white/40 hover:text-white/70">Cancel</button>
            </div>
          </div>
        ) : (
          <p className={`text-sm font-bold leading-snug ${cfg.titleColor}`}>{displayPoint}</p>
        )}
      </div>

      {/* Evidence */}
      <p className="text-white/55 text-sm leading-relaxed pl-4 mb-2">{item.evidence}</p>

      {/* Strategic impact */}
      {item.strategic_impact && (
        <div className={`ml-4 rounded-lg border px-3 py-2 mb-2 ${cfg.sigBg}`}>
          <p className={`text-xs font-semibold uppercase tracking-wider mb-0.5 ${cfg.sigColor}`}>Strategic impact</p>
          <p className="text-white/50 text-xs leading-relaxed">{item.strategic_impact}</p>
        </div>
      )}

      {/* Metadata row */}
      <div className="ml-4 flex flex-wrap items-center gap-1.5">
        <ConfidenceBadge score={item.confidence_score} />
        <CitationBadge citation={item.citation} />
      </div>

      {/* Edit mode toolbar */}
      {editMode && !editing && (
        <div className="mt-2.5 ml-4 flex items-center gap-1.5">
          <button onClick={() => { setDraft(displayPoint); setEditing(true); }} className="flex items-center gap-1 text-[10px] text-white/40 hover:text-white/70 bg-white/5 hover:bg-white/8 border border-white/10 rounded px-2 py-1 transition-all">
            <Pencil className="w-2.5 h-2.5" />Edit
          </button>
          <button onClick={onElevate} className={`flex items-center gap-1 text-[10px] border rounded px-2 py-1 transition-all ${edit.elevated ? "bg-violet-500/15 border-violet-500/25 text-violet-400" : "text-white/40 hover:text-white/70 bg-white/5 hover:bg-white/8 border-white/10"}`}>
            <ArrowUpCircle className="w-2.5 h-2.5" />{edit.elevated ? "Elevated" : "Elevate"}
          </button>
          <button onClick={onRemove} className="flex items-center gap-1 text-[10px] text-red-400/60 hover:text-red-400 bg-white/5 hover:bg-red-500/8 border border-white/10 hover:border-red-500/20 rounded px-2 py-1 transition-all">
            <Trash2 className="w-2.5 h-2.5" />Remove
          </button>
        </div>
      )}
    </div>
  );
}

function SwotGrid({
  swot, editMode, edits, onEditChange,
}: {
  swot: FullReport["swot"];
  editMode: boolean;
  edits: SwotEdits;
  onEditChange: (key: string, patch: Partial<ItemEdit>) => void;
}) {
  const keys = ["strengths", "weaknesses", "opportunities", "threats"] as const;
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
      {keys.map(key => {
        const cfg = QUADRANT_CFG[key];
        const items = swot[key];
        const Icon = cfg.Icon;
        const lowCount = items.filter(i => i.confidence_score === "low").length;
        return (
          <div key={key} className={`bg-white/[0.02] border ${cfg.border} rounded-2xl overflow-hidden`}>
            <div className={`${cfg.headerBg} border-b ${cfg.border} px-5 py-4 flex items-center gap-3`}>
              <div className={`w-9 h-9 rounded-xl bg-white/5 border ${cfg.border} flex items-center justify-center`}>
                <Icon className={`w-4 h-4 ${cfg.titleColor}`} />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className={`text-xl font-black ${cfg.titleColor}`}>{cfg.letter}</span>
                  <span className="text-white font-bold">{cfg.label}</span>
                  {lowCount > 0 && (
                    <span className="text-[10px] bg-red-500/10 border border-red-500/20 text-red-400 rounded-full px-2 py-0.5">
                      {lowCount} flagged
                    </span>
                  )}
                </div>
                <p className="text-white/35 text-xs">{cfg.desc}</p>
              </div>
            </div>
            <div className="p-5 space-y-5">
              {items.map((item, i) => {
                const eKey = `${key}_${i}`;
                const edit = edits[eKey] ?? { removed: false, elevated: false };
                return (
                  <div key={i}>
                    <SwotItemCard
                      item={item} quadrant={key} idx={i}
                      editMode={editMode} edit={edit}
                      onRemove={() => onEditChange(eKey, { removed: true })}
                      onRestore={() => onEditChange(eKey, { removed: false })}
                      onElevate={() => onEditChange(eKey, { elevated: !edit.elevated })}
                      onEditPoint={v => onEditChange(eKey, { editedPoint: v })}
                    />
                    {i < items.length - 1 && <div className="mt-4 border-t border-white/[0.05]" />}
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─── Competitive Intelligence Matrix ─────────────────────────────────────────

function CompetitiveMatrixSection({ matrix, companyName }: { matrix: FullReport["competitiveMatrix"]; companyName: string }) {
  if (!matrix || (!matrix.competitors.length && !matrix.targetMoats.length)) return null;

  const METRIC_ROWS: Array<{ label: string; key: keyof CompetitorProfile }> = [
    { label: "Pricing Model",    key: "pricingModel" },
    { label: "Market Share Est.", key: "marketShareEstimate" },
    { label: "Tech Stack",       key: "techStackIndicators" },
    { label: "Hiring Trend",     key: "hiringTrends" },
    { label: "Key Moat",         key: "keyMoat" },
    { label: "Key Vulnerability",key: "keyVulnerability" },
  ];

  return (
    <section>
      <SectionHeader icon={BarChart2} label="Competitive Intelligence Matrix" color="blue" />

      {/* Moats & Vulnerabilities */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {matrix.targetMoats.length > 0 && (
          <div className="bg-emerald-500/5 border border-emerald-500/15 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4 text-emerald-400" />
              <p className="text-emerald-300 font-bold text-sm">{companyName} — Structural Moats</p>
            </div>
            <ul className="space-y-2">
              {matrix.targetMoats.map((m, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                  <span className="text-white/65 text-sm">{m}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
        {matrix.targetVulnerabilities.length > 0 && (
          <div className="bg-red-500/5 border border-red-500/15 rounded-2xl p-5">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle className="w-4 h-4 text-red-400" />
              <p className="text-red-300 font-bold text-sm">{companyName} — Structural Gaps</p>
            </div>
            <ul className="space-y-2">
              {matrix.targetVulnerabilities.map((v, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-red-400 mt-1.5 shrink-0" />
                  <span className="text-white/65 text-sm">{v}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Comparison Table */}
      {matrix.competitors.length > 0 && (
        <>
          <div className="overflow-x-auto rounded-2xl border border-white/[0.06]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/[0.06] bg-white/[0.02]">
                  <th className="text-left text-white/35 font-semibold px-4 py-3 text-xs uppercase tracking-wider w-32">Metric</th>
                  {matrix.competitors.map(c => (
                    <th key={c.name} className="text-left text-white/70 font-bold px-4 py-3">{c.name}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {METRIC_ROWS.map((row, ri) => (
                  <tr key={row.key} className={`${ri < METRIC_ROWS.length - 1 ? "border-b border-white/[0.04]" : ""} hover:bg-white/[0.015] transition-colors`}>
                    <td className="px-4 py-3 text-white/40 text-xs font-semibold whitespace-nowrap align-top">{row.label}</td>
                    {matrix.competitors.map(c => (
                      <td key={c.name} className={`px-4 py-3 text-sm align-top leading-relaxed ${row.key === "keyMoat" ? "text-emerald-300/70" : row.key === "keyVulnerability" ? "text-red-300/70" : "text-white/55"}`}>
                        {c[row.key] || <span className="text-white/20 italic">Not available</span>}
                      </td>
                    ))}
                  </tr>
                ))}
                <tr className="border-t border-white/[0.06] bg-white/[0.01]">
                  <td className="px-4 py-3 text-white/40 text-xs font-semibold whitespace-nowrap">vs {companyName}</td>
                  {matrix.competitors.map(c => (
                    <td key={c.name} className="px-4 py-3 text-xs text-white/45 italic leading-relaxed">{c.vsTargetCompany}</td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
          {matrix.benchmarkSummary && (
            <div className="mt-4 bg-white/[0.02] border border-white/[0.06] rounded-xl px-5 py-4">
              <p className="text-xs font-semibold text-white/35 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <BarChart2 className="w-3 h-3" /> Benchmark Summary
              </p>
              <p className="text-white/60 text-sm leading-relaxed">{matrix.benchmarkSummary}</p>
            </div>
          )}
        </>
      )}
    </section>
  );
}

// ─── Scenario Builder ─────────────────────────────────────────────────────────

const PRESET_SCENARIOS = [
  { label: "Recession / economic downturn", icon: "📉" },
  { label: "Competitor launches free tier", icon: "🆓" },
  { label: "Key AI regulation passed", icon: "⚖️" },
  { label: "Inflation rises 3%", icon: "💸" },
  { label: "New competitor raises $1B", icon: "💰" },
  { label: "Interest rates rise 2%", icon: "📈" },
];

function ScenarioBuilder({
  activeScenario, scenarioNote, refining, onSimulate, onReset,
}: {
  activeScenario: string | null;
  scenarioNote: string | null;
  refining: boolean;
  onSimulate: (scenario: string) => void;
  onReset: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [custom, setCustom] = useState("");

  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
      {/* Active scenario banner */}
      {activeScenario && (
        <div className="flex items-center gap-3 px-5 py-3 bg-amber-500/8 border-b border-amber-500/15">
          <FlaskConical className="w-4 h-4 text-amber-400 shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-amber-300 text-sm font-semibold">Scenario active: {activeScenario}</p>
            {scenarioNote && <p className="text-amber-300/60 text-xs mt-0.5">{scenarioNote}</p>}
          </div>
          <button onClick={onReset} className="text-xs text-white/40 hover:text-white/70 bg-white/5 border border-white/10 rounded-lg px-3 py-1 transition-all flex items-center gap-1.5">
            <X className="w-3 h-3" />Reset
          </button>
        </div>
      )}

      <button onClick={() => setOpen(p => !p)} className="w-full flex items-center justify-between px-6 py-4 hover:bg-white/[0.02] transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
            <FlaskConical className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-left">
            <p className="text-white font-bold text-sm">What-if Scenario Simulator</p>
            <p className="text-white/35 text-xs">Re-run the strategic plan under a different macro condition</p>
          </div>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>

      {open && (
        <div className="border-t border-white/[0.06] px-6 py-5 space-y-5">
          {/* Presets */}
          <div>
            <p className="text-xs text-white/35 font-semibold uppercase tracking-wider mb-3">Preset scenarios</p>
            <div className="flex flex-wrap gap-2">
              {PRESET_SCENARIOS.map(s => (
                <button
                  key={s.label}
                  onClick={() => onSimulate(s.label)}
                  disabled={refining}
                  className={`flex items-center gap-1.5 text-sm border rounded-xl px-3 py-2 transition-all disabled:opacity-40
                    ${activeScenario === s.label
                      ? "bg-amber-500/15 border-amber-500/25 text-amber-300"
                      : "bg-white/[0.03] border-white/10 text-white/60 hover:bg-white/[0.06] hover:text-white"
                    }`}
                >
                  <span>{s.icon}</span>
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          {/* Custom */}
          <div>
            <p className="text-xs text-white/35 font-semibold uppercase tracking-wider mb-3">Custom scenario</p>
            <div className="flex gap-3">
              <input
                value={custom}
                onChange={e => setCustom(e.target.value)}
                onKeyDown={e => { if (e.key === "Enter" && custom.trim() && !refining) { onSimulate(custom.trim()); setCustom(""); } }}
                placeholder='e.g. "What if our main supplier exits the market?"'
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/25 outline-none focus:border-amber-500/40 transition-all"
              />
              <button
                onClick={() => { if (custom.trim() && !refining) { onSimulate(custom.trim()); setCustom(""); } }}
                disabled={!custom.trim() || refining}
                className="flex items-center gap-2 bg-amber-500/80 hover:bg-amber-500 disabled:bg-white/5 disabled:text-white/20 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all whitespace-nowrap"
              >
                {refining ? <Loader2 className="w-4 h-4 animate-spin" /> : <FlaskConical className="w-4 h-4" />}
                Simulate
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Evidence & Sources Panel ─────────────────────────────────────────────────

function SourcesPanel({ sources }: { sources: FullReport["sources"] }) {
  const [open, setOpen] = useState(false);
  const qColor: Record<string, string> = {
    sufficient: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    partial:    "text-amber-400 bg-amber-500/10 border-amber-500/20",
    insufficient:"text-red-400 bg-red-500/10 border-red-500/20",
    full:       "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    limited:    "text-amber-400 bg-amber-500/10 border-amber-500/20",
    none:       "text-red-400 bg-red-500/10 border-red-500/20",
  };

  return (
    <div className="bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
      <button onClick={() => setOpen(p => !p)} className="w-full flex items-center justify-between px-6 py-4 hover:bg-white/[0.02] transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
            <FileText className="w-4 h-4 text-white/50" />
          </div>
          <div className="text-left">
            <p className="text-white font-bold text-sm">Evidence & Sources</p>
            <p className="text-white/35 text-xs">Raw findings from Agent 1 and Agent 2</p>
          </div>
        </div>
        {open ? <ChevronUp className="w-4 h-4 text-white/30" /> : <ChevronDown className="w-4 h-4 text-white/30" />}
      </button>

      {open && (
        <div className="border-t border-white/[0.06] px-6 py-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Agent 1 */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-lg bg-violet-500/15 border border-violet-500/25 flex items-center justify-center">
                <Database className="w-3.5 h-3.5 text-violet-400" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">Agent 1 — Data Aggregator</p>
                <span className={`text-[10px] font-semibold rounded-full px-2 py-0.5 border ${qColor[sources.agent1.dataQuality] ?? qColor.partial}`}>{sources.agent1.dataQuality}</span>
              </div>
            </div>

            <div className="mb-4">
              <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><FileText className="w-3 h-3" />SEC Filing</p>
              <div className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs ${sources.agent1.secFound ? "bg-emerald-500/8 border border-emerald-500/15 text-emerald-300" : "bg-white/[0.03] border border-white/[0.06] text-white/35"}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${sources.agent1.secFound ? "bg-emerald-400" : "bg-white/20"}`} />
                {sources.agent1.secFiling || (sources.agent1.secFound ? "Filed" : "Not found")}
              </div>
            </div>

            {sources.agent1.competitors.length > 0 && (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><Globe className="w-3 h-3" />Competitors</p>
                <div className="space-y-1.5">
                  {sources.agent1.competitors.map((c, i) => (
                    <div key={i} className="bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2">
                      <p className="text-white/70 text-xs font-semibold">{c.name}</p>
                      <p className="text-white/35 text-xs">{c.positioning}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {sources.agent1.sentimentSummary && (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><Users className="w-3 h-3" />Sentiment</p>
                <p className="text-white/50 text-xs leading-relaxed bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2">{sources.agent1.sentimentSummary}</p>
              </div>
            )}

            {sources.agent1.newsItems.length > 0 && (
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><Globe className="w-3 h-3" />News ({sources.agent1.newsItems.length})</p>
                <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                  {sources.agent1.newsItems.map((n, i) => (
                    <div key={i} className="bg-white/[0.03] border border-white/[0.06] rounded-lg px-3 py-2">
                      {n.url ? (
                        <a href={n.url} target="_blank" rel="noopener noreferrer" className="text-white/65 text-xs font-medium leading-snug hover:text-white/85 transition-colors">
                          {n.headline}
                        </a>
                      ) : (
                        <p className="text-white/65 text-xs font-medium leading-snug">{n.headline}</p>
                      )}
                      <p className="text-white/30 text-[10px] mt-0.5">{n.date} · {n.source}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Agent 2 */}
          <div>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-7 h-7 rounded-lg bg-blue-500/15 border border-blue-500/25 flex items-center justify-center">
                <BarChart2 className="w-3.5 h-3.5 text-blue-400" />
              </div>
              <div>
                <p className="text-white font-bold text-sm">Agent 2 — Quant Analyst</p>
                <span className={`text-[10px] font-semibold rounded-full px-2 py-0.5 border ${qColor[sources.agent2.dataAvailability] ?? qColor.limited}`}>{sources.agent2.dataAvailability} data</span>
              </div>
            </div>

            {sources.agent2.metrics.length > 0 ? (
              <div className="mb-4">
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><BarChart2 className="w-3 h-3" />Financial Metrics</p>
                <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-hidden">
                  <table className="w-full text-xs">
                    <thead><tr className="border-b border-white/[0.06]">
                      <th className="text-left text-white/30 font-semibold px-4 py-2.5">Metric</th>
                      <th className="text-left text-white/30 font-semibold px-4 py-2.5">Value</th>
                      <th className="text-left text-white/30 font-semibold px-4 py-2.5 hidden sm:table-cell">Source</th>
                    </tr></thead>
                    <tbody>
                      {sources.agent2.metrics.map((m, i) => (
                        <tr key={i} className={i < sources.agent2.metrics.length - 1 ? "border-b border-white/[0.04]" : ""}>
                          <td className="px-4 py-2.5 text-white/50 font-medium">{m.label}</td>
                          <td className="px-4 py-2.5 text-white/80 font-semibold">{m.value}</td>
                          <td className="px-4 py-2.5 text-white/25 hidden sm:table-cell">{m.source}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : (
              <div className="bg-white/[0.02] border border-white/[0.06] rounded-xl px-4 py-3 mb-4">
                <p className="text-white/30 text-xs">No public financial metrics extracted.</p>
              </div>
            )}

            {sources.agent2.notes && (
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2 flex items-center gap-1.5"><Info className="w-3 h-3" />Analyst Notes</p>
                <p className="text-white/40 text-xs leading-relaxed bg-white/[0.02] border border-white/[0.06] rounded-lg px-3 py-2">{sources.agent2.notes}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Bar Chart Icon ───────────────────────────────────────────────────────────

function BarChartIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="3" width="18" height="18" rx="2" /><path d="M3 9h18M9 21V9" />
    </svg>
  );
}

// ─── Business Score ───────────────────────────────────────────────────────────

const GRADE_CFG: Record<HealthGrade, { color: string; ring: string; glow: string; bg: string; border: string; label: string; sublabel: string }> = {
  "A+": { color: "text-emerald-300", ring: "#10b981", glow: "#10b98166", bg: "from-emerald-500/12 to-emerald-600/4", border: "border-emerald-500/25", label: "Exceptional", sublabel: "93–100 · Market leader tier (Apple / Microsoft)" },
  "A":  { color: "text-emerald-400", ring: "#34d399", glow: "#34d39966", bg: "from-emerald-400/10 to-emerald-500/4", border: "border-emerald-400/20", label: "Strong",       sublabel: "85–92 · Clear category leader, minor gaps" },
  "B+": { color: "text-blue-300",    ring: "#60a5fa", glow: "#60a5fa66", bg: "from-blue-400/12 to-blue-500/4",      border: "border-blue-400/25",    label: "Above Average",sublabel: "78–84 · Solid business, one notable weakness" },
  "B":  { color: "text-blue-400",    ring: "#3b82f6", glow: "#3b82f666", bg: "from-blue-500/10 to-blue-600/4",      border: "border-blue-500/20",    label: "Solid",        sublabel: "70–77 · Competitive but meaningful headwinds" },
  "C+": { color: "text-amber-300",   ring: "#fcd34d", glow: "#fcd34d66", bg: "from-amber-400/12 to-amber-500/4",    border: "border-amber-400/25",   label: "Average+",     sublabel: "62–69 · Moderate resilience, watch for execution risk" },
  "C":  { color: "text-amber-400",   ring: "#f59e0b", glow: "#f59e0b66", bg: "from-amber-500/10 to-amber-600/4",    border: "border-amber-500/20",   label: "Moderate",     sublabel: "50–61 · Significant financial or competitive gaps" },
  "D":  { color: "text-orange-300",  ring: "#f97316", glow: "#f9731666", bg: "from-orange-500/12 to-orange-600/4",  border: "border-orange-500/25",  label: "Below Average",sublabel: "35–49 · Distressed signals, high execution risk" },
  "F":  { color: "text-red-300",     ring: "#ef4444", glow: "#ef444466", bg: "from-red-500/12 to-red-600/4",        border: "border-red-500/25",     label: "At Risk",      sublabel: "0–34 · Severe operational or financial threats" },
};

// Score-value-driven colors: 16-20 = green, 11-15 = amber, 0-10 = red
function scoreColor(n: number) {
  if (n >= 16) return {
    bar:   "bg-emerald-400",
    dot:   "bg-emerald-400",
    badge: "bg-emerald-500/15 border-emerald-500/25 text-emerald-300",
    label: "Strong",
    status:"text-emerald-300",
  };
  if (n >= 11) return {
    bar:   "bg-amber-400",
    dot:   "bg-amber-400",
    badge: "bg-amber-500/15 border-amber-500/25 text-amber-300",
    label: "Watch List",
    status:"text-amber-300",
  };
  return {
    bar:   "bg-red-400",
    dot:   "bg-red-400",
    badge: "bg-red-500/15 border-red-500/25 text-red-300",
    label: "Priority Area",
    status:"text-red-300",
  };
}

const CATEGORY_ICONS: Record<string, React.ElementType> = {
  "Market Attractiveness": TrendingUp,
  "Competitive Moat":      Shield,
  "Execution Capability":  Zap,
  "Financial Health":      BarChart2,
  "Risk & Vulnerability":  AlertTriangle,
};

const CATEGORY_SUBLABELS: Record<string, string> = {
  "Market Attractiveness": "TAM · Industry growth · Market trends",
  "Competitive Moat":      "Pricing power · IP · Switching costs & brand",
  "Execution Capability":  "Leadership · Agility · Supply chain",
  "Financial Health":      "Margin · Capital intensity · Revenue diversity",
  "Risk & Vulnerability":  "Regulatory exposure · Churn · Concentration",
};

function ScoreRing({ score, ring, glow }: { score: number; ring: string; glow: string }) {
  const R = 52, C = 2 * Math.PI * R;
  const pct = Math.max(0, Math.min(1, score / 100));
  return (
    <svg width={128} height={128} viewBox="0 0 128 128" style={{ transform: "rotate(-90deg)" }}>
      <circle cx={64} cy={64} r={R} fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth={11} />
      <circle
        cx={64} cy={64} r={R} fill="none"
        stroke={ring} strokeWidth={11} strokeLinecap="round"
        strokeDasharray={`${C * pct} ${C}`}
        style={{ filter: `drop-shadow(0 0 10px ${glow})`, transition: "stroke-dasharray 1.2s ease" }}
      />
    </svg>
  );
}

function DeltaBadge({ delta }: { delta: number }) {
  if (delta === 0) return (
    <span className="text-[10px] font-bold rounded-full px-2 py-0.5 border bg-white/5 border-white/15 text-white/35 inline-flex items-center gap-0.5">
      <Minus className="w-2.5 h-2.5" />0
    </span>
  );
  const up = delta > 0;
  return (
    <span className={`text-[10px] font-bold rounded-full px-2 py-0.5 border inline-flex items-center gap-0.5 ${up ? "bg-emerald-500/15 border-emerald-500/25 text-emerald-300" : "bg-red-500/15 border-red-500/25 text-red-300"}`}>
      {up ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingUp className="w-2.5 h-2.5 rotate-180" />}
      {up ? "+" : ""}{delta}
    </span>
  );
}

function CategoryCard({ cat, index, delta }: { cat: CategoryScore; index: number; delta?: number | null }) {
  const [open, setOpen] = useState(false);
  const sc = scoreColor(cat.score);
  const pct = (cat.score / 20) * 100;
  const Icon = CATEGORY_ICONS[cat.categoryName] ?? Target;
  const sublabel = CATEGORY_SUBLABELS[cat.categoryName] ?? "";

  return (
    <div className="bg-white/[0.025] border border-white/[0.07] rounded-2xl overflow-hidden">
      <button
        onClick={() => setOpen(p => !p)}
        className="w-full flex items-center gap-4 px-5 py-4 hover:bg-white/[0.02] transition-colors"
      >
        {/* Number + icon */}
        <div className="flex items-center gap-2.5 shrink-0">
          <span className="text-white/20 text-xs font-bold w-4 text-right">{index + 1}</span>
          <div className="w-8 h-8 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center">
            <Icon className={`w-4 h-4 ${sc.status}`} />
          </div>
        </div>

        {/* Name + sublabel + bar */}
        <div className="flex-1 min-w-0 text-left">
          <div className="flex items-baseline gap-2 mb-1.5">
            <p className="text-white font-bold text-sm">{cat.categoryName}</p>
            <span className="text-white/25 text-[10px] hidden sm:block">{sublabel}</span>
          </div>
          <div className="h-2 bg-white/[0.06] rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${sc.bar}`}
              style={{ width: `${pct}%`, transition: `width 0.9s ease ${index * 80}ms` }}
            />
          </div>
        </div>

        {/* Score + delta + status badge + chevron */}
        <div className="flex items-center gap-2 shrink-0">
          {delta != null && <DeltaBadge delta={delta} />}
          <span className={`text-[10px] font-bold rounded-full px-2 py-0.5 border hidden sm:inline-flex items-center gap-1 ${sc.badge}`}>
            <span className={`w-1 h-1 rounded-full ${sc.dot}`} />
            {sc.label}
          </span>
          <span className={`text-xl font-black tabular-nums ${sc.status}`}>
            {cat.score}<span className="text-white/25 text-xs font-normal">/20</span>
          </span>
          {open ? <ChevronUp className="w-4 h-4 text-white/25" /> : <ChevronDown className="w-4 h-4 text-white/25" />}
        </div>
      </button>

      {open && (
        <div className="border-t border-white/[0.05] px-5 pb-5 pt-4 space-y-3">
          <p className="text-white/55 text-sm leading-relaxed">{cat.rationale}</p>
          {cat.subCriteria.length > 0 && (
            <div className="space-y-2">
              {cat.subCriteria.map((sub, i) => (
                <div key={i} className="flex items-start gap-3 bg-white/[0.03] border border-white/[0.06] rounded-xl px-4 py-3">
                  <span className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${sc.dot}`} />
                  <div className="flex-1 min-w-0">
                    <span className="text-white/40 text-[10px] font-bold uppercase tracking-wider">{sub.label}</span>
                    <p className="text-white/65 text-sm mt-0.5 leading-relaxed">{sub.finding}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Scorecard Modal ──────────────────────────────────────────────────────────

// Inline-style colour maps for html2canvas compatibility (no Tailwind vars)
const GRADE_HEX: Record<HealthGrade, { ring: string; text: string; bg: string; border: string }> = {
  "A+": { ring: "#10b981", text: "#6ee7b7", bg: "rgba(16,185,129,0.12)", border: "rgba(16,185,129,0.25)" },
  "A":  { ring: "#34d399", text: "#6ee7b7", bg: "rgba(52,211,153,0.10)", border: "rgba(52,211,153,0.20)" },
  "B+": { ring: "#60a5fa", text: "#93c5fd", bg: "rgba(96,165,250,0.12)", border: "rgba(96,165,250,0.25)" },
  "B":  { ring: "#3b82f6", text: "#93c5fd", bg: "rgba(59,130,246,0.10)", border: "rgba(59,130,246,0.20)" },
  "C+": { ring: "#fcd34d", text: "#fde68a", bg: "rgba(252,211,77,0.12)",  border: "rgba(252,211,77,0.25)" },
  "C":  { ring: "#f59e0b", text: "#fcd34d", bg: "rgba(245,158,11,0.10)",  border: "rgba(245,158,11,0.20)" },
  "D":  { ring: "#f97316", text: "#fdba74", bg: "rgba(249,115,22,0.12)",  border: "rgba(249,115,22,0.25)" },
  "F":  { ring: "#ef4444", text: "#fca5a5", bg: "rgba(239,68,68,0.12)",   border: "rgba(239,68,68,0.25)" },
};

function catBarColor(score: number): string {
  if (score >= 16) return "#10b981";
  if (score >= 11) return "#f59e0b";
  return "#ef4444";
}

function catTextColor(score: number): string {
  if (score >= 16) return "#6ee7b7";
  if (score >= 11) return "#fcd34d";
  return "#fca5a5";
}

// The actual branded card — captured by html2canvas
function ScorecardCard({ score, companyName, cardRef }: {
  score: BusinessScore;
  companyName: string;
  cardRef: React.RefObject<HTMLDivElement | null>;
}) {
  const gh = GRADE_HEX[score.healthGrade] ?? GRADE_HEX["C"];
  const today = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const R = 52, C = 2 * Math.PI * R;
  const pct = Math.max(0, Math.min(1, score.overallScore / 100));

  return (
    <div
      ref={cardRef}
      style={{
        width: 680,
        background: "#08080f",
        borderRadius: 20,
        overflow: "hidden",
        fontFamily: "system-ui, -apple-system, 'Segoe UI', sans-serif",
        color: "#fff",
        border: "1px solid rgba(255,255,255,0.08)",
      }}
    >
      {/* Header */}
      <div style={{ background: "rgba(255,255,255,0.03)", borderBottom: "1px solid rgba(255,255,255,0.07)", padding: "20px 28px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.1em", color: "rgba(255,255,255,0.3)", textTransform: "uppercase", marginBottom: 3 }}>Business Scorecard</div>
          <div style={{ fontSize: 20, fontWeight: 900, color: "#fff" }}>{companyName}</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div style={{ fontSize: 10, color: "rgba(255,255,255,0.25)", marginBottom: 2 }}>Generated</div>
          <div style={{ fontSize: 11, fontWeight: 600, color: "rgba(255,255,255,0.45)" }}>{today}</div>
        </div>
      </div>

      {/* Hero — score ring + grade */}
      <div style={{ padding: "28px 28px 20px", background: gh.bg, borderBottom: `1px solid ${gh.border}`, display: "flex", alignItems: "center", gap: 28 }}>
        {/* SVG ring */}
        <div style={{ position: "relative", flexShrink: 0, width: 128, height: 128 }}>
          <svg width={128} height={128} viewBox="0 0 128 128" style={{ transform: "rotate(-90deg)" }}>
            <circle cx={64} cy={64} r={R} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth={11} />
            <circle cx={64} cy={64} r={R} fill="none" stroke={gh.ring} strokeWidth={11} strokeLinecap="round"
              strokeDasharray={`${C * pct} ${C}`} />
          </svg>
          <div style={{ position: "absolute", inset: 0, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }}>
            <span style={{ fontSize: 36, fontWeight: 900, lineHeight: 1, color: gh.text }}>{score.overallScore}</span>
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 2 }}>/ 100</span>
          </div>
        </div>

        {/* Grade + summary */}
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
            <span style={{ fontSize: 52, fontWeight: 900, lineHeight: 1, color: gh.text }}>{score.healthGrade}</span>
            <div>
              <div style={{ fontSize: 18, fontWeight: 900, color: gh.text }}>{GRADE_CFG[score.healthGrade]?.label ?? ""}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.3)", marginTop: 2 }}>{GRADE_CFG[score.healthGrade]?.sublabel ?? ""}</div>
            </div>
          </div>
          <p style={{ fontSize: 13, color: "rgba(255,255,255,0.55)", lineHeight: 1.6, margin: 0 }}>{score.executiveSummary}</p>
        </div>
      </div>

      {/* Category bars */}
      <div style={{ padding: "20px 28px 0" }}>
        <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em", color: "rgba(255,255,255,0.25)", textTransform: "uppercase", marginBottom: 12 }}>Category Breakdown</div>
        {score.categories.map(cat => {
          const barPct = (cat.score / 20) * 100;
          const barColor = catBarColor(cat.score);
          const textColor = catTextColor(cat.score);
          return (
            <div key={cat.categoryName} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 5 }}>
                <span style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.8)" }}>{cat.categoryName}</span>
                <span style={{ fontSize: 13, fontWeight: 900, color: textColor }}>{cat.score}<span style={{ fontSize: 10, fontWeight: 400, color: "rgba(255,255,255,0.25)" }}>/20</span></span>
              </div>
              <div style={{ height: 6, background: "rgba(255,255,255,0.06)", borderRadius: 99, overflow: "hidden" }}>
                <div style={{ height: "100%", width: `${barPct}%`, background: barColor, borderRadius: 99 }} />
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick wins */}
      {score.quickWins.length > 0 && (
        <div style={{ padding: "16px 28px 20px" }}>
          <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.1em", color: "rgba(255,255,255,0.25)", textTransform: "uppercase", marginBottom: 10 }}>Top Quick Wins</div>
          {score.quickWins.slice(0, 3).map((win, i) => (
            <div key={i} style={{ display: "flex", gap: 10, marginBottom: 8, alignItems: "flex-start" }}>
              <div style={{ flexShrink: 0, width: 18, height: 18, borderRadius: "50%", background: "rgba(124,58,237,0.25)", border: "1px solid rgba(124,58,237,0.35)", display: "flex", alignItems: "center", justifyContent: "center", marginTop: 1 }}>
                <span style={{ fontSize: 9, fontWeight: 900, color: "#a78bfa" }}>{i + 1}</span>
              </div>
              <p style={{ fontSize: 12, color: "rgba(255,255,255,0.70)", lineHeight: 1.55, margin: 0 }}>{win}</p>
            </div>
          ))}
        </div>
      )}

      {/* Footer */}
      <div style={{ padding: "12px 28px", borderTop: "1px solid rgba(255,255,255,0.06)", background: "rgba(255,255,255,0.01)", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.12em", color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>StrategyOS · AI Business Intelligence</span>
        <span style={{ fontSize: 10, color: "rgba(255,255,255,0.15)" }}>Powered by multi-agent analysis</span>
      </div>
    </div>
  );
}

function ScorecardModal({ score, companyName, onClose }: {
  score: BusinessScore;
  companyName: string;
  onClose: () => void;
}) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [copying, setCopying] = useState(false);
  const [copied, setCopied] = useState(false);

  async function captureCanvas(): Promise<HTMLCanvasElement> {
    if (!cardRef.current) throw new Error("Card not mounted");
    return html2canvas(cardRef.current, {
      scale: 2,
      backgroundColor: "#08080f",
      useCORS: true,
      logging: false,
    });
  }

  async function downloadPng() {
    setDownloading(true);
    try {
      const canvas = await captureCanvas();
      const url = canvas.toDataURL("image/png");
      const a = Object.assign(document.createElement("a"), {
        href: url,
        download: `${companyName.replace(/\s+/g, "-")}-scorecard.png`,
      });
      a.click();
    } catch (e) {
      console.error("PNG export failed", e);
    } finally {
      setDownloading(false);
    }
  }

  async function copyImage() {
    setCopying(true);
    try {
      const canvas = await captureCanvas();
      canvas.toBlob(async blob => {
        if (!blob) return;
        await navigator.clipboard.write([
          new ClipboardItem({ "image/png": blob }),
        ]);
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      }, "image/png");
    } catch (e) {
      console.error("Copy failed", e);
    } finally {
      setCopying(false);
    }
  }

  // Close on backdrop click
  function handleBackdrop(e: React.MouseEvent<HTMLDivElement>) {
    if (e.target === e.currentTarget) onClose();
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: "rgba(0,0,0,0.75)", backdropFilter: "blur(4px)" }}
      onClick={handleBackdrop}
    >
      <div className="relative w-full max-w-3xl" style={{ maxHeight: "90vh", overflowY: "auto" }}>
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute -top-3 -right-3 z-10 w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 border border-white/15 flex items-center justify-center transition-all"
        >
          <X className="w-4 h-4 text-white/70" />
        </button>

        {/* Modal card */}
        <div className="rounded-2xl overflow-hidden border border-white/10" style={{ background: "#0d0d1a" }}>
          {/* Modal header */}
          <div className="flex items-center gap-3 px-6 py-4 border-b border-white/[0.07]">
            <div className="w-8 h-8 rounded-lg bg-violet-500/15 border border-violet-500/25 flex items-center justify-center">
              <Share2 className="w-4 h-4 text-violet-400" />
            </div>
            <div className="flex-1">
              <p className="text-white font-bold text-sm">Share Scorecard</p>
              <p className="text-white/35 text-xs">Download as PNG or copy to clipboard</p>
            </div>
          </div>

          {/* Scorecard preview */}
          <div className="p-6 flex justify-center" style={{ background: "#07070e" }}>
            {/* Wrapper scales the 680px card to fit the modal */}
            <div style={{ transform: "scale(0.85)", transformOrigin: "top center", width: 680, marginBottom: -680 * 0.15 }}>
              <ScorecardCard score={score} companyName={companyName} cardRef={cardRef} />
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 px-6 py-5 border-t border-white/[0.07]">
            <button
              onClick={downloadPng}
              disabled={downloading}
              className="flex items-center justify-center gap-2 bg-violet-600 hover:bg-violet-500 disabled:opacity-60 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all flex-1"
            >
              {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              {downloading ? "Exporting…" : "Download PNG"}
            </button>
            <button
              onClick={copyImage}
              disabled={copying || copied}
              className="flex items-center justify-center gap-2 bg-white/5 hover:bg-white/10 disabled:opacity-60 border border-white/10 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all flex-1"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : copying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Copy className="w-4 h-4" />}
              {copied ? "Copied!" : copying ? "Copying…" : "Copy Image"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ScoreSparkline({ history, ring }: { history: number[]; ring: string }) {
  if (history.length < 2) return null;
  const W = 80, H = 32, PAD = 4;
  const min = Math.min(...history);
  const max = Math.max(...history);
  const range = max - min || 1;
  const pts = history.map((v, i) => {
    const x = PAD + (i / (history.length - 1)) * (W - PAD * 2);
    const y = H - PAD - ((v - min) / range) * (H - PAD * 2);
    return `${x},${y}`;
  }).join(" ");
  const lastX = PAD + (W - PAD * 2);
  const lastY = H - PAD - ((history[history.length - 1] - min) / range) * (H - PAD * 2);
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} className="shrink-0">
      <polyline
        points={pts}
        fill="none"
        stroke={ring}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round"
        opacity={0.6}
      />
      <circle cx={lastX} cy={lastY} r={2.5} fill={ring} opacity={0.9} />
    </svg>
  );
}

function BusinessScoreSection({
  score,
  companyName,
  prevScore,
  scoreHistory,
}: {
  score: BusinessScore;
  companyName: string;
  prevScore?: BusinessScore | null;
  scoreHistory?: number[];
}) {
  const gcfg = GRADE_CFG[score.healthGrade] ?? GRADE_CFG["C"];
  const [showScorecard, setShowScorecard] = useState(false);

  // Lowest 3 categories for the Score Booster
  const sortedByScore = [...score.categories].sort((a, b) => a.score - b.score);
  const bottom3 = sortedByScore.slice(0, 3);

  // Build a map of category deltas vs previous analysis
  const categoryDeltas = useMemo<Record<string, number>>(() => {
    if (!prevScore) return {};
    const map: Record<string, number> = {};
    for (const cat of score.categories) {
      const prev = prevScore.categories.find(c => c.categoryName === cat.categoryName);
      if (prev) map[cat.categoryName] = cat.score - prev.score;
    }
    return map;
  }, [score, prevScore]);

  const overallDelta = prevScore != null ? score.overallScore - prevScore.overallScore : null;

  return (
    <section>
      {showScorecard && (
        <ScorecardModal score={score} companyName={companyName} onClose={() => setShowScorecard(false)} />
      )}

      {/* ── Hero banner ── */}
      <div className={`relative bg-gradient-to-br ${gcfg.bg} border ${gcfg.border} rounded-2xl p-6 md:p-8 mb-5 overflow-hidden`}>
        <div className="absolute -top-16 -right-16 w-64 h-64 rounded-full opacity-[0.07] blur-3xl pointer-events-none" style={{ background: gcfg.ring }} />

        {/* Share button — top-right corner */}
        <button
          onClick={() => setShowScorecard(true)}
          className="absolute top-4 right-4 flex items-center gap-1.5 bg-white/8 hover:bg-white/15 border border-white/15 text-white/70 hover:text-white font-semibold rounded-xl px-3 py-1.5 text-xs transition-all z-10"
        >
          <Share2 className="w-3.5 h-3.5" />
          Share Scorecard
        </button>

        <div className="relative flex flex-col md:flex-row items-center gap-6 md:gap-10">
          {/* Ring + score */}
          <div className="relative shrink-0">
            <ScoreRing score={score.overallScore} ring={gcfg.ring} glow={gcfg.glow} />
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <span className={`text-5xl font-black leading-none ${gcfg.color}`}>{score.overallScore}</span>
              <span className="text-white/30 text-[11px] font-medium mt-0.5">/ 100</span>
            </div>
          </div>

          {/* Grade block */}
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center gap-3 mb-1 justify-center md:justify-start">
              <span className={`text-6xl font-black leading-none ${gcfg.color}`}>{score.healthGrade}</span>
              <div>
                <p className={`text-xl font-black ${gcfg.color}`}>{gcfg.label}</p>
                <p className="text-white/30 text-xs mt-0.5">{gcfg.sublabel}</p>
              </div>
            </div>

            {/* Overall trend row */}
            {(overallDelta != null || (scoreHistory && scoreHistory.length >= 2)) && (
              <div className="flex items-center gap-3 mt-2 justify-center md:justify-start">
                {overallDelta != null && (
                  <span className={`text-xs font-bold rounded-full px-2.5 py-1 border inline-flex items-center gap-1 ${
                    overallDelta > 0  ? "bg-emerald-500/15 border-emerald-500/30 text-emerald-300" :
                    overallDelta < 0  ? "bg-red-500/15 border-red-500/30 text-red-300" :
                                        "bg-white/5 border-white/15 text-white/40"
                  }`}>
                    {overallDelta > 0 ? <TrendingUp className="w-3 h-3" /> : overallDelta < 0 ? <TrendingUp className="w-3 h-3 rotate-180" /> : <Minus className="w-3 h-3" />}
                    {overallDelta > 0 ? "+" : ""}{overallDelta} vs previous
                  </span>
                )}
                {scoreHistory && scoreHistory.length >= 2 && (
                  <ScoreSparkline history={scoreHistory} ring={gcfg.ring} />
                )}
              </div>
            )}

            <p className="text-white/55 text-sm leading-relaxed max-w-xl mt-3">{score.executiveSummary}</p>

            {/* 5-pill summary */}
            <div className="flex flex-wrap gap-2 mt-4 justify-center md:justify-start">
              {score.categories.map(cat => {
                const sc = scoreColor(cat.score);
                const d = categoryDeltas[cat.categoryName];
                return (
                  <div key={cat.categoryName} className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-full px-3 py-1">
                    <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${sc.dot}`} />
                    <span className="text-white/40 text-xs">{cat.categoryName.split(" ")[0]}</span>
                    <span className={`text-xs font-black ${sc.status}`}>{cat.score}</span>
                    {d != null && (
                      <span className={`text-[10px] font-bold ml-0.5 ${d > 0 ? "text-emerald-400" : d < 0 ? "text-red-400" : "text-white/30"}`}>
                        {d > 0 ? `+${d}` : d < 0 ? `${d}` : ""}
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ── Grade legend ── */}
      <div className="flex flex-wrap gap-1.5 mb-5">
        {(["A+","A","B+","B","C+","C","D","F"] as HealthGrade[]).map(g => {
          const cfg = GRADE_CFG[g];
          const active = g === score.healthGrade;
          return (
            <div key={g} className={`flex items-center gap-1.5 rounded-full px-3 py-1 border text-xs font-bold transition-all ${active ? `${cfg.bg.replace("from-","bg-").split(" ")[0]} ${cfg.border} ${cfg.color}` : "bg-white/[0.03] border-white/[0.06] text-white/25"}`}>
              {g} <span className={`font-normal text-[10px] ${active ? cfg.color : "text-white/20"}`}>{cfg.label}</span>
            </div>
          );
        })}
      </div>

      {/* ── 5 category breakdown bars ── */}
      <div className="space-y-3 mb-5">
        {score.categories.map((cat, i) => (
          <CategoryCard
            key={cat.categoryName}
            cat={cat}
            index={i}
            delta={categoryDeltas[cat.categoryName] != null ? categoryDeltas[cat.categoryName] : null}
          />
        ))}
      </div>

      {/* ── Score Booster card ── */}
      {score.quickWins.length > 0 && (
        <div className="bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden">
          {/* Header */}
          <div className="flex items-center gap-3 px-6 py-4 border-b border-white/[0.06] bg-violet-500/[0.04]">
            <div className="w-9 h-9 rounded-xl bg-violet-500/15 border border-violet-500/25 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 text-violet-400" />
            </div>
            <div>
              <p className="text-white font-bold">How to Increase This Score</p>
              <p className="text-white/30 text-xs">Top 3 high-impact actions targeting your lowest-scoring categories</p>
            </div>
          </div>

          {/* Booster rows — each paired with its lowest category */}
          <div className="divide-y divide-white/[0.05]">
            {score.quickWins.slice(0, 3).map((win, i) => {
              const cat = bottom3[i];
              const sc = cat ? scoreColor(cat.score) : scoreColor(0);
              return (
                <div key={i} className="flex items-start gap-4 px-6 py-4 hover:bg-white/[0.015] transition-colors">
                  {/* Category tag */}
                  {cat && (
                    <div className="shrink-0 flex flex-col items-center gap-1 pt-0.5 w-20 text-center">
                      <span className={`text-lg font-black tabular-nums ${sc.status}`}>{cat.score}<span className="text-xs font-normal text-white/25">/20</span></span>
                      <span className={`text-[9px] font-bold rounded-full px-2 py-0.5 border ${sc.badge}`}>{sc.label}</span>
                      <span className="text-white/30 text-[9px] leading-tight mt-0.5">{cat.categoryName.split(" ")[0]}</span>
                    </div>
                  )}
                  {/* Action */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="w-5 h-5 rounded-full bg-violet-500/20 border border-violet-500/25 flex items-center justify-center shrink-0">
                        <span className="text-violet-300 text-[10px] font-bold">{i + 1}</span>
                      </div>
                      <span className="text-white/30 text-xs font-medium">Action</span>
                    </div>
                    <p className="text-white/80 text-sm leading-relaxed">{win}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </section>
  );
}

// ─── Landing Page Generator ───────────────────────────────────────────────────

function LandingPageGenerator({ report }: { report: FullReport }) {
  const [status, setStatus]   = useState<"idle" | "loading" | "done" | "error">("idle");
  const [html, setHtml]       = useState<string | null>(null);
  const [error, setError]     = useState<string | null>(null);
  const [copied, setCopied]   = useState(false);
  const [preview, setPreview] = useState<"desktop" | "mobile">("desktop");
  const [style, setStyle]     = useState<"dark-glass" | "light-minimal" | "bold-gradient">("dark-glass");

  const STYLE_OPTIONS = [
    { value: "dark-glass",    label: "Dark Glass",    swatch: "linear-gradient(135deg, #0f172a 0%, #164e63 100%)" },
    { value: "light-minimal", label: "Light Minimal", swatch: "linear-gradient(135deg, #f9fafb 0%, #e0e7ff 100%)" },
    { value: "bold-gradient", label: "Bold Gradient", swatch: "linear-gradient(135deg, #c026d3 0%, #4f46e5 100%)" },
  ] as const;

  async function generate() {
    setStatus("loading");
    setError(null);
    try {
      const res = await fetch("/api/v3/generate-landing-page", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          companyName:         report.companyName,
          executiveSummary:    report.executiveSummary,
          strategicPriorities: report.strategicPriorities,
          quickWins:           report.businessScore?.quickWins ?? [],
          businessScore:       report.businessScore,
          competitiveMatrix:   report.competitiveMatrix,
          keyOpportunities:    report.keyOpportunities,
          style,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) throw new Error(data.error ?? "Generation failed");
      setHtml(data.html);
      setStatus("done");
    } catch (err: any) {
      setError(err?.message ?? "Something went wrong");
      setStatus("error");
    }
  }

  function downloadHtml() {
    if (!html) return;
    const blob = new Blob([html], { type: "text/html" });
    const url  = URL.createObjectURL(blob);
    const a    = Object.assign(document.createElement("a"), { href: url, download: "index.html" });
    a.click();
    URL.revokeObjectURL(url);
  }

  async function copyHtml() {
    if (!html) return;
    await navigator.clipboard.writeText(html);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  function openInNewTab() {
    if (!html) return;
    const blob = new Blob([html], { type: "text/html" });
    window.open(URL.createObjectURL(blob), "_blank");
  }

  return (
    /* ── Outer card: slate-900 background matching the user's spec ── */
    <div className="rounded-xl overflow-hidden" style={{ background: "#0f172a" }}>

      {/* ── Header bar ── */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 px-6 py-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.08)" }}>
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0" style={{ background: "rgba(99,102,241,0.2)", border: "1px solid rgba(99,102,241,0.35)" }}>
            <Globe className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="min-w-0">
            <p className="text-white font-bold text-base">V3: Generated Strategic Landing Page</p>
            <p className="text-white/40 text-xs">AI copywriter · Tailwind CSS · ready to deploy</p>
          </div>
        </div>

        {/* Action buttons — always render the row; show contextually */}
        <div className="flex items-center gap-2 flex-wrap">
          {status !== "loading" && (
            <div className="flex items-center gap-1 rounded-lg p-1" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
              {STYLE_OPTIONS.map(opt => (
                <button
                  key={opt.value}
                  onClick={() => setStyle(opt.value)}
                  title={opt.label}
                  className="flex items-center gap-1.5 px-2.5 py-1.5 rounded text-xs transition-all"
                  style={{
                    background: style === opt.value ? "rgba(255,255,255,0.1)" : "transparent",
                    color: style === opt.value ? "#fff" : "rgba(255,255,255,0.35)",
                  }}
                >
                  <span className="w-3 h-3 rounded-full shrink-0" style={{ background: opt.swatch, border: "1px solid rgba(255,255,255,0.25)" }} />
                  {opt.label}
                </button>
              ))}
            </div>
          )}
          {status === "idle" || status === "error" ? (
            <button
              onClick={generate}
              className="flex items-center gap-2 text-sm font-semibold text-white rounded-lg px-4 py-2 transition-all"
              style={{ background: "#4f46e5" }}
              onMouseEnter={e => (e.currentTarget.style.background = "#4338ca")}
              onMouseLeave={e => (e.currentTarget.style.background = "#4f46e5")}
            >
              <Sparkles className="w-4 h-4" />
              {status === "error" ? "Retry" : "Generate Page"}
            </button>
          ) : null}

          {status === "done" && (
            <>
              <button
                onClick={generate}
                className="flex items-center gap-1.5 text-sm font-semibold text-white rounded-lg px-4 py-2 transition-all"
                style={{ background: "#334155" }}
                onMouseEnter={e => (e.currentTarget.style.background = "#475569")}
                onMouseLeave={e => (e.currentTarget.style.background = "#334155")}
              >
                <RefreshCcw className="w-3.5 h-3.5" />Regenerate
              </button>
              <button
                onClick={copyHtml}
                className="flex items-center gap-1.5 text-sm font-semibold text-white rounded-lg px-4 py-2 transition-all"
                style={{ background: copied ? "#065f46" : "#334155" }}
                onMouseEnter={e => { if (!copied) e.currentTarget.style.background = "#4f46e5"; }}
                onMouseLeave={e => { if (!copied) e.currentTarget.style.background = "#334155"; }}
              >
                {copied ? <CheckCircle2 className="w-3.5 h-3.5" /> : <Code2 className="w-3.5 h-3.5" />}
                {copied ? "Copied!" : "Copy HTML Code"}
              </button>
              <button
                onClick={downloadHtml}
                className="flex items-center gap-1.5 text-sm font-semibold text-white rounded-lg px-4 py-2 transition-all"
                style={{ background: "#4f46e5" }}
                onMouseEnter={e => (e.currentTarget.style.background = "#4338ca")}
                onMouseLeave={e => (e.currentTarget.style.background = "#4f46e5")}
              >
                <Download className="w-3.5 h-3.5" />Download index.html
              </button>
              <button
                onClick={openInNewTab}
                className="flex items-center gap-1.5 text-sm text-white/50 hover:text-white/80 rounded-lg px-3 py-2 transition-all"
                style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)" }}
              >
                <ExternalLink className="w-3.5 h-3.5" />Open
              </button>
            </>
          )}
        </div>
      </div>

      {/* ── Loading ── */}
      {status === "loading" && (
        <div className="flex flex-col items-center justify-center py-20 gap-5">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl flex items-center justify-center" style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.3)" }}>
              <Globe className="w-8 h-8 text-indigo-400" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full flex items-center justify-center" style={{ background: "#0f172a" }}>
              <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
            </div>
          </div>
          <div className="text-center">
            <p className="text-white font-semibold text-base mb-1">Building your landing page…</p>
            <p className="text-white/40 text-sm">Writing copy · Designing sections · Styling with Tailwind</p>
          </div>
          <div className="flex gap-1.5 mt-1">
            {["Hero", "Value Pillars", "Stats", "CTA", "Footer"].map((s, i) => (
              <span key={s} className="text-xs text-white/25 animate-pulse" style={{ animationDelay: `${i * 200}ms` }}>
                {s}{i < 4 ? " →" : ""}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* ── Error ── */}
      {status === "error" && error && (
        <div className="flex items-center gap-3 px-6 py-4 mx-6 my-4 rounded-xl" style={{ background: "rgba(239,68,68,0.08)", border: "1px solid rgba(239,68,68,0.2)" }}>
          <AlertTriangle className="w-4 h-4 text-red-400 shrink-0" />
          <p className="text-red-300 text-sm">{error}</p>
        </div>
      )}

      {/* ── Preview (done state) ── */}
      {status === "done" && html && (
        <div className="p-5">
          {/* Browser chrome mock + viewport toggle */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="flex gap-1.5">
                <span className="w-3 h-3 rounded-full" style={{ background: "#ef4444" }} />
                <span className="w-3 h-3 rounded-full" style={{ background: "#f59e0b" }} />
                <span className="w-3 h-3 rounded-full" style={{ background: "#10b981" }} />
              </div>
              <div className="ml-1 px-3 py-1 rounded-md text-xs font-mono" style={{ background: "rgba(255,255,255,0.05)", color: "rgba(255,255,255,0.3)", border: "1px solid rgba(255,255,255,0.07)" }}>
                index.html — {report.companyName}
              </div>
            </div>
            <div className="flex items-center gap-1 rounded-lg p-1" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}>
              {(["desktop", "mobile"] as const).map(v => (
                <button
                  key={v}
                  onClick={() => setPreview(v)}
                  className="flex items-center gap-1 px-2.5 py-1.5 rounded text-xs transition-all"
                  style={{ background: preview === v ? "rgba(255,255,255,0.1)" : "transparent", color: preview === v ? "#fff" : "rgba(255,255,255,0.35)" }}
                >
                  {v === "desktop" ? <Code2 className="w-3 h-3" /> : <MonitorSmartphone className="w-3 h-3" />}
                  {v.charAt(0).toUpperCase() + v.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* Live sandbox iframe — id="landingPagePreview" per spec */}
          <div
            className="mx-auto rounded-xl overflow-hidden transition-all duration-300"
            style={{
              maxWidth: preview === "mobile" ? 390 : "100%",
              height: 800,
              border: "1px solid #334155",
              background: "#ffffff",
            }}
          >
            <iframe
              id="landingPagePreview"
              srcDoc={html}
              sandbox="allow-scripts allow-same-origin"
              className="w-full h-full border-0"
              title={`${report.companyName} — Generated Landing Page`}
            />
          </div>
          <p className="text-center text-xs mt-3" style={{ color: "rgba(255,255,255,0.2)" }}>
            Live sandbox preview · Scripts enabled · "Open" for full page · "Download index.html" to deploy
          </p>
        </div>
      )}

      {/* ── Idle — section preview cards ── */}
      {status === "idle" && (
        <div className="px-6 pb-6 pt-5">
          <p className="text-white/40 text-sm mb-4">Generates a complete, deployable HTML file from your strategy report:</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { icon: Globe,       label: "Hero Section",     desc: "Bold headline, subheadline, primary + ghost CTA" },
              { icon: BarChart2,   label: "Value Pillars",    desc: "3 cards from your strategic priorities" },
              { icon: TrendingUp,  label: "Stats Strip",      desc: "Business Score, moats, key metrics as social proof" },
              { icon: Sparkles,    label: "CTA + Footer",     desc: "High-converting close + clean branded footer" },
            ].map(item => (
              <div key={item.label} className="flex items-start gap-3 rounded-xl p-4" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                <item.icon className="w-4 h-4 text-indigo-400/70 shrink-0 mt-0.5" />
                <div>
                  <p className="text-white/70 text-xs font-semibold mb-0.5">{item.label}</p>
                  <p className="text-white/30 text-xs leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Result View ──────────────────────────────────────────────────────────────

function ResultView({
  report, refinedSections, refining, refineMode, activeScenario, scenarioNote,
  onNew, onSimulate, onResetScenario, onRefinedApply, onEditApply, savedId,
  prevScore, scoreHistory,
}: {
  report: FullReport;
  refinedSections: RefineUpdates | null;
  refining: boolean;
  refineMode: "scenario" | "edit" | null;
  activeScenario: string | null;
  scenarioNote: string | null;
  onNew: () => void;
  onSimulate: (s: string) => void;
  onResetScenario: () => void;
  onRefinedApply: (edits: SwotEdits) => void;
  onEditApply: (edits: SwotEdits) => void;
  savedId: number | null;
  prevScore?: BusinessScore | null;
  scoreHistory?: number[];
}) {
  const [, navigate] = useLocation();
  const [editMode, setEditMode] = useState(false);
  const [edits, setEdits] = useState<SwotEdits>({});

  const IMPACT_COLORS: Record<string, string> = {
    High:   "bg-red-500/15 text-red-300 border-red-500/25",
    Medium: "bg-amber-500/15 text-amber-300 border-amber-500/25",
    Low:    "bg-emerald-500/15 text-emerald-300 border-emerald-500/25",
  };
  const TIMEFRAME_COLORS: Record<string, string> = {
    "Immediate (0-6 months)":  "bg-violet-500/15 text-violet-300 border-violet-500/25",
    "Near-term (6-18 months)": "bg-blue-500/15 text-blue-300 border-blue-500/25",
    "Long-term (18+ months)":  "bg-slate-500/15 text-slate-300 border-slate-500/25",
  };
  const PHASE_COLORS = [
    { bg: "bg-violet-500/10",  border: "border-violet-500/25",  text: "text-violet-300",  num: "bg-violet-500/20 text-violet-300" },
    { bg: "bg-blue-500/10",    border: "border-blue-500/25",    text: "text-blue-300",    num: "bg-blue-500/20 text-blue-300" },
    { bg: "bg-emerald-500/10", border: "border-emerald-500/25", text: "text-emerald-300", num: "bg-emerald-500/20 text-emerald-300" },
  ];

  const qualityConfig = {
    sufficient:   { label: "Research Complete",   color: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30" },
    partial:      { label: "Partial Research",    color: "bg-amber-500/15 text-amber-300 border-amber-500/30" },
    insufficient: { label: "Limited Public Data", color: "bg-red-500/15 text-red-300 border-red-500/30" },
  };
  const qcfg = qualityConfig[report.dataQuality] ?? qualityConfig.partial;

  // Merge base report with any refined sections
  const display = refinedSections
    ? { ...report, ...refinedSections }
    : report;

  const editChangeCount = Object.values(edits).filter(e => e.removed || e.elevated || e.editedPoint).length;

  const handleEditChange = useCallback((key: string, patch: Partial<ItemEdit>) => {
    setEdits(prev => ({ ...prev, [key]: { ...(prev[key] ?? { removed: false, elevated: false }), ...patch } }));
  }, []);

  const handleApplyEdits = () => {
    onEditApply(edits);
  };

  return (
    <main className="flex-1 px-4 md:px-8 py-10 w-full max-w-6xl mx-auto space-y-10">

      {/* Header */}
      <div>
        <button onClick={onNew} className="flex items-center gap-1.5 text-white/35 hover:text-white/65 text-sm mb-5 transition-colors">
          <ArrowLeft className="w-4 h-4" />New analysis
        </button>
        <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
          <div>
            <h1 className="text-4xl font-bold text-white tracking-tight mb-3">{report.companyName}</h1>
            <div className="flex flex-wrap items-center gap-2">
              <span className={`text-xs font-semibold rounded-full px-3 py-1 border ${qcfg.color}`}>{qcfg.label}</span>
              <span className="text-xs font-medium bg-violet-500/8 border border-violet-500/15 text-violet-400/70 rounded-full px-3 py-1">json_schema · grounded</span>
              {report.dataNote && (
                <span className="text-xs text-white/35 flex items-center gap-1"><Info className="w-3 h-3" />{report.dataNote}</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-3 shrink-0">
            {savedId != null && (
              <button
                onClick={() => navigate("/history")}
                className="flex items-center gap-2 bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/30 text-emerald-300 font-semibold rounded-xl px-4 py-2.5 text-sm transition-all"
              >
                <History className="w-4 h-4" />
                Saved — view history
              </button>
            )}
            <button onClick={onNew} className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl px-5 py-2.5 text-sm transition-all">
              <BrainCircuit className="w-4 h-4" />Analyse another
            </button>
          </div>
        </div>
      </div>

      {/* Business Score — rendered first as the headline KPI */}
      {report.businessScore && (
        <BusinessScoreSection
          score={report.businessScore}
          companyName={report.companyName}
          prevScore={prevScore}
          scoreHistory={scoreHistory}
        />
      )}

      {/* Executive Summary */}
      <section>
        <SectionHeader icon={BrainCircuit} label="Executive Summary" color="violet"
          action={refining && refineMode ? (
            <div className="flex items-center gap-1.5 text-xs text-amber-400">
              <Loader2 className="w-3.5 h-3.5 animate-spin" />Updating...
            </div>
          ) : undefined}
        />
        <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-7">
          {display.executiveSummary.split("\n\n").filter(Boolean).map((para, i) => (
            <p key={i} className={`text-white/70 leading-relaxed ${i > 0 ? "mt-4" : ""}`}>{para}</p>
          ))}
        </div>
      </section>

      {/* SWOT */}
      <section>
        <SectionHeader icon={BarChartIcon} label="SWOT Analysis" color="white"
          action={
            <div className="flex items-center gap-2">
              {editMode && editChangeCount > 0 && (
                <span className="text-xs text-amber-400 bg-amber-500/10 border border-amber-500/20 rounded-full px-2.5 py-1">
                  {editChangeCount} change{editChangeCount > 1 ? "s" : ""}
                </span>
              )}
              {editMode ? (
                <>
                  <button
                    onClick={handleApplyEdits}
                    disabled={refining}
                    className="flex items-center gap-1.5 text-xs bg-violet-600 hover:bg-violet-500 disabled:bg-white/10 text-white font-semibold rounded-xl px-4 py-2 transition-all"
                  >
                    {refining && refineMode === "edit" ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCcw className="w-3.5 h-3.5" />}
                    Regenerate Report
                  </button>
                  <button onClick={() => { setEditMode(false); setEdits({}); }} className="flex items-center gap-1.5 text-xs text-white/40 hover:text-white/70 bg-white/5 border border-white/10 rounded-xl px-4 py-2 transition-all">
                    <X className="w-3.5 h-3.5" />Cancel
                  </button>
                </>
              ) : (
                <button onClick={() => setEditMode(true)} className="flex items-center gap-1.5 text-xs text-white/50 hover:text-white bg-white/5 hover:bg-white/8 border border-white/10 rounded-xl px-4 py-2 transition-all">
                  <Pencil className="w-3.5 h-3.5" />Edit SWOT
                </button>
              )}
            </div>
          }
        />
        {editMode && (
          <div className="mb-4 flex items-start gap-2 bg-amber-500/8 border border-amber-500/15 rounded-xl px-4 py-3">
            <Pencil className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
            <p className="text-amber-300/80 text-sm">Edit mode — remove, elevate, or rewrite SWOT items. Click <strong>Regenerate Report</strong> to re-synthesize the executive summary and action plan from your revised SWOT.</p>
          </div>
        )}
        <SwotGrid swot={report.swot} editMode={editMode} edits={edits} onEditChange={handleEditChange} />
      </section>

      {/* Strategic Priorities */}
      <section>
        <SectionHeader icon={Target} label="Top 3 Strategic Priorities" color="violet" />
        <div className="space-y-4">
          {display.strategicPriorities.map((p, i) => (
            <div key={i} className="bg-white/[0.02] border border-white/10 rounded-2xl p-6 flex gap-5">
              <div className="w-10 h-10 rounded-xl bg-violet-500/15 border border-violet-500/25 flex items-center justify-center shrink-0 text-violet-300 font-bold text-lg">{i + 1}</div>
              <div className="flex-1 min-w-0">
                <h3 className="text-white font-bold mb-1.5">{p.title}</h3>
                <p className="text-white/55 text-sm leading-relaxed mb-3">{p.rationale}</p>
                <div className="flex items-start gap-2 bg-violet-500/8 border border-violet-500/15 rounded-xl px-4 py-3 mb-2">
                  <ChevronRight className="w-4 h-4 text-violet-400 mt-0.5 shrink-0" />
                  <p className="text-violet-200/70 text-sm leading-relaxed">{p.keyAction}</p>
                </div>
                {p.citation && <CitationBadge citation={p.citation} />}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Risks + Opportunities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <section>
          <SectionHeader icon={AlertOctagon} label="Major Risks" color="red" />
          <div className="space-y-3">
            {display.majorRisks.map((r, i) => (
              <div key={i} className={`bg-white/[0.02] border border-white/10 rounded-xl p-5 ${r.confidence_score === "low" ? "opacity-75" : ""}`}>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h4 className="text-white font-semibold text-sm leading-snug">{r.title}</h4>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <ConfidenceBadge score={r.confidence_score} />
                    <span className={`text-xs font-bold rounded-full px-2.5 py-0.5 border ${IMPACT_COLORS[r.impact] ?? IMPACT_COLORS.Medium}`}>{r.impact}</span>
                  </div>
                </div>
                <p className="text-white/50 text-sm leading-relaxed mb-3">{r.description}</p>
                <div className="flex items-start gap-2 bg-white/[0.03] rounded-lg px-3 py-2 mb-2">
                  <Shield className="w-3.5 h-3.5 text-white/30 mt-0.5 shrink-0" />
                  <p className="text-white/40 text-xs leading-relaxed">{r.mitigation}</p>
                </div>
                {r.citation && <CitationBadge citation={r.citation} />}
              </div>
            ))}
          </div>
        </section>

        <section>
          <SectionHeader icon={Lightbulb} label="Key Opportunities" color="blue" />
          <div className="space-y-3">
            {display.keyOpportunities.map((o, i) => (
              <div key={i} className="bg-white/[0.02] border border-white/10 rounded-xl p-5">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <h4 className="text-white font-semibold text-sm leading-snug">{o.title}</h4>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <ConfidenceBadge score={o.confidence_score} />
                    <span className={`text-xs font-semibold rounded-full px-2.5 py-0.5 border whitespace-nowrap ${TIMEFRAME_COLORS[o.timeframe] ?? "bg-blue-500/15 text-blue-300 border-blue-500/25"}`}>
                      {o.timeframe?.replace(" (0-6 months)", "")?.replace(" (6-18 months)", "")?.replace(" (18+ months)", "") ?? o.timeframe}
                    </span>
                  </div>
                </div>
                <p className="text-white/50 text-sm leading-relaxed mb-3">{o.description}</p>
                <div className="flex items-start gap-2 bg-blue-500/5 border border-blue-500/10 rounded-lg px-3 py-2 mb-2">
                  <TrendingUp className="w-3.5 h-3.5 text-blue-400/60 mt-0.5 shrink-0" />
                  <p className="text-white/40 text-xs leading-relaxed">{o.advantage}</p>
                </div>
                {o.citation && <CitationBadge citation={o.citation} />}
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Competitive Matrix */}
      {report.competitiveMatrix && (
        <CompetitiveMatrixSection matrix={report.competitiveMatrix} companyName={report.companyName} />
      )}

      {/* 90-Day Action Plan */}
      <section>
        <SectionHeader icon={CalendarDays} label="90-Day Action Plan" color="emerald"
          action={activeScenario ? (
            <span className="text-[10px] bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-full px-2.5 py-1 flex items-center gap-1">
              <FlaskConical className="w-2.5 h-2.5" />Scenario active
            </span>
          ) : undefined}
        />
        {refining && refineMode ? (
          <div className="flex items-center justify-center gap-2 py-10 text-white/40">
            <Loader2 className="w-5 h-5 animate-spin" />
            <span className="text-sm">Regenerating plan...</span>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {display.actionPlan90Days.map((phase, i) => {
              const pc = PHASE_COLORS[i] ?? PHASE_COLORS[0];
              return (
                <div key={i} className={`${pc.bg} border ${pc.border} rounded-2xl p-6`}>
                  <div className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold mb-4 ${pc.num}`}>
                    <Clock className="w-3 h-3" />{phase.phase}
                  </div>
                  <h3 className={`font-bold text-base mb-4 ${pc.text}`}>{phase.focus}</h3>
                  <ul className="space-y-2.5 mb-5">
                    {phase.actions.map((action, j) => (
                      <li key={j} className="flex items-start gap-2">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold shrink-0 mt-0.5 ${pc.num}`}>{j + 1}</div>
                        <span className="text-white/60 text-sm leading-relaxed">{action}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="border-t border-white/10 pt-4">
                    <p className="text-xs font-semibold text-white/35 uppercase tracking-wider mb-1.5">Milestone</p>
                    <p className="text-white/60 text-sm leading-relaxed">{phase.milestone}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Scenario Builder */}
      <ScenarioBuilder
        activeScenario={activeScenario}
        scenarioNote={scenarioNote}
        refining={refining}
        onSimulate={onSimulate}
        onReset={onResetScenario}
      />

      {/* Landing Page Generator */}
      <div id="landing-page" ref={(el) => {
        if (el && window.location.hash === "#landing-page") {
          requestAnimationFrame(() => el.scrollIntoView({ behavior: "smooth" }));
        }
      }}>
        <LandingPageGenerator report={report} />
      </div>

      {/* Evidence & Sources */}
      {report.sources && <SourcesPanel sources={report.sources} />}

      {/* CTA */}
      <div className="bg-gradient-to-r from-violet-600/10 to-blue-600/10 border border-violet-500/20 rounded-2xl p-8 text-center">
        <h3 className="text-xl font-bold text-white mb-2">Analyse another company</h3>
        <p className="text-white/40 text-sm mb-5">Run the three-agent pipeline on any company, startup, or organisation.</p>
        <button onClick={onNew} className="inline-flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white font-semibold rounded-xl px-6 py-3 text-sm transition-all mx-auto">
          <BrainCircuit className="w-4 h-4" />New analysis
        </button>
      </div>
    </main>
  );
}

// ─── Auto-save helper ─────────────────────────────────────────────────────────

async function saveReport(report: FullReport): Promise<number | null> {
  try {
    const res = await fetch("/api/reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        companyName: report.companyName,
        dataQuality: report.dataQuality,
        reportJson: report,
      }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.id ?? null;
  } catch {
    return null;
  }
}

// ─── Main Page & SSE Consumer ─────────────────────────────────────────────────

export default function SwotResult() {
  const [, navigate] = useLocation();
  const params = new URLSearchParams(typeof window !== "undefined" ? window.location.search : "");
  const companyName = params.get("company") ?? "";
  const additionalContext = params.get("context") ?? "";

  const [report, setReport] = useState<FullReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [agents, setAgents] = useState<Record<1|2|3, AgentState>>(makeDefaultAgents);
  const [savedId, setSavedId] = useState<number | null>(null);
  const [prevScore, setPrevScore] = useState<BusinessScore | null>(null);
  const [scoreHistory, setScoreHistory] = useState<number[]>([]);

  // Refine state
  const [refinedSections, setRefinedSections] = useState<RefineUpdates | null>(null);
  const [refining, setRefining] = useState(false);
  const [refineMode, setRefineMode] = useState<"scenario" | "edit" | null>(null);
  const [activeScenario, setActiveScenario] = useState<string | null>(null);
  const [scenarioNote, setScenarioNote] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);
  // Monotonic token — incremented on every pipeline run; async history callbacks
  // check it before writing state so a slow A-run can never overwrite B-run trends.
  const runTokenRef = useRef(0);

  function updateAgent(n: 1|2|3, patch: Partial<AgentState>) {
    setAgents(prev => ({ ...prev, [n]: { ...prev[n], ...patch } }));
  }

  const consumeSSE = useCallback(async (
    url: string,
    body: Record<string, unknown>,
    onEvent: (event: SSEEvent) => void,
    signal: AbortSignal
  ) => {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal,
    });
    if (!res.ok || !res.body) {
      const d = await res.json().catch(() => ({ error: "Request failed" }));
      throw new Error(d.error ?? "Request failed");
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buf = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;
        const payload = line.slice(6).trim();
        if (!payload) continue;
        try { onEvent(JSON.parse(payload)); } catch {}
      }
    }
  }, []);

  async function runPipeline() {
    if (!companyName) { navigate("/"); return; }
    setLoading(true); setError(null); setReport(null);
    setSavedId(null);
    // Reset trend state so a new company never shows stale deltas
    setPrevScore(null); setScoreHistory([]);
    setAgents(makeDefaultAgents());
    setRefinedSections(null); setActiveScenario(null); setScenarioNote(null);

    // Capture a stable token for this run; async callbacks must match it before
    // writing trend state so a late-finishing run-A cannot pollute run-B.
    const token = ++runTokenRef.current;

    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      await consumeSSE(
        "/api/swot/generate",
        { companyName, additionalContext },
        (event) => {
          switch (event.type) {
            case "agent_start": updateAgent(event.agent, { phase: "running", label: event.label, role: event.role, currentDetail: "", summary: {} }); break;
            case "agent_update": updateAgent(event.agent, { currentDetail: event.detail }); break;
            case "agent_complete": updateAgent(event.agent, { phase: "complete", summary: event.summary, currentDetail: "" }); break;
            case "report":
              setReport(event.data);
              setLoading(false);
              // Auto-save in background, then fetch score history for this company.
              // The token check ensures a stale callback from a previous run never
              // overwrites trend state that belongs to a newer run.
              saveReport(event.data).then(async (id) => {
                if (runTokenRef.current !== token) return; // superseded run — discard
                if (id != null) setSavedId(id);
                try {
                  const name = encodeURIComponent(event.data.companyName);
                  const res = await fetch(`/api/reports/by-company/${name}`);
                  if (runTokenRef.current !== token) return; // another run started while awaiting
                  if (res.ok) {
                    const rows: Array<{ id: number; businessScore: BusinessScore | null; createdAt: string }> = await res.json();
                    // Exclude the just-saved report; find most recent prior scored report
                    const others = rows.filter(r => r.id !== id && r.businessScore != null);
                    // Always set explicitly so stale state is never carried over
                    setPrevScore(others.length > 0 ? others[0].businessScore : null);
                    // Build sparkline: oldest → newest (include all scored rows for this company)
                    const allWithScore = rows.filter(r => r.businessScore != null);
                    const sorted = [...allWithScore].sort(
                      (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()
                    );
                    const hist = sorted.map(r => r.businessScore!.overallScore);
                    setScoreHistory(hist.length >= 2 ? hist : []);
                  } else {
                    // On fetch failure, ensure stale trends are not shown
                    setPrevScore(null);
                    setScoreHistory([]);
                  }
                } catch {
                  if (runTokenRef.current === token) {
                    setPrevScore(null);
                    setScoreHistory([]);
                  }
                }
              });
              break;
            case "error": throw new Error(event.message);
          }
        },
        ctrl.signal,
      );
    } catch (err: any) {
      if (err?.name === "AbortError") return;
      setError(err?.message ?? "Something went wrong. Please try again.");
      setLoading(false);
    }
  }

  const handleSimulate = useCallback(async (scenario: string) => {
    if (!report || refining) return;
    setRefining(true); setRefineMode("scenario");

    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      await consumeSSE(
        "/api/swot/refine",
        { report, scenario },
        (event) => {
          if (event.type === "refine_complete") {
            setRefinedSections(event.updates);
            setActiveScenario(scenario);
            setScenarioNote(event.updates.scenarioNote ?? null);
          } else if (event.type === "error") {
            throw new Error(event.message);
          }
        },
        ctrl.signal,
      );
    } catch (err: any) {
      if (err?.name !== "AbortError") console.error("Simulate error:", err);
    } finally {
      setRefining(false); setRefineMode(null);
    }
  }, [report, refining, consumeSSE]);

  const handleEditApply = useCallback(async (edits: SwotEdits) => {
    if (!report || refining) return;

    // Compute edited SWOT
    const keys = ["strengths", "weaknesses", "opportunities", "threats"] as const;
    const editedSwot: FullReport["swot"] = { strengths: [], weaknesses: [], opportunities: [], threats: [] };
    for (const k of keys) {
      const items = report.swot[k];
      const elevated = items.filter((_, i) => edits[`${k}_${i}`]?.elevated && !edits[`${k}_${i}`]?.removed)
        .map((item, i) => ({ ...item, point: edits[`${k}_${i}`]?.editedPoint ?? item.point }));
      const rest = items.filter((_, i) => !edits[`${k}_${i}`]?.elevated && !edits[`${k}_${i}`]?.removed)
        .map((item, i) => ({ ...item, point: edits[`${k}_${i}`]?.editedPoint ?? item.point }));
      editedSwot[k] = [...elevated, ...rest];
    }

    setRefining(true); setRefineMode("edit");
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      await consumeSSE(
        "/api/swot/refine",
        { report, editedSwot },
        (event) => {
          if (event.type === "refine_complete") {
            setRefinedSections(event.updates);
            setScenarioNote(null);
          } else if (event.type === "error") {
            throw new Error(event.message);
          }
        },
        ctrl.signal,
      );
    } catch (err: any) {
      if (err?.name !== "AbortError") console.error("Refine error:", err);
    } finally {
      setRefining(false); setRefineMode(null);
    }
  }, [report, refining, consumeSSE]);

  useEffect(() => {
    runPipeline();
    return () => { abortRef.current?.abort(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [companyName, additionalContext]);

  return (
    <div className="min-h-screen bg-[#080810] flex flex-col">
      <header className="flex items-center gap-3 px-8 py-5 border-b border-white/[0.06]">
        <div className="w-8 h-8 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
        </div>
        <span className="font-semibold text-white tracking-tight">StrategyOS</span>
      </header>

      <VersionNav />

      {loading  ? <LoadingView companyName={companyName} agents={agents} /> :
       error    ? <ErrorView error={error} onRetry={() => navigate("/")} /> :
       report   ? <ResultView
          report={report}
          refinedSections={refinedSections}
          refining={refining}
          refineMode={refineMode}
          activeScenario={activeScenario}
          scenarioNote={scenarioNote}
          onNew={() => navigate("/")}
          onSimulate={handleSimulate}
          onResetScenario={() => { setRefinedSections(null); setActiveScenario(null); setScenarioNote(null); }}
          onRefinedApply={() => {}}
          onEditApply={handleEditApply}
          savedId={savedId}
          prevScore={prevScore}
          scoreHistory={scoreHistory}
        /> :
       null}
    </div>
  );
}
