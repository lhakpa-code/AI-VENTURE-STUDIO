import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { useCreateBusiness, getListBusinessesQueryKey } from "@workspace/api-client-react";

import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, ArrowLeft, BrainCircuit } from "lucide-react";
import { Link } from "wouter";

const formSchema = z.object({
  name: z.string().min(2, "Business name is required"),
  industry: z.string().min(2, "Industry is required"),
  stage: z.string().min(1, "Stage is required"),
  description: z.string().optional(),
  targetMarket: z.string().optional(),
  teamSize: z.string().optional(),
  revenueRange: z.string().optional(),
  mainGoal: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function BusinessNew() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const createBusiness = useCreateBusiness();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      industry: "",
      stage: "",
      description: "",
      targetMarket: "",
      teamSize: "",
      revenueRange: "",
      mainGoal: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    createBusiness.mutate(
      { data },
      {
        onSuccess: (result) => {
          queryClient.invalidateQueries({ queryKey: getListBusinessesQueryKey() });
          // Auto-SWOT is generated on creation — redirect straight to the assessment
          if ((result as any).autoAssessmentId) {
            setLocation(`/assessments/${(result as any).autoAssessmentId}`);
          } else {
            setLocation(`/businesses/${result.id}`);
          }
        },
      }
    );
  };

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="mb-8">
        <Link href="/" className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Link>
        <h1 className="text-3xl font-bold tracking-tight">Profile Strategy Brief</h1>
        <p className="text-muted-foreground mt-2">
          Define your business identity. The more context you provide, the sharper the insights and strategies will be.
        </p>
      </div>

      <Card className="bg-card/50 backdrop-blur border-border/50">
        <CardHeader>
          <CardTitle>Core Identity</CardTitle>
          <CardDescription>Tell us the foundational elements of your operation.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Nexus Dynamics" {...field} className="bg-background/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="industry"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Industry</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="Select industry" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="SaaS">SaaS / Software</SelectItem>
                          <SelectItem value="E-commerce">E-commerce</SelectItem>
                          <SelectItem value="Agency">Agency / Services</SelectItem>
                          <SelectItem value="Fintech">Fintech</SelectItem>
                          <SelectItem value="Healthcare">Healthcare</SelectItem>
                          <SelectItem value="Hardware">Hardware / Manufacturing</SelectItem>
                          <SelectItem value="Other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="stage"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Stage</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="Select stage" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Idea">Idea</SelectItem>
                          <SelectItem value="Pre-revenue">Pre-revenue</SelectItem>
                          <SelectItem value="Early-stage">Early-stage</SelectItem>
                          <SelectItem value="Growth">Growth</SelectItem>
                          <SelectItem value="Scale">Scale</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="teamSize"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Team Size</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="Select size" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Solo">Solo Founder</SelectItem>
                          <SelectItem value="2-5">2-5 Employees</SelectItem>
                          <SelectItem value="6-20">6-20 Employees</SelectItem>
                          <SelectItem value="20+">20+ Employees</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="revenueRange"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Revenue Range</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-background/50">
                            <SelectValue placeholder="Select range" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="$0">$0 (Pre-revenue)</SelectItem>
                          <SelectItem value="<$10k">&lt; $10k ARR</SelectItem>
                          <SelectItem value="$10k-$100k">$10k - $100k ARR</SelectItem>
                          <SelectItem value="$100k+">$100k+ ARR</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-6 pt-4 border-t border-border/50">
                <h3 className="text-lg font-medium">Context & Positioning</h3>
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Elevator Pitch / Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="What does your business do? What problem do you solve?" 
                          className="resize-none h-24 bg-background/50" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="targetMarket"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Target Market</FormLabel>
                      <FormControl>
                        <Input placeholder="Who is your ideal customer?" {...field} className="bg-background/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="mainGoal"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Primary Goal (Next 6-12 Months)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Hit $1M ARR, Launch V2, Expand to Europe" {...field} className="bg-background/50" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="pt-4 flex flex-col gap-3">
                <Button type="submit" disabled={createBusiness.isPending} className="w-full px-8 bg-primary text-primary-foreground shadow-[0_0_15px_rgba(93,46,232,0.4)] hover:bg-primary/90">
                  {createBusiness.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing Business &amp; Generating SWOT...
                    </>
                  ) : (
                    <>
                      <BrainCircuit className="mr-2 h-4 w-4" />
                      Create Profile &amp; Run SWOT Analysis
                    </>
                  )}
                </Button>
                <p className="text-xs text-center text-muted-foreground">
                  Your SWOT analysis will be generated automatically — you'll be taken straight to your results.
                </p>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
