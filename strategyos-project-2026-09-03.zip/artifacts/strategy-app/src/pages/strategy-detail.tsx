import { useParams, Link } from "wouter";
import { useState } from "react";
import {
  useGetStrategy, getGetStrategyQueryKey,
  useGetStrategyProgress, getGetStrategyProgressQueryKey,
  useUpdateMilestone,
  useGetBusiness, getGetBusinessQueryKey,
  useLogKpiProgress,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { ArrowLeft, CheckCircle2, Circle, Clock, Route, Target, BarChart3, Crosshair, Calendar, TrendingUp, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";

const STATUS_CONFIG = {
  not_started: {
    icon: Circle,
    label: "Not Started",
    className: "text-muted-foreground hover:text-primary",
    rowClass: "bg-card/50 border-border/50 hover:border-border",
    badgeClass: "bg-muted/50 text-muted-foreground border-border/50",
  },
  in_progress: {
    icon: Clock,
    label: "In Progress",
    className: "text-amber-500",
    rowClass: "bg-amber-500/5 border-amber-500/20",
    badgeClass: "bg-amber-500/10 text-amber-500 border-amber-500/20",
  },
  completed: {
    icon: CheckCircle2,
    label: "Completed",
    className: "text-emerald-500",
    rowClass: "bg-card/30 border-border/30 opacity-60",
    badgeClass: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
  },
};

type KpiDialogState = {
  milestoneId: number;
  milestoneTitle: string;
  kpi: string;
  target: string | null;
} | null;

export default function StrategyDetail() {
  const params = useParams();
  const id = Number(params.id);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [kpiDialog, setKpiDialog] = useState<KpiDialogState>(null);
  const [kpiValue, setKpiValue] = useState("");
  const [kpiNote, setKpiNote] = useState("");

  const { data: strategy, isLoading: isStrategyLoading } = useGetStrategy(id, {
    query: { enabled: !!id, queryKey: getGetStrategyQueryKey(id) }
  });

  const { data: progress, isLoading: isProgressLoading } = useGetStrategyProgress(id, {
    query: { enabled: !!id, queryKey: getGetStrategyProgressQueryKey(id) }
  });

  const businessId = strategy?.businessId;
  const { data: business } = useGetBusiness(businessId as number, {
    query: { enabled: !!businessId, queryKey: getGetBusinessQueryKey(businessId as number) }
  });

  const updateMilestone = useUpdateMilestone();
  const logKpi = useLogKpiProgress();

  const openKpiDialog = (milestone: { id: number; title: string; kpi?: string | null; target?: string | null }) => {
    setKpiValue("");
    setKpiNote("");
    setKpiDialog({
      milestoneId: milestone.id,
      milestoneTitle: milestone.title,
      kpi: milestone.kpi ?? "KPI",
      target: milestone.target ?? null,
    });
  };

  const handleLogKpi = () => {
    if (!kpiDialog || !kpiValue.trim()) return;
    logKpi.mutate(
      { id: kpiDialog.milestoneId, data: { actualValue: kpiValue.trim(), note: kpiNote.trim() || undefined } },
      {
        onSuccess: () => {
          toast({
            title: "Progress logged",
            description: `Recorded "${kpiValue}" for ${kpiDialog.kpi}`,
          });
          setKpiDialog(null);
          setKpiValue("");
          setKpiNote("");
        },
        onError: () => {
          toast({ title: "Failed to log progress", variant: "destructive" });
        },
      }
    );
  };

  const handleCycleMilestoneStatus = (milestoneId: number, currentStatus: string) => {
    let nextStatus = "not_started";
    if (currentStatus === "not_started") nextStatus = "in_progress";
    else if (currentStatus === "in_progress") nextStatus = "completed";
    else if (currentStatus === "completed") nextStatus = "not_started";

    queryClient.setQueryData(getGetStrategyQueryKey(id), (oldData: any) => {
      if (!oldData?.pillars) return oldData;
      return {
        ...oldData,
        pillars: oldData.pillars.map((pillar: any) => ({
          ...pillar,
          milestones: pillar.milestones?.map((m: any) =>
            m.id === milestoneId ? { ...m, status: nextStatus } : m
          ),
        })),
      };
    });

    queryClient.setQueryData(getGetStrategyProgressQueryKey(id), (oldProgress: any) => {
      if (!oldProgress) return oldProgress;
      let dc = 0, di = 0, dn = 0;
      if (currentStatus === "not_started" && nextStatus === "in_progress") { dn = -1; di = 1; }
      else if (currentStatus === "in_progress" && nextStatus === "completed") { di = -1; dc = 1; }
      else if (currentStatus === "completed" && nextStatus === "not_started") { dc = -1; dn = 1; }
      const completed = oldProgress.completed + dc;
      return {
        ...oldProgress,
        completed,
        inProgress: oldProgress.inProgress + di,
        notStarted: oldProgress.notStarted + dn,
        completionPercent: oldProgress.total > 0 ? (completed / oldProgress.total) * 100 : 0,
      };
    });

    updateMilestone.mutate(
      { id: milestoneId, data: { status: nextStatus } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetStrategyQueryKey(id) });
          queryClient.invalidateQueries({ queryKey: getGetStrategyProgressQueryKey(id) });
        },
      }
    );
  };

  if (isStrategyLoading || isProgressLoading) {
    return (
      <div className="p-8 max-w-6xl mx-auto space-y-8">
        <div className="h-8 w-64 bg-muted animate-pulse rounded" />
        <div className="h-32 bg-card animate-pulse rounded-xl" />
        <div className="space-y-6">
          {[1, 2, 3].map(i => <div key={i} className="h-48 bg-card animate-pulse rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!strategy) return <div className="p-8 text-center text-muted-foreground">Strategy not found.</div>;

  const completionPct = Math.round(progress?.completionPercent || 0);

  return (
    <div className="p-8 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
        <div>
          {business && (
            <Link href={`/businesses/${business.id}`} className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4 transition-colors">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to {business.name}
            </Link>
          )}
          <div className="flex items-center gap-3">
            <Route className="w-8 h-8 text-primary" />
            <h1 className="text-3xl font-bold tracking-tight">{strategy.title}</h1>
            {strategy.status === "active" && (
              <Badge className="bg-primary/20 text-primary hover:bg-primary/30 border-none">Active</Badge>
            )}
          </div>
          <p className="text-muted-foreground mt-2">
            Generated on{" "}
            <span className="font-mono uppercase text-xs">
              {format(new Date(strategy.createdAt), "MMM d, yyyy")}
            </span>
          </p>
        </div>
      </div>

      {/* Overview + Progress */}
      <Card className="bg-card/50 backdrop-blur border-border/50">
        <CardContent className="p-8 space-y-8">
          <div>
            <h2 className="text-xl font-semibold mb-2">Strategic Overview</h2>
            <p className="text-muted-foreground leading-relaxed">{strategy.overview || "No overview available."}</p>
          </div>

          <div className="space-y-4 pt-6 border-t border-border/50">
            <div className="flex justify-between items-end">
              <div>
                <p className="font-medium text-lg">Overall Execution Progress</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {progress?.completed || 0} of {progress?.total || 0} strategic actions completed
                </p>
              </div>
              <span className="text-3xl font-bold font-mono text-primary">{completionPct}%</span>
            </div>
            <div className="h-3 bg-background rounded-full overflow-hidden border border-border/50">
              <div
                className="h-full bg-primary transition-all duration-500 ease-out"
                style={{ width: `${completionPct}%` }}
              />
            </div>
            <div className="grid grid-cols-3 gap-4 pt-2">
              <div className="text-center p-3 rounded-lg bg-background/50 border border-border/30">
                <p className="text-2xl font-bold font-mono text-muted-foreground">{progress?.notStarted || 0}</p>
                <p className="text-xs text-muted-foreground mt-1">Not Started</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-amber-500/5 border border-amber-500/20">
                <p className="text-2xl font-bold font-mono text-amber-500">{progress?.inProgress || 0}</p>
                <p className="text-xs text-muted-foreground mt-1">In Progress</p>
              </div>
              <div className="text-center p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
                <p className="text-2xl font-bold font-mono text-emerald-500">{progress?.completed || 0}</p>
                <p className="text-xs text-muted-foreground mt-1">Completed</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Strategy Pillars — Formula Grid */}
      <div className="space-y-8">
        <div className="flex items-center gap-3">
          <Target className="w-6 h-6 text-primary" />
          <h2 className="text-2xl font-bold tracking-tight">Strategy Execution Plan</h2>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-6 text-xs text-muted-foreground bg-card/30 border border-border/30 rounded-lg px-4 py-3">
          <span className="font-semibold text-foreground uppercase tracking-wider text-xs">Formula:</span>
          <span className="flex items-center gap-1.5">
            <div className="w-3 h-3 rounded-sm bg-primary/30" />
            Strategy Area
          </span>
          <span className="text-muted-foreground/40">→</span>
          <span className="flex items-center gap-1.5">
            <Target className="w-3 h-3 text-primary" />
            Strategic Objective
          </span>
          <span className="text-muted-foreground/40">→</span>
          <span className="flex items-center gap-1.5">
            <BarChart3 className="w-3 h-3 text-blue-400" />
            KPI
          </span>
          <span className="text-muted-foreground/40">→</span>
          <span className="flex items-center gap-1.5">
            <Crosshair className="w-3 h-3 text-emerald-400" />
            Target
          </span>
          <span className="text-muted-foreground/40">→</span>
          <span className="flex items-center gap-1.5">
            <Calendar className="w-3 h-3 text-amber-400" />
            Timeframe
          </span>
        </div>

        {strategy.pillars?.sort((a, b) => a.priority - b.priority).map((pillar, idx) => {
          const pillarProgress = progress?.pillarBreakdown?.find(p => p.pillarId === pillar.id);
          const pillarPct = pillarProgress?.total
            ? Math.round((pillarProgress.completed / pillarProgress.total) * 100)
            : 0;
          const isComplete = pillarProgress && pillarProgress.total > 0 && pillarProgress.completed === pillarProgress.total;

          return (
            <div key={pillar.id} className="space-y-3">
              {/* Pillar header — Strategy Area */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center font-mono text-sm shrink-0 border border-primary/20">
                    {String(idx + 1).padStart(2, "0")}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-bold text-primary">{pillar.title}</h3>
                      <Badge variant="outline" className="text-xs font-mono uppercase tracking-wider bg-primary/5 border-primary/20 text-primary">
                        Strategy Area
                      </Badge>
                      {isComplete && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                      )}
                    </div>
                    {pillar.description && (
                      <p className="text-sm text-muted-foreground mt-0.5">{pillar.description}</p>
                    )}
                  </div>
                </div>
                <div className="hidden md:flex items-center gap-3 shrink-0">
                  <span className="text-sm text-muted-foreground font-mono">
                    {pillarProgress?.completed || 0}/{pillarProgress?.total || 0}
                  </span>
                  <div className="w-20 h-1.5 bg-background rounded-full overflow-hidden border border-border/50">
                    <div
                      className={`h-full transition-all ${isComplete ? "bg-emerald-500" : "bg-primary"}`}
                      style={{ width: `${pillarPct}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Column headers */}
              <div className="hidden md:grid grid-cols-[auto_1fr_1fr_1fr_auto_auto] gap-0 text-xs font-semibold uppercase tracking-wider text-muted-foreground/60 px-4 py-2 bg-card/20 rounded-lg border border-border/20">
                <div className="w-10" />
                <div className="flex items-center gap-1.5 px-3">
                  <Target className="w-3 h-3 text-primary/60" />
                  Strategic Objective
                </div>
                <div className="flex items-center gap-1.5 px-3">
                  <BarChart3 className="w-3 h-3 text-blue-400/60" />
                  KPI
                </div>
                <div className="flex items-center gap-1.5 px-3">
                  <Crosshair className="w-3 h-3 text-emerald-400/60" />
                  Target
                </div>
                <div className="flex items-center gap-1.5 px-3 w-28">
                  <Calendar className="w-3 h-3 text-amber-400/60" />
                  Timeframe
                </div>
                <div className="px-3 w-28">Status</div>
              </div>

              {/* Milestone rows */}
              <div className="space-y-2">
                {pillar.milestones?.sort((a, b) => a.order - b.order).map((milestone) => {
                  const cfg = STATUS_CONFIG[milestone.status as keyof typeof STATUS_CONFIG] || STATUS_CONFIG.not_started;
                  const Icon = cfg.icon;

                  return (
                    <div
                      key={milestone.id}
                      className={`group rounded-xl border transition-all ${cfg.rowClass}`}
                    >
                      {/* Desktop: formula row */}
                      <div className="hidden md:grid grid-cols-[auto_1fr_1fr_1fr_auto_auto] gap-0 items-start p-3">
                        {/* Status toggle */}
                        <button
                          onClick={() => handleCycleMilestoneStatus(milestone.id, milestone.status)}
                          className="w-10 flex items-center justify-center pt-1 focus:outline-none"
                          title="Click to cycle status"
                        >
                          <Icon className={`w-5 h-5 transition-colors ${cfg.className}`} />
                        </button>

                        {/* Strategic Objective */}
                        <div className="px-3 py-1 min-w-0">
                          <p className={`text-sm font-medium leading-snug ${milestone.status === "completed" ? "line-through text-muted-foreground" : "text-foreground"}`}>
                            {milestone.title}
                          </p>
                          {milestone.description && (
                            <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                              {milestone.description}
                            </p>
                          )}
                        </div>

                        {/* KPI */}
                        <div className="px-3 py-1 min-w-0">
                          {milestone.kpi ? (
                            <div className="flex items-start gap-1.5">
                              <BarChart3 className="w-3.5 h-3.5 text-blue-400 mt-0.5 shrink-0" />
                              <span className="text-xs text-blue-300/90 leading-snug">{milestone.kpi}</span>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground/40">—</span>
                          )}
                        </div>

                        {/* Target */}
                        <div className="px-3 py-1 min-w-0">
                          {milestone.target ? (
                            <div className="flex items-start gap-1.5">
                              <Crosshair className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                              <span className="text-xs text-emerald-300/90 font-medium leading-snug">{milestone.target}</span>
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground/40">—</span>
                          )}
                        </div>

                        {/* Timeframe */}
                        <div className="px-3 py-1 w-28">
                          {milestone.timeframe ? (
                            <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/20 font-mono text-xs whitespace-nowrap">
                              {milestone.timeframe}
                            </Badge>
                          ) : (
                            <span className="text-xs text-muted-foreground/40">—</span>
                          )}
                        </div>

                        {/* Status badge */}
                        <div className="px-3 py-1 w-28">
                          <Badge variant="outline" className={`text-xs ${cfg.badgeClass}`}>
                            {cfg.label}
                          </Badge>
                        </div>
                      </div>

                      {/* Mobile: stacked layout */}
                      <div className="md:hidden p-4 space-y-3">
                        <div className="flex items-start gap-3">
                          <button
                            onClick={() => handleCycleMilestoneStatus(milestone.id, milestone.status)}
                            className="mt-0.5 focus:outline-none shrink-0"
                          >
                            <Icon className={`w-5 h-5 transition-colors ${cfg.className}`} />
                          </button>
                          <div className="flex-1 min-w-0">
                            <p className={`text-sm font-medium leading-snug ${milestone.status === "completed" ? "line-through text-muted-foreground" : ""}`}>
                              {milestone.title}
                            </p>
                            {milestone.description && (
                              <p className="text-xs text-muted-foreground mt-1">{milestone.description}</p>
                            )}
                          </div>
                          <Badge variant="outline" className={`shrink-0 text-xs ${cfg.badgeClass}`}>
                            {cfg.label}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 gap-2 pl-8">
                          {milestone.kpi && (
                            <div className="flex items-start gap-2 p-2 rounded-lg bg-blue-500/5 border border-blue-500/10">
                              <BarChart3 className="w-3.5 h-3.5 text-blue-400 mt-0.5 shrink-0" />
                              <div>
                                <p className="text-xs font-medium text-blue-400/80 uppercase tracking-wider mb-0.5">KPI</p>
                                <p className="text-xs text-blue-300/90">{milestone.kpi}</p>
                              </div>
                            </div>
                          )}
                          {milestone.target && (
                            <div className="flex items-start gap-2 p-2 rounded-lg bg-emerald-500/5 border border-emerald-500/10">
                              <Crosshair className="w-3.5 h-3.5 text-emerald-400 mt-0.5 shrink-0" />
                              <div>
                                <p className="text-xs font-medium text-emerald-400/80 uppercase tracking-wider mb-0.5">Target</p>
                                <p className="text-xs text-emerald-300/90 font-medium">{milestone.target}</p>
                              </div>
                            </div>
                          )}
                          {milestone.timeframe && (
                            <div className="flex items-center gap-2">
                              <Calendar className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                              <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/20 font-mono text-xs">
                                {milestone.timeframe}
                              </Badge>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

                {(!pillar.milestones || pillar.milestones.length === 0) && (
                  <p className="text-sm text-muted-foreground italic py-4 pl-4">No actions defined for this area.</p>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* CTA — add another strategy */}
      <div className="border border-dashed border-border/40 rounded-xl p-6 text-center bg-card/10">
        <p className="text-muted-foreground text-sm mb-3">
          Want a strategy focused on a different area?
        </p>
        {business && (
          <Button asChild variant="outline" className="bg-card/50 border-border/50 hover:bg-card">
            <Link href={`/businesses/${business.id}/strategies/new`}>
              <Route className="w-4 h-4 mr-2" />
              Generate Another Strategy
            </Link>
          </Button>
        )}
      </div>

      {/* KPI Log Dialog */}
      <Dialog open={!!kpiDialog} onOpenChange={(open) => { if (!open) setKpiDialog(null); }}>
        <DialogContent className="sm:max-w-md bg-card border-border/50">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-primary" />
              Log KPI Progress
            </DialogTitle>
            <DialogDescription>
              Record an actual measurement for <span className="text-blue-400 font-medium">{kpiDialog?.kpi}</span>
              {kpiDialog?.target && (
                <> — target is <span className="text-emerald-400 font-medium">{kpiDialog.target}</span></>
              )}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-1.5">
              <Label htmlFor="kpi-value" className="text-sm font-medium">
                Actual Value <span className="text-red-400">*</span>
              </Label>
              <Input
                id="kpi-value"
                placeholder={kpiDialog?.target ? `e.g. halfway to "${kpiDialog.target}"` : "e.g. $12,400 MRR, 3 deals, 42%"}
                value={kpiValue}
                onChange={(e) => setKpiValue(e.target.value)}
                className="bg-background border-border/50"
                onKeyDown={(e) => { if (e.key === "Enter" && kpiValue.trim()) handleLogKpi(); }}
                autoFocus
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="kpi-note" className="text-sm font-medium text-muted-foreground">
                Note <span className="text-muted-foreground/50 font-normal">(optional)</span>
              </Label>
              <Textarea
                id="kpi-note"
                placeholder="Context, blockers, or observations..."
                value={kpiNote}
                onChange={(e) => setKpiNote(e.target.value)}
                className="bg-background border-border/50 resize-none"
                rows={2}
              />
            </div>
            <div className="flex gap-3 pt-1">
              <Button
                onClick={handleLogKpi}
                disabled={!kpiValue.trim() || logKpi.isPending}
                className="flex-1 bg-primary text-primary-foreground"
              >
                {logKpi.isPending ? "Saving..." : "Log Progress"}
              </Button>
              <Button variant="outline" onClick={() => setKpiDialog(null)} className="border-border/50">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
