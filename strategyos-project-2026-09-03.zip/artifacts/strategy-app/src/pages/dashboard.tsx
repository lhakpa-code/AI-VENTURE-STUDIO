import { useListBusinesses } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Briefcase, Activity, Target, ArrowRight } from "lucide-react";

export default function Dashboard() {
  const { data: businesses, isLoading } = useListBusinesses();

  if (isLoading) {
    return (
      <div className="p-8 space-y-6">
        <div className="h-8 w-48 bg-muted rounded animate-pulse" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-48 bg-card rounded-xl border border-border animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  if (!businesses || businesses.length === 0) {
    return (
      <div className="h-full flex flex-col items-center justify-center p-8 text-center max-w-2xl mx-auto">
        <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
          <Briefcase className="w-10 h-10 text-primary" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight mb-4">Your AI Strategy Partner</h1>
        <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
          Stop guessing. Start executing. StrategyOS analyzes your business identity, uncovers hidden opportunities, and generates actionable roadmaps for growth.
        </p>
        <Link href="/businesses/new" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-12 px-8 py-2">
          <Plus className="mr-2 h-5 w-5" />
          Create Your First Business Profile
        </Link>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Portfolios</h1>
          <p className="text-muted-foreground mt-1">Manage your active business strategies</p>
        </div>
        <Link href="/businesses/new" className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground shadow hover:bg-primary/90 h-10 px-4 py-2">
          <Plus className="mr-2 h-4 w-4" />
          New Business
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {businesses.map((business, i) => (
          <Link key={business.id} href={`/businesses/${business.id}`}>
            <Card className="group hover:border-primary/50 transition-colors cursor-pointer bg-card/50 backdrop-blur border-border/50 hover:bg-card">
              <CardHeader>
                <CardTitle className="flex justify-between items-start">
                  <span className="truncate pr-4">{business.name}</span>
                  <div className="bg-primary/10 text-primary text-xs px-2 py-1 rounded font-mono uppercase tracking-wider">
                    {business.stage}
                  </div>
                </CardTitle>
                <CardDescription className="line-clamp-2 mt-2 text-muted-foreground">
                  {business.description || `${business.industry} business targeting ${business.targetMarket}`}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border/50 text-sm">
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Activity className="w-4 h-4" />
                      {business.industry}
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors transform group-hover:translate-x-1" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
