import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useGetBusiness, getGetBusinessQueryKey, useCreateStrategy, getListStrategiesQueryKey, getGetBusinessDashboardQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Target, Loader2, ArrowLeft, Route } from "lucide-react";
import { Link } from "wouter";

const FOCUS_AREAS = [
  { id: "marketing", label: "Marketing & Acquisition" },
  { id: "sales", label: "Sales & Conversion" },
  { id: "product", label: "Product & Engineering" },
  { id: "operations", label: "Operations & Processes" },
  { id: "finance", label: "Finance & Fundraising" },
  { id: "team", label: "Team & Culture" }
];

const LOADING_STEPS = [
  "Mapping strategic objectives...",
  "Structuring tactical pillars...",
  "Sequencing milestones...",
  "Estimating timeframes...",
  "Assembling action plan..."
];

export default function StrategyNew() {
  const params = useParams();
  const id = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  
  const [title, setTitle] = useState("");
  const [selectedAreas, setSelectedAreas] = useState<string[]>([]);
  const [loadingStepIndex, setLoadingStepIndex] = useState(0);

  // We check for an assessmentId in query params if they came from an assessment
  const searchParams = new URLSearchParams(window.location.search);
  const assessmentId = searchParams.get("assessmentId") ? Number(searchParams.get("assessmentId")) : undefined;

  const { data: business, isLoading: isLoadingBusiness } = useGetBusiness(id, {
    query: { enabled: !!id, queryKey: getGetBusinessQueryKey(id) }
  });

  const createStrategy = useCreateStrategy();

  useEffect(() => {
    if (!createStrategy.isPending) return;
    const interval = setInterval(() => {
      setLoadingStepIndex((prev) => (prev < LOADING_STEPS.length - 1 ? prev + 1 : prev));
    }, 1500);
    return () => clearInterval(interval);
  }, [createStrategy.isPending]);

  const handleGenerate = () => {
    if (!id || !title.trim()) return;
    setLoadingStepIndex(0);
    
    createStrategy.mutate(
      { 
        id, 
        data: { 
          title, 
          focusAreas: selectedAreas.length > 0 ? selectedAreas : undefined,
          assessmentId
        } 
      },
      {
        onSuccess: (strategy) => {
          queryClient.invalidateQueries({ queryKey: getListStrategiesQueryKey(id) });
          queryClient.invalidateQueries({ queryKey: getGetBusinessDashboardQueryKey(id) });
          setLocation(`/strategies/${strategy.id}`);
        }
      }
    );
  };

  const toggleArea = (areaId: string) => {
    setSelectedAreas(prev => 
      prev.includes(areaId) ? prev.filter(a => a !== areaId) : [...prev, areaId]
    );
  };

  if (isLoadingBusiness) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-100px)]">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!business) return <div className="p-8">Business not found.</div>;

  if (createStrategy.isPending) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[80vh] max-w-lg mx-auto text-center space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="relative">
          <div className="absolute inset-0 bg-primary/20 blur-[50px] rounded-full w-32 h-32" />
          <div className="relative w-32 h-32 bg-card border border-primary/20 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(93,46,232,0.3)]">
            <Route className="w-12 h-12 text-primary animate-pulse" />
          </div>
        </div>
        
        <div className="space-y-2">
          <h2 className="text-2xl font-bold font-mono tracking-tight text-white">
            Constructing Growth Roadmap
          </h2>
          <p className="text-primary h-6 transition-all duration-300">
            {LOADING_STEPS[loadingStepIndex]}
          </p>
        </div>
        
        <div className="w-full bg-card rounded-full h-1.5 overflow-hidden">
          <div 
            className="bg-primary h-full transition-all duration-500 ease-out"
            style={{ width: `${Math.max(10, (loadingStepIndex / (LOADING_STEPS.length - 1)) * 100)}%` }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="mb-8">
        <Link href={`/businesses/${id}`} className="inline-flex items-center text-sm text-muted-foreground hover:text-primary mb-4 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Hub
        </Link>
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-3">
          <Target className="text-primary w-8 h-8" />
          Generate Strategy
        </h1>
        <p className="text-muted-foreground mt-2">
          Create a step-by-step tactical roadmap tailored to {business.name}.
        </p>
      </div>

      <Card className="bg-card/50 backdrop-blur border-border/50">
        <CardHeader>
          <CardTitle>Strategy Parameters</CardTitle>
          <CardDescription>Give this strategy a focus to yield the most actionable results.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="space-y-3">
            <Label htmlFor="title" className="text-base">Roadmap Title</Label>
            <Input 
              id="title"
              placeholder="e.g. Q3 Growth Push, Pre-Seed Prep, Launch V2"
              className="bg-background/50 h-12 text-lg"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </div>

          <div className="space-y-4 pt-4 border-t border-border/50">
            <Label className="text-base block">Focus Areas (Optional)</Label>
            <p className="text-sm text-muted-foreground mb-4">
              Select specific areas to weight the strategy towards, or leave blank for a holistic business strategy.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {FOCUS_AREAS.map((area) => (
                <div 
                  key={area.id}
                  className={`flex items-center space-x-3 space-y-0 rounded-md border p-4 cursor-pointer transition-colors ${
                    selectedAreas.includes(area.id) ? 'border-primary bg-primary/5' : 'border-border/50 hover:bg-card'
                  }`}
                  onClick={() => toggleArea(area.id)}
                >
                  <Checkbox 
                    id={`area-${area.id}`} 
                    checked={selectedAreas.includes(area.id)}
                    onCheckedChange={() => toggleArea(area.id)}
                  />
                  <div className="space-y-1 leading-none flex-1">
                    <Label 
                      htmlFor={`area-${area.id}`}
                      className="cursor-pointer font-medium"
                    >
                      {area.label}
                    </Label>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="pt-6">
            <Button 
              size="lg" 
              onClick={handleGenerate}
              disabled={!title.trim()}
              className="w-full text-lg h-14 bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(93,46,232,0.4)]"
            >
              <Route className="w-5 h-5 mr-2" />
              Generate Growth Strategy
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
