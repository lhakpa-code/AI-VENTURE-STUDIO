import { useState } from "react";
import {
  BrainCircuit, Compass, Sparkles, Loader2,
  DollarSign, Map, CheckCircle2, RefreshCw, Target, TrendingUp,
  Copy, Download, Check, Megaphone, Calculator,
} from "lucide-react";
import VersionNav from "../components/VersionNav";

// ── Types ─────────────────────────────────────────────────────────────────────

interface Answers {
  idea: string;
  target_customer: string;
  problem: string;
  solution: string;
  monetization: string;
  competitors: string;
  market: string;
  stage: string;
  budget: string;
  goals: string;
}

const EMPTY_ANSWERS: Answers = {
  idea: "", target_customer: "", problem: "", solution: "", monetization: "",
  competitors: "", market: "", stage: "", budget: "", goals: "",
};

interface Question {
  key: keyof Answers;
  title: string;
  hint: string;
  placeholder: string;
  multiline?: boolean;
  options?: string[];
  aiHelper?: boolean;
}

const QUESTIONS: Question[] = [
  { key: "idea", title: "What is your startup idea or name?", hint: "A short description or working name is fine.", placeholder: "e.g. FitFlow — AI-powered home workout planner", multiline: true },
  { key: "target_customer", title: "Who is your target customer?", hint: "Be as specific as you can — demographics, role, behaviour.", placeholder: "e.g. Busy professionals aged 25-40 who can't commit to gym hours", multiline: true },
  { key: "problem", title: "What specific problem are you solving?", hint: "The pain point your customer feels today.", placeholder: "e.g. Generic workout apps don't adapt to schedule changes and people quit within 3 weeks", multiline: true },
  { key: "solution", title: "What is your proposed solution?", hint: "How your product removes that pain.", placeholder: "e.g. An AI coach that re-plans workouts around your calendar automatically", multiline: true },
  { key: "monetization", title: "How will you make money?", hint: "Your monetization strategy — even a rough idea helps.", placeholder: "e.g. Freemium with a $12/mo premium tier, plus corporate wellness plans", multiline: true },
  { key: "competitors", title: "Who are your top competitors?", hint: "Direct or indirect. Not sure? Let AI suggest them.", placeholder: "e.g. Freeletics, Fitbod, Nike Training Club", multiline: true, aiHelper: true },
  { key: "market", title: "What country/market are you targeting?", hint: "Your first launch market.", placeholder: "e.g. United Kingdom, then EU" },
  { key: "stage", title: "What stage are you at?", hint: "Pick the closest match.", placeholder: "", options: ["Idea", "MVP", "Launched", "Generating Revenue"] },
  { key: "budget", title: "What is your current budget?", hint: "The total amount you can invest in the next 90 days.", placeholder: "e.g. $5,000" },
  { key: "goals", title: "What are your main goals for the next 90 days?", hint: "What does success look like by day 90?", placeholder: "e.g. Launch MVP, get 500 signups, land 3 paying customers", multiline: true },
];

interface RevenueStream { name: string; description: string }
interface PricingTier { name: string; price: string; target: string; includes: string }
interface AcquisitionChannel { name: string; description: string }
interface UnitEconomics {
  summary: string;
  estimated_cac?: string;
  target_ltv?: string;
  gross_margin?: string;
  payback_period?: string;
}
interface RoadmapStep { week?: string; title: string; description: string; outcome: string }
interface RoadmapMonth { theme: string; steps: RoadmapStep[] }
interface ArchitectResult {
  business_model: {
    recommended_model: string;
    rationale: string;
    revenue_streams: RevenueStream[];
    pricing_strategy: { summary: string; tiers: PricingTier[] };
    acquisition_channels?: AcquisitionChannel[];
    unit_economics?: UnitEconomics;
    key_metrics: string[];
  };
  roadmap: { month_1: RoadmapMonth; month_2: RoadmapMonth; month_3: RoadmapMonth };
}

// ── Plan → markdown (for Copy / Export) ───────────────────────────────────────

function planToMarkdown(answers: Answers, result: ArchitectResult): string {
  const bm = result.business_model;
  const lines: string[] = [
    `# Startup Strategy: ${answers.idea}`,
    "",
    "## Business & Monetization Model",
    `**Recommended model:** ${bm.recommended_model}`,
    "",
    bm.rationale,
    "",
    "### Revenue streams",
    ...(bm.revenue_streams ?? []).map((s) => `- **${s.name}** — ${s.description}`),
    "",
    "### Pricing strategy",
    bm.pricing_strategy?.summary ?? "",
    ...(bm.pricing_strategy?.tiers ?? []).map(
      (t) => `- **${t.name}** (${t.price}) — ${t.target}. ${t.includes}`,
    ),
  ];
  if (bm.acquisition_channels?.length) {
    lines.push("", "### Customer acquisition channels",
      ...bm.acquisition_channels.map((c) => `- **${c.name}** — ${c.description}`));
  }
  if (bm.unit_economics) {
    const u = bm.unit_economics;
    lines.push("", "### Unit economics", u.summary ?? "");
    if (u.estimated_cac) lines.push(`- Estimated CAC: ${u.estimated_cac}`);
    if (u.target_ltv) lines.push(`- Target LTV: ${u.target_ltv}`);
    if (u.gross_margin) lines.push(`- Gross margin: ${u.gross_margin}`);
    if (u.payback_period) lines.push(`- Payback period: ${u.payback_period}`);
  }
  if (bm.key_metrics?.length) {
    lines.push("", "### Metrics to track", ...bm.key_metrics.map((m) => `- ${m}`));
  }
  lines.push("", "## 90-Day Execution Roadmap");
  const months: [string, RoadmapMonth][] = [
    ["Month 1", result.roadmap.month_1],
    ["Month 2", result.roadmap.month_2],
    ["Month 3", result.roadmap.month_3],
  ];
  for (const [label, month] of months) {
    lines.push("", `### ${label} — ${month?.theme ?? ""}`);
    for (const s of month?.steps ?? []) {
      lines.push(`- ${s.week ? `**${s.week}:** ` : ""}**${s.title}** — ${s.description}${s.outcome ? ` _(Outcome: ${s.outcome})_` : ""}`);
    }
  }
  return lines.join("\n");
}

// ── Shared styles ─────────────────────────────────────────────────────────────

const GLOW_BG =
  "min-h-screen bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.2),rgba(255,255,255,0))] text-slate-100 flex flex-col";
const CARD =
  "bg-slate-900/80 border border-slate-800 rounded-2xl backdrop-blur-md shadow-xl";

// ── Page ──────────────────────────────────────────────────────────────────────

export default function ArchitectPage() {
  const [answers, setAnswers] = useState<Answers>(EMPTY_ANSWERS);
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<ArchitectResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [suggesting, setSuggesting] = useState(false);

  const allFilled = QUESTIONS.every((q) => answers[q.key].trim().length > 0);

  const setAnswer = (key: keyof Answers, v: string) =>
    setAnswers((prev) => ({ ...prev, [key]: v }));

  const suggestCompetitors = async () => {
    setSuggesting(true);
    try {
      const res = await fetch("/api/architect/suggest-competitors", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          idea: answers.idea,
          problem: answers.problem,
          target_customer: answers.target_customer,
          market: answers.market,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Suggestion failed");
      const list = (data.competitors ?? [])
        .map((c: { name: string; description: string }) => `${c.name} — ${c.description}`)
        .join("\n");
      if (list) setAnswer("competitors", list);
    } catch (err: any) {
      setError(err?.message ?? "Could not suggest competitors");
      setTimeout(() => setError(null), 4000);
    } finally {
      setSuggesting(false);
    }
  };

  const generate = async () => {
    setGenerating(true);
    setError(null);
    try {
      const res = await fetch("/api/architect/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(answers),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Generation failed");
      setResult(data);
    } catch (err: any) {
      setError(err?.message ?? "Something went wrong. Please try again.");
    } finally {
      setGenerating(false);
    }
  };

  const reset = () => {
    setResult(null);
    setAnswers(EMPTY_ANSWERS);
    setError(null);
  };

  return (
    <div className={GLOW_BG}>
      {/* Header */}
      <header className="flex items-center gap-3 px-4 sm:px-8 py-5 border-b border-white/[0.06]">
        <div className="w-8 h-8 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center">
          <BrainCircuit className="w-4 h-4 text-violet-400" />
        </div>
        <span className="font-semibold text-white tracking-tight">StrategyOS</span>
        <span className="ml-auto inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
          <Compass className="w-3 h-3" />
          Startup Architect
        </span>
      </header>

      <VersionNav />

      <main className="flex-1 w-full max-w-3xl mx-auto px-4 py-8 sm:py-12">
        {result ? (
          <ResultsView result={result} answers={answers} onRestart={reset} />
        ) : generating ? (
          <GeneratingView idea={answers.idea} />
        ) : (
          <>
            <div className="mb-8">
              <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">Startup Architect</h1>
              <p className="text-slate-400 text-sm leading-relaxed">
                Answer the 10 questions below and we'll design a custom business model and 90-day execution roadmap.
              </p>
            </div>

            {error && (
              <div className="mb-6 rounded-xl border border-red-500/30 bg-red-500/10 text-red-300 text-sm px-4 py-3">
                {error}
              </div>
            )}

            <div className={`${CARD} p-6 sm:p-8 space-y-7`}>
              {QUESTIONS.map((q, i) => {
                const value = answers[q.key];
                return (
                  <div key={q.key}>
                    <label className="block text-sm font-bold text-white mb-1">
                      <span className="text-cyan-400 mr-2">{i + 1}.</span>
                      {q.title}
                    </label>
                    <p className="text-slate-500 text-xs leading-relaxed mb-2.5">{q.hint}</p>

                    {q.options ? (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {q.options.map((opt) => (
                          <button
                            key={opt}
                            type="button"
                            onClick={() => setAnswer(q.key, opt)}
                            className={`rounded-xl border px-3 py-2.5 text-center text-xs font-medium transition-all ${
                              value === opt
                                ? "border-cyan-500/60 bg-cyan-500/10 text-white shadow-lg shadow-cyan-500/10"
                                : "border-slate-800 bg-slate-900/60 text-slate-300 hover:border-slate-700"
                            }`}
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    ) : q.multiline ? (
                      <textarea
                        value={value}
                        onChange={(e) => setAnswer(q.key, e.target.value)}
                        placeholder={q.placeholder}
                        rows={2}
                        className="w-full rounded-xl bg-slate-950/60 border border-slate-800 focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 text-slate-100 placeholder:text-slate-600 text-sm px-4 py-3 resize-none transition-all"
                      />
                    ) : (
                      <input
                        value={value}
                        onChange={(e) => setAnswer(q.key, e.target.value)}
                        placeholder={q.placeholder}
                        className="w-full rounded-xl bg-slate-950/60 border border-slate-800 focus:border-cyan-500/50 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 text-slate-100 placeholder:text-slate-600 text-sm px-4 py-3 transition-all"
                      />
                    )}

                    {q.aiHelper && (
                      <button
                        type="button"
                        onClick={suggestCompetitors}
                        disabled={suggesting || !answers.idea.trim()}
                        className="mt-2.5 inline-flex items-center gap-2 text-xs font-semibold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 disabled:opacity-50 rounded-full px-4 py-2 transition-all"
                      >
                        {suggesting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                        {suggesting ? "Researching competitors…" : "AI, help me list these"}
                      </button>
                    )}
                  </div>
                );
              })}

              <div className="pt-2 border-t border-white/[0.06]">
                <button
                  onClick={generate}
                  disabled={!allFilled}
                  className="w-full inline-flex items-center justify-center gap-2 rounded-full bg-gradient-to-r from-cyan-400 to-indigo-500 text-slate-950 font-bold text-sm px-8 py-3.5 disabled:opacity-40 hover:opacity-90 transition-all shadow-lg shadow-cyan-500/20"
                >
                  <Sparkles className="w-4 h-4" /> Generate Plan
                </button>
                {!allFilled && (
                  <p className="text-center text-xs text-slate-500 mt-2">Fill in all 10 fields to generate your plan.</p>
                )}
              </div>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

// ── Generating ────────────────────────────────────────────────────────────────

function GeneratingView({ idea }: { idea: string }) {
  return (
    <div className={`${CARD} p-10 sm:p-14 text-center`}>
      <div className="w-14 h-14 mx-auto rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-6">
        <Loader2 className="w-7 h-7 text-cyan-400 animate-spin" />
      </div>
      <h2 className="text-xl font-bold text-white mb-2">Architecting your startup…</h2>
      <p className="text-slate-400 text-sm leading-relaxed max-w-md mx-auto">
        Designing a custom business model, pricing strategy, and 90-day execution roadmap for{" "}
        <span className="text-cyan-300">{idea.slice(0, 60)}</span>. This takes ~20 seconds.
      </p>
    </div>
  );
}

// ── Results ───────────────────────────────────────────────────────────────────

function ResultsView({ result, answers, onRestart }: {
  result: ArchitectResult;
  answers: Answers;
  onRestart: () => void;
}) {
  const bm = result.business_model;
  const [copied, setCopied] = useState(false);

  const copyPlan = async () => {
    try {
      await navigator.clipboard.writeText(planToMarkdown(answers, result));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* clipboard unavailable */ }
  };

  const exportPlan = () => {
    const blob = new Blob([planToMarkdown(answers, result)], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "startup-strategy.md";
    a.click();
    URL.revokeObjectURL(url);
  };
  const months: [string, RoadmapMonth][] = [
    ["Month 1", result.roadmap.month_1],
    ["Month 2", result.roadmap.month_2],
    ["Month 3", result.roadmap.month_3],
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 mb-2">
            <CheckCircle2 className="w-3 h-3" /> Strategy ready
          </span>
          <h2 className="text-2xl font-bold text-white">{answers.idea.slice(0, 80)}</h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={copyPlan}
            className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-300 bg-cyan-500/10 border border-cyan-500/20 hover:bg-cyan-500/20 rounded-full px-4 py-2 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? "Copied!" : "Copy Plan"}
          </button>
          <button
            onClick={exportPlan}
            className="inline-flex items-center gap-2 text-xs font-semibold text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 hover:bg-indigo-500/20 rounded-full px-4 py-2 transition-all"
          >
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button
            onClick={onRestart}
            className="inline-flex items-center gap-2 text-xs font-semibold text-slate-300 bg-white/[0.04] border border-white/[0.08] hover:border-slate-600 rounded-full px-4 py-2 transition-all"
          >
            <RefreshCw className="w-3.5 h-3.5" /> Start over
          </button>
        </div>
      </div>

      {/* Business model */}
      <section className={`${CARD} p-6 sm:p-8`}>
        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">Business Model & Pricing Strategy</h3>
            <p className="text-slate-400 text-sm">{bm.recommended_model}</p>
          </div>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed mb-6">{bm.rationale}</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {bm.revenue_streams?.map((s) => (
            <div key={s.name} className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 hover:border-cyan-500/40 transition-all">
              <div className="flex items-center gap-2 mb-1.5">
                <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                <span className="text-sm font-bold text-white">{s.name}</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed">{s.description}</p>
            </div>
          ))}
        </div>

        <p className="text-slate-300 text-sm leading-relaxed mb-4">{bm.pricing_strategy?.summary}</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          {bm.pricing_strategy?.tiers?.map((t) => (
            <div key={t.name} className="rounded-xl border border-slate-800 bg-slate-950/40 p-5 hover:-translate-y-1 hover:border-cyan-500/50 hover:shadow-cyan-500/10 shadow-xl transition-all duration-300">
              <div className="text-sm font-bold text-white mb-1">{t.name}</div>
              <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400 mb-2">{t.price}</div>
              <div className="text-xs text-slate-500 mb-2">{t.target}</div>
              <p className="text-slate-400 text-xs leading-relaxed">{t.includes}</p>
            </div>
          ))}
        </div>

        {(bm.acquisition_channels?.length ?? 0) > 0 && (
          <>
            <div className="flex items-center gap-2 mb-3">
              <Megaphone className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-bold text-white">Customer acquisition channels</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
              {bm.acquisition_channels!.map((c) => (
                <div key={c.name} className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 hover:border-cyan-500/40 transition-all">
                  <div className="text-sm font-bold text-white mb-1">{c.name}</div>
                  <p className="text-slate-400 text-xs leading-relaxed">{c.description}</p>
                </div>
              ))}
            </div>
          </>
        )}

        {bm.unit_economics && (
          <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/[0.05] p-4 mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Calculator className="w-4 h-4 text-cyan-400" />
              <span className="text-sm font-bold text-white">Unit economics</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed mb-3">{bm.unit_economics.summary}</p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                ["Est. CAC", bm.unit_economics.estimated_cac],
                ["Target LTV", bm.unit_economics.target_ltv],
                ["Gross margin", bm.unit_economics.gross_margin],
                ["Payback", bm.unit_economics.payback_period],
              ].filter(([, v]) => v).map(([label, v]) => (
                <div key={label} className="rounded-lg bg-slate-950/50 border border-slate-800 px-3 py-2">
                  <div className="text-[10px] uppercase tracking-wider text-slate-500">{label}</div>
                  <div className="text-sm font-bold text-cyan-300">{v}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {bm.key_metrics?.length > 0 && (
          <div className="rounded-xl border border-indigo-500/20 bg-indigo-500/[0.06] p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="w-4 h-4 text-indigo-400" />
              <span className="text-sm font-bold text-white">Metrics to track</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {bm.key_metrics.map((m) => (
                <span key={m} className="text-xs text-indigo-200 bg-indigo-500/10 border border-indigo-500/20 rounded-full px-3 py-1">{m}</span>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* Roadmap */}
      <section className={`${CARD} p-6 sm:p-8`}>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
            <Map className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">90-Day Execution Roadmap</h3>
            <p className="text-slate-400 text-sm">Step-by-step, calibrated to your budget and goals</p>
          </div>
        </div>

        <div className="space-y-8">
          {months.map(([label, month], mi) => (
            <div key={label}>
              <div className="flex items-center gap-3 mb-4">
                <span className={`text-xs font-bold uppercase tracking-wider rounded-full px-3 py-1 border ${
                  mi === 0 ? "bg-cyan-500/10 text-cyan-300 border-cyan-500/30"
                  : mi === 1 ? "bg-indigo-500/10 text-indigo-300 border-indigo-500/30"
                  : "bg-violet-500/10 text-violet-300 border-violet-500/30"
                }`}>{label}</span>
                <span className="text-sm font-semibold text-white">{month?.theme}</span>
              </div>
              <div className="space-y-3 sm:pl-4 sm:border-l sm:border-slate-800">
                {month?.steps?.map((s, i) => (
                  <div key={i} className="rounded-xl border border-slate-800 bg-slate-950/40 p-4 hover:border-slate-700 transition-all">
                    <div className="flex items-start gap-3">
                      <span className="mt-0.5 w-6 h-6 shrink-0 rounded-lg bg-white/[0.04] border border-white/[0.08] flex items-center justify-center text-[11px] font-bold text-slate-400">
                        {i + 1}
                      </span>
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          {s.week && (
                            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-white/[0.04] border border-white/[0.08] rounded-full px-2 py-0.5">
                              {s.week}
                            </span>
                          )}
                          <span className="text-sm font-bold text-white">{s.title}</span>
                        </div>
                        <p className="text-slate-400 text-xs leading-relaxed mb-1.5">{s.description}</p>
                        {s.outcome && (
                          <div className="inline-flex items-center gap-1.5 text-[11px] text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 rounded-full px-2.5 py-0.5">
                            <CheckCircle2 className="w-3 h-3" /> {s.outcome}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
