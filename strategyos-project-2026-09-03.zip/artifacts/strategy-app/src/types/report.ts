// ─── Core item types with grounding fields ────────────────────────────────────

export type ConfidenceScore = "high" | "medium" | "low";

export interface SwotItem {
  // New structured payload (v2)
  point: string;
  evidence: string;
  strategic_impact: string;
  confidence_score: ConfidenceScore;
  citation: string;
}

export interface StrategicPriority {
  title: string;
  rationale: string;
  keyAction: string;
  citation: string;
}

export interface RiskItem {
  title: string;
  description: string;
  impact: "High" | "Medium" | "Low";
  mitigation: string;
  citation: string;
  confidence_score: ConfidenceScore;
}

export interface OpportunityItem {
  title: string;
  description: string;
  advantage: string;
  timeframe: string;
  citation: string;
  confidence_score: ConfidenceScore;
}

export interface ActionPhase {
  phase: string;
  focus: string;
  actions: string[];
  milestone: string;
}

// ─── Competitive Matrix ───────────────────────────────────────────────────────

export interface CompetitorProfile {
  name: string;
  pricingModel: string;
  marketShareEstimate: string;
  techStackIndicators: string;
  hiringTrends: string;
  keyMoat: string;
  keyVulnerability: string;
  vsTargetCompany: string;
}

export interface CompetitiveMatrix {
  targetMoats: string[];
  targetVulnerabilities: string[];
  benchmarkSummary: string;
  competitors: CompetitorProfile[];
}

// ─── Sources (from Agents 1 + 2) ─────────────────────────────────────────────

export interface MetricItem {
  label: string;
  value: string;
  source: string;
}

export interface ReportSources {
  agent1: {
    secFound: boolean;
    secFiling: string;
    newsItems: Array<{ headline: string; date: string; source: string }>;
    sentimentSummary: string;
    competitors: Array<{ name: string; positioning: string }>;
    dataQuality: string;
  };
  agent2: {
    companyType: string;
    metrics: MetricItem[];
    dataAvailability: string;
    notes: string;
  };
}

// ─── Business Score ───────────────────────────────────────────────────────────

export type ScoreRating = "Excellent" | "Strong" | "Moderate" | "Weak" | "Critical";
export type HealthGrade = "A+" | "A" | "B+" | "B" | "C+" | "C" | "D" | "F";

export interface SubCriterion {
  label: string;   // e.g. "TAM", "Pricing Power"
  finding: string; // 1-sentence grounded evidence note
}

export interface CategoryScore {
  categoryName: string;
  score: number;       // 0-20
  rating: ScoreRating;
  rationale: string;   // 1-2 sentences citing evidence
  subCriteria: SubCriterion[]; // exactly 3
}

export interface BusinessScore {
  overallScore: number;        // 0-100 (sum of 5 × 0-20)
  healthGrade: HealthGrade;    // A+/A/B+/B/C+/C/D/F
  executiveSummary: string;    // 2 sentences
  categories: CategoryScore[]; // exactly 5, in canonical order
  quickWins: string[];         // exactly 3 — one per lowest-scoring category
}

// ─── Full Report ──────────────────────────────────────────────────────────────

export interface FullReport {
  companyName: string;
  dataQuality: "sufficient" | "partial" | "insufficient";
  dataNote: string;
  swot: {
    strengths: SwotItem[];
    weaknesses: SwotItem[];
    opportunities: SwotItem[];
    threats: SwotItem[];
  };
  executiveSummary: string;
  strategicPriorities: StrategicPriority[];
  majorRisks: RiskItem[];
  keyOpportunities: OpportunityItem[];
  actionPlan90Days: ActionPhase[];
  competitiveMatrix: CompetitiveMatrix;
  businessScore: BusinessScore;
  sources: ReportSources;
}

// ─── Refine / Scenario Updates ────────────────────────────────────────────────

export interface RefineUpdates {
  executiveSummary: string;
  strategicPriorities: StrategicPriority[];
  majorRisks: RiskItem[];
  keyOpportunities: OpportunityItem[];
  actionPlan90Days: ActionPhase[];
  scenarioNote: string;
}

// ─── SSE Event Types ──────────────────────────────────────────────────────────

export type SSEEvent =
  | { type: "agent_start"; agent: 1 | 2 | 3; label: string; role: string }
  | { type: "agent_update"; agent: 1 | 2 | 3; detail: string }
  | { type: "agent_complete"; agent: 1 | 2 | 3; summary: Record<string, string> }
  | { type: "report"; data: FullReport }
  | { type: "refine_start"; mode: "scenario" | "edit" | "both"; label: string }
  | { type: "refine_update"; detail: string }
  | { type: "refine_complete"; updates: RefineUpdates }
  | { type: "error"; message: string };
