import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import {
  db,
  businessesTable,
  assessmentsTable,
  strategiesTable,
  strategyPillarsTable,
  milestonesTable,
} from "@workspace/db";
import {
  CreateStrategyBody,
  CreateStrategyParams,
  ListStrategiesParams,
  GetStrategyParams,
  GetStrategyProgressParams,
} from "@workspace/api-zod";
import { generateStrategy } from "../lib/strategyEngine";

const router: IRouter = Router();

async function getStrategyWithPillars(strategyId: number) {
  const [strategy] = await db
    .select()
    .from(strategiesTable)
    .where(eq(strategiesTable.id, strategyId));

  if (!strategy) return null;

  const pillars = await db
    .select()
    .from(strategyPillarsTable)
    .where(eq(strategyPillarsTable.strategyId, strategyId))
    .orderBy(strategyPillarsTable.priority);

  const pillarsWithMilestones = await Promise.all(
    pillars.map(async (pillar) => {
      const milestones = await db
        .select()
        .from(milestonesTable)
        .where(eq(milestonesTable.pillarId, pillar.id))
        .orderBy(milestonesTable.order);
      return { ...pillar, milestones };
    })
  );

  return { ...strategy, pillars: pillarsWithMilestones };
}

router.get("/businesses/:id/strategies", async (req, res): Promise<void> => {
  const params = ListStrategiesParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const strategies = await db
    .select()
    .from(strategiesTable)
    .where(eq(strategiesTable.businessId, params.data.id))
    .orderBy(desc(strategiesTable.createdAt));

  const strategiesWithPillars = await Promise.all(
    strategies.map(async (s) => {
      const pillars = await db
        .select()
        .from(strategyPillarsTable)
        .where(eq(strategyPillarsTable.strategyId, s.id))
        .orderBy(strategyPillarsTable.priority);

      const pillarsWithMilestones = await Promise.all(
        pillars.map(async (p) => {
          const milestones = await db
            .select()
            .from(milestonesTable)
            .where(eq(milestonesTable.pillarId, p.id))
            .orderBy(milestonesTable.order);
          return { ...p, milestones };
        })
      );
      return { ...s, pillars: pillarsWithMilestones };
    })
  );

  res.json(strategiesWithPillars);
});

router.post("/businesses/:id/strategies", async (req, res): Promise<void> => {
  const params = CreateStrategyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateStrategyBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [business] = await db
    .select()
    .from(businessesTable)
    .where(eq(businessesTable.id, params.data.id));

  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }

  // Fetch the linked assessment if provided
  let assessmentResult = null;
  if (parsed.data.assessmentId) {
    const [assessment] = await db
      .select()
      .from(assessmentsTable)
      .where(eq(assessmentsTable.id, parsed.data.assessmentId));
    if (assessment) {
      assessmentResult = {
        identitySummary: assessment.identitySummary ?? "",
        strengths: assessment.strengths,
        weaknesses: assessment.weaknesses,
        opportunities: assessment.opportunities,
        threats: assessment.threats,
        strengthScore: assessment.strengthScore ?? 6,
        weaknessScore: assessment.weaknessScore ?? 6,
        opportunityScore: assessment.opportunityScore ?? 6,
        threatScore: assessment.threatScore ?? 6,
        recommendations: assessment.recommendations,
      };
    }
  }

  // Create strategy record
  const [strategy] = await db
    .insert(strategiesTable)
    .values({
      businessId: params.data.id,
      assessmentId: parsed.data.assessmentId ?? null,
      title: parsed.data.title,
      status: "generating",
    })
    .returning();

  // Generate strategy content
  const result = generateStrategy(
    business,
    parsed.data.title,
    parsed.data.focusAreas ?? [],
    assessmentResult
  );

  // Update strategy with overview
  await db
    .update(strategiesTable)
    .set({ overview: result.overview, status: "active", updatedAt: new Date() })
    .where(eq(strategiesTable.id, strategy.id));

  // Insert pillars and milestones
  for (const pillarDef of result.pillars) {
    const [pillar] = await db
      .insert(strategyPillarsTable)
      .values({
        strategyId: strategy.id,
        title: pillarDef.title,
        description: pillarDef.description,
        priority: pillarDef.priority,
      })
      .returning();

    for (const milestoneDef of pillarDef.milestones) {
      await db.insert(milestonesTable).values({
        pillarId: pillar.id,
        title: milestoneDef.title,
        description: milestoneDef.description,
        kpi: milestoneDef.kpi ?? null,
        target: milestoneDef.target ?? null,
        timeframe: milestoneDef.timeframe,
        status: "not_started",
        order: milestoneDef.order,
      });
    }
  }

  const full = await getStrategyWithPillars(strategy.id);
  res.status(201).json(full);
});

router.get("/strategies/:id", async (req, res): Promise<void> => {
  const params = GetStrategyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const full = await getStrategyWithPillars(params.data.id);
  if (!full) {
    res.status(404).json({ error: "Strategy not found" });
    return;
  }
  res.json(full);
});

router.get("/strategies/:id/progress", async (req, res): Promise<void> => {
  const params = GetStrategyProgressParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const pillars = await db
    .select()
    .from(strategyPillarsTable)
    .where(eq(strategyPillarsTable.strategyId, params.data.id))
    .orderBy(strategyPillarsTable.priority);

  const pillarBreakdown = await Promise.all(
    pillars.map(async (pillar) => {
      const milestones = await db
        .select()
        .from(milestonesTable)
        .where(eq(milestonesTable.pillarId, pillar.id));
      return {
        pillarId: pillar.id,
        pillarTitle: pillar.title,
        total: milestones.length,
        completed: milestones.filter((m) => m.status === "completed").length,
      };
    })
  );

  const total = pillarBreakdown.reduce((s, p) => s + p.total, 0);
  const completed = pillarBreakdown.reduce((s, p) => s + p.completed, 0);
  const inProgress = await db
    .select()
    .from(milestonesTable)
    .then(() => 0); // computed below

  // Get all milestones to count statuses
  const allMilestones = await Promise.all(
    pillars.map((p) =>
      db.select().from(milestonesTable).where(eq(milestonesTable.pillarId, p.id))
    )
  ).then((arrays) => arrays.flat());

  const inProgressCount = allMilestones.filter((m) => m.status === "in_progress").length;
  const notStartedCount = allMilestones.filter((m) => m.status === "not_started").length;

  res.json({
    strategyId: params.data.id,
    total,
    completed,
    inProgress: inProgressCount,
    notStarted: notStartedCount,
    completionPercent: total > 0 ? Math.round((completed / total) * 100) : 0,
    pillarBreakdown,
  });
});

export default router;
