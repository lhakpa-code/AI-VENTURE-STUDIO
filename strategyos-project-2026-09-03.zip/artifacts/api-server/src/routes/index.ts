import { Router, type IRouter } from "express";
import healthRouter from "./health";
import businessesRouter from "./businesses";
import assessmentsRouter from "./assessments";
import strategiesRouter from "./strategies";
import milestonesRouter from "./milestones";
import swotRouter from "./swot";
import reportsRouter from "./reports";
import ventureRouter from "./venture";
import architectRouter from "./architect";

const router: IRouter = Router();

router.use(healthRouter);
router.use(swotRouter);
router.use(reportsRouter);
router.use(ventureRouter);
router.use(architectRouter);
router.use(businessesRouter);
router.use(assessmentsRouter);
router.use(strategiesRouter);
router.use(milestonesRouter);

export default router;
