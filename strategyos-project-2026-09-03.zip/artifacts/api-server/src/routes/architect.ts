import { Router, type Request, type Response } from "express";
import OpenAI from "openai";

const router = Router();

function getClient(): OpenAI {
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

// ── Shared types ──────────────────────────────────────────────────────────────

interface ArchitectAnswers {
  idea: string;             // 1. startup idea or name
  target_customer: string;  // 2. target customer
  problem: string;          // 3. problem being solved
  solution: string;         // 4. proposed solution
  monetization: string;     // 5. monetization strategy
  competitors: string;      // 6. top competitors
  market: string;           // 7. country/market
  stage: string;            // 8. Idea / MVP / Launched / Generating Revenue
  budget: string;           // 9. current budget
  goals: string;            // 10. main goals next 90 days
}

const REQUIRED_FIELDS: (keyof ArchitectAnswers)[] = [
  "idea", "target_customer", "problem", "solution", "monetization",
  "competitors", "market", "stage", "budget", "goals",
];

async function callOpenAI(systemPrompt: string, userPrompt: string): Promise<unknown> {
  const client = getClient();
  const response = await client.chat.completions.create({
    model: "gpt-4o",
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
  });
  const raw = response.choices[0]?.message?.content ?? "{}";
  return JSON.parse(raw);
}

// ── AI competitor suggestion helper (wizard step 6) ──────────────────────────

const MAX_FIELD_LEN = 2000;

function asText(v: unknown): string | null {
  return typeof v === "string" && v.trim().length > 0 && v.length <= MAX_FIELD_LEN
    ? v.trim()
    : null;
}

router.post("/architect/suggest-competitors", async (req: Request, res: Response): Promise<void> => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const idea = asText(body.idea);
  const problem = asText(body.problem);
  const target_customer = asText(body.target_customer);
  const market = asText(body.market);
  if (!idea) {
    res.status(400).json({ error: "Missing or invalid required field: idea" });
    return;
  }

  const userPrompt = `Identify the top competitors for this startup concept.
Startup idea: ${idea}
${problem ? `Problem being solved: ${problem}` : ""}
${target_customer ? `Target customer: ${target_customer}` : ""}
${market ? `Target market: ${market}` : ""}

Return a JSON object:
{ "competitors": [ { "name": "...", "description": "one concise sentence on what they do and why they compete" } ] }
List 4 to 6 real, relevant competitors. Prefer well-known companies where applicable.`;

  try {
    const data = (await callOpenAI(
      "You are a competitive intelligence analyst. Output JSON only.",
      userPrompt,
    )) as { competitors?: unknown };
    if (!Array.isArray(data?.competitors)) {
      res.status(502).json({ error: "AI returned an unexpected response. Please try again." });
      return;
    }
    res.json(data);
  } catch (err: any) {
    console.error("architect/suggest-competitors error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Suggestion failed" });
  }
});

// ── Main generation: business model + 90-day roadmap ─────────────────────────

router.post("/architect/generate", async (req: Request, res: Response): Promise<void> => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const parsed: Partial<ArchitectAnswers> = {};
  const missing: string[] = [];
  for (const f of REQUIRED_FIELDS) {
    const v = asText(body[f]);
    if (v) parsed[f] = v;
    else missing.push(f);
  }
  if (missing.length) {
    res.status(400).json({ error: `Missing or invalid required fields: ${missing.join(", ")}` });
    return;
  }
  const a = parsed as ArchitectAnswers;

  const userPrompt = `A founder answered a 10-question intake. Build their custom strategy.

1. Startup idea/name: ${a.idea}
2. Target customer: ${a.target_customer}
3. Problem being solved: ${a.problem}
4. Proposed solution: ${a.solution}
5. Monetization strategy: ${a.monetization}
6. Top competitors: ${a.competitors}
7. Target country/market: ${a.market}
8. Current stage: ${a.stage}
9. Current budget: ${a.budget}
10. Main goals for the next 90 days: ${a.goals}

Return a JSON object with EXACTLY this shape:
{
  "business_model": {
    "recommended_model": "name of the optimal business model",
    "rationale": "2-3 sentences on why this model fits their market, stage and budget",
    "revenue_streams": [ { "name": "...", "description": "..." } ],
    "pricing_strategy": {
      "summary": "2-3 sentence pricing approach tailored to their target market and budget",
      "tiers": [ { "name": "...", "price": "e.g. $29/mo", "target": "who it's for", "includes": "key value" } ]
    },
    "acquisition_channels": [ { "name": "...", "description": "why this channel fits their budget and market, with a concrete first tactic" } ],
    "unit_economics": {
      "summary": "2-3 sentence overview matched to their budget",
      "estimated_cac": "e.g. $40-80",
      "target_ltv": "e.g. $350+",
      "gross_margin": "e.g. 80%+",
      "payback_period": "e.g. under 6 months"
    },
    "key_metrics": [ "3-5 metrics this founder should track given their stage" ]
  },
  "roadmap": {
    "month_1": { "theme": "short theme title", "steps": [ { "week": "e.g. Week 1-2", "title": "...", "description": "concrete, specific action", "outcome": "measurable result" } ] },
    "month_2": { "theme": "...", "steps": [ ... ] },
    "month_3": { "theme": "...", "steps": [ ... ] }
  }
}
Include 3-4 acquisition_channels realistic for their budget. Each month must have 4-6 concrete steps with a "week" timing label (e.g. "Week 1", "Week 2-3"), calibrated to their stated budget, stage, and 90-day goals. Be specific to THIS business — no generic advice.`;

  try {
    const data = (await callOpenAI(
      "You are a veteran startup architect and operator who has taken multiple companies from idea to revenue. Output JSON only, matching the requested schema exactly.",
      userPrompt,
    )) as { business_model?: unknown; roadmap?: { month_1?: unknown; month_2?: unknown; month_3?: unknown } };
    if (
      !data?.business_model ||
      !data?.roadmap?.month_1 ||
      !data?.roadmap?.month_2 ||
      !data?.roadmap?.month_3
    ) {
      res.status(502).json({ error: "AI returned an incomplete strategy. Please try again." });
      return;
    }
    res.json(data);
  } catch (err: any) {
    console.error("architect/generate error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── v5 Founder Chat: strategy blueprint from a 7-question conversation ────────

const BLUEPRINT_FIELDS = [
  "idea", "target_customer", "problem", "solution", "monetization",
  "competitors", "market", "stage", "budget", "goals",
] as const;

router.post("/architect/blueprint", async (req: Request, res: Response): Promise<void> => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const parsed: Record<string, string> = {};
  const missing: string[] = [];
  for (const f of BLUEPRINT_FIELDS) {
    const v = asText(body[f]);
    if (v) parsed[f] = v;
    else missing.push(f);
  }
  if (missing.length) {
    res.status(400).json({ error: `Missing or invalid required fields: ${missing.join(", ")}` });
    return;
  }

  const userPrompt = `A founder answered a 10-question conversational intake. Draft their Founder Strategy Blueprint.

1. Startup idea: ${parsed.idea}
2. Target customer: ${parsed.target_customer}
3. Problem being solved: ${parsed.problem}
4. Proposed solution: ${parsed.solution}
5. How they plan to make money: ${parsed.monetization}
6. Competitors: ${parsed.competitors}
7. Target market: ${parsed.market}
8. Current stage: ${parsed.stage}
9. Budget: ${parsed.budget}
10. Main goals for the next 90 days: ${parsed.goals}

Return a JSON object with EXACTLY this shape (every field a plain STRING unless noted — no nested objects):
{
  "business_concept": "2-3 sentence sharp articulation of the business",
  "target_customer": "2-3 sentences profiling the ideal customer and their buying trigger",
  "problem_strength": "2-3 sentences assessing how painful/urgent the problem is, with an honest strength rating (e.g. 'Strong 8/10')",
  "value_proposition": "1-2 sentence crisp value proposition statement",
  "competitive_positioning": "2-3 sentences on how to position against likely alternatives/competitors",
  "recommended_business_model": "2-3 sentences naming the optimal model and why it fits their stage and budget",
  "pricing_approach": "2-3 sentences on pricing tailored to the target customer and market",
  "go_to_market_strategy": "3-4 sentences on the GTM motion realistic for their budget, with concrete first channels",
  "major_risks": [ "3-5 strings: the biggest risks facing this business, each with a short mitigation hint" ],
  "recommended_kpis": [ "4-6 KPI strings appropriate to their stage" ],
  "mvp_priorities": [ "4-6 strings: what to build/validate first, in priority order" ],
  "personalized_roadmap": [ { "phase": "e.g. Days 1-30", "focus": "short phase title", "actions": [ "2-4 concrete action strings" ] } ]
}
personalized_roadmap must cover the next 90 days in exactly 3 phases — "Days 1-30", "Days 31-60", "Days 61-90" — calibrated to their stage (${parsed.stage}), budget (${parsed.budget}) and stated 90-day goals. Be direct and useful, specific to THIS business — no generic filler.`;

  try {
    const data = (await callOpenAI(
      "You are a veteran startup strategist drafting a founder's company blueprint. Output JSON only, matching the requested schema exactly. All prose fields must be plain strings.",
      userPrompt,
    )) as Record<string, unknown>;

    // Strict shape validation: JSON mode guarantees JSON, not our schema.
    const isStr = (v: unknown): v is string => typeof v === "string" && v.trim().length > 0;
    const isStrArray = (v: unknown, min = 1): v is string[] =>
      Array.isArray(v) && v.length >= min && v.every(isStr);
    const proseKeys = [
      "business_concept", "target_customer", "problem_strength", "value_proposition",
      "competitive_positioning", "recommended_business_model", "pricing_approach",
      "go_to_market_strategy",
    ];
    const roadmap = data?.personalized_roadmap;
    const valid =
      proseKeys.every((k) => isStr(data?.[k])) &&
      isStrArray(data?.major_risks, 3) &&
      isStrArray(data?.recommended_kpis, 4) &&
      isStrArray(data?.mvp_priorities, 4) &&
      Array.isArray(roadmap) && roadmap.length === 3 &&
      roadmap.every(
        (p: unknown, i: number) =>
          typeof p === "object" && p !== null &&
          (p as Record<string, unknown>).phase === ["Days 1-30", "Days 31-60", "Days 61-90"][i] &&
          isStr((p as Record<string, unknown>).focus) &&
          isStrArray((p as Record<string, unknown>).actions),
      );
    if (!valid) {
      res.status(502).json({ error: "AI returned an unexpected blueprint format. Please try again." });
      return;
    }
    res.json(data);
  } catch (err: any) {
    console.error("architect/blueprint error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── Business Growth Strategy Report (for running businesses) ─────────────────

const GROWTH_FIELDS = [
  "business", "customer", "revenue_model", "monthly_revenue", "challenge",
  "marketing", "competitors", "team_size", "goals",
] as const;

router.post("/architect/growth-report", async (req: Request, res: Response): Promise<void> => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const parsed: Record<string, string> = {};
  const missing: string[] = [];
  for (const f of GROWTH_FIELDS) {
    const v = asText(body[f]);
    if (v) parsed[f] = v;
    else missing.push(f);
  }
  if (missing.length) {
    res.status(400).json({ error: `Missing or invalid required fields: ${missing.join(", ")}` });
    return;
  }

  const userPrompt = `An operator of a RUNNING business answered a 9-question diagnostic. Draft their Business Growth Strategy Report.

1. What the business does: ${parsed.business}
2. Who the customers are: ${parsed.customer}
3. How it makes money: ${parsed.revenue_model}
4. Current monthly revenue: ${parsed.monthly_revenue}
5. Biggest challenge right now: ${parsed.challenge}
6. Current marketing channels: ${parsed.marketing}
7. Main competitors: ${parsed.competitors}
8. Team size: ${parsed.team_size}
9. Goals for the next 90 days: ${parsed.goals}

Return a JSON object with EXACTLY this shape (every field a plain STRING unless noted — no nested objects):
{
  "current_state_diagnosis": "3-4 sentences honestly diagnosing where this business is today and why it faces its stated challenge",
  "business_model_recommendation": "2-3 sentences on whether to keep, adjust, or overhaul the revenue model, and how",
  "marketing_overhaul": "3-4 sentences on how to rework marketing given their current channels, with concrete first moves",
  "pricing_strategy": "2-3 sentences on pricing changes appropriate to their revenue and market position",
  "retention_strategy": "2-3 sentences on keeping and expanding existing customers",
  "competitive_repositioning": "2-3 sentences on how to reposition against the named competitors",
  "operational_efficiency": "2-3 sentences on ops improvements realistic for a team of ${parsed.team_size}",
  "major_risks": [ "3-5 strings: biggest risks to the turnaround, each with a short mitigation hint" ],
  "recommended_kpis": [ "4-6 KPI strings to track the turnaround" ],
  "turnaround_plan": [ { "phase": "e.g. Days 1-30", "focus": "short phase title", "actions": [ "2-4 concrete action strings" ] } ]
}
turnaround_plan must cover the next 90 days in exactly 3 phases — "Days 1-30", "Days 31-60", "Days 61-90" — calibrated to their stated challenge, team size and 90-day goals. Be direct and useful, specific to THIS business — no generic filler.`;

  try {
    const data = (await callOpenAI(
      "You are a veteran growth strategist and turnaround operator. Output JSON only, matching the requested schema exactly. All prose fields must be plain strings.",
      userPrompt,
    )) as Record<string, unknown>;

    const isStr = (v: unknown): v is string => typeof v === "string" && v.trim().length > 0;
    const isStrArray = (v: unknown, min = 1): v is string[] =>
      Array.isArray(v) && v.length >= min && v.every(isStr);
    const proseKeys = [
      "current_state_diagnosis", "business_model_recommendation", "marketing_overhaul",
      "pricing_strategy", "retention_strategy", "competitive_repositioning", "operational_efficiency",
    ];
    const plan = data?.turnaround_plan;
    const valid =
      proseKeys.every((k) => isStr(data?.[k])) &&
      isStrArray(data?.major_risks, 3) &&
      isStrArray(data?.recommended_kpis, 4) &&
      Array.isArray(plan) && plan.length === 3 &&
      plan.every(
        (p: unknown, i: number) =>
          typeof p === "object" && p !== null &&
          (p as Record<string, unknown>).phase === ["Days 1-30", "Days 31-60", "Days 61-90"][i] &&
          isStr((p as Record<string, unknown>).focus) &&
          isStrArray((p as Record<string, unknown>).actions),
      );
    if (!valid) {
      res.status(502).json({ error: "AI returned an unexpected report format. Please try again." });
      return;
    }
    res.json(data);
  } catch (err: any) {
    console.error("architect/growth-report error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── Investor pitch deck ───────────────────────────────────────────────────────

const DECK_SLIDES = [
  "cover",
  "problem",
  "solution",
  "market_opportunity",
  "product",
  "business_model",
  "competition",
  "traction",
  "go_to_market",
  "the_ask",
  "vision",
] as const;

type SlideKey = typeof DECK_SLIDES[number];

interface Slide {
  key: SlideKey;
  title: string;
  headline: string;
  bullets: string[];
}

function buildPptx(companyName: string, slides: Slide[]): Promise<Buffer> {
  // Dynamic import so esbuild bundles CJS pptxgenjs correctly
  return import("pptxgenjs").then(({ default: PptxGenJS }) => {
    const pptx = new PptxGenJS();
    pptx.layout = "LAYOUT_WIDE";

    const NAVY = "0a1a2f";
    const CYAN = "22d3ee";
    const AMBER = "f59e0b";
    const WHITE = "FFFFFF";
    const MUTED = "94a3b8";

    for (const slide of slides) {
      const s = pptx.addSlide();
      // Background
      s.background = { color: NAVY };

      if (slide.key === "cover") {
        // Large centred title
        s.addText(companyName, { x: 0.5, y: 1.5, w: "90%", h: 1.2, fontSize: 44, bold: true, color: WHITE, align: "center" });
        s.addText(slide.headline, { x: 0.5, y: 3.0, w: "90%", h: 0.8, fontSize: 20, color: CYAN, align: "center" });
        s.addText(slide.bullets.join("  ·  "), { x: 0.5, y: 4.0, w: "90%", h: 0.5, fontSize: 13, color: MUTED, align: "center" });
      } else {
        // Slide title strip
        s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: "100%", h: 1.1, fill: { color: "0d2340" } });
        s.addText(slide.title.toUpperCase(), { x: 0.4, y: 0.1, w: "85%", h: 0.4, fontSize: 10, bold: true, color: CYAN, charSpacing: 3 });
        s.addText(slide.headline, { x: 0.4, y: 0.45, w: "90%", h: 0.55, fontSize: 20, bold: true, color: WHITE });

        // Cyan accent line
        s.addShape(pptx.ShapeType.rect, { x: 0.4, y: 1.2, w: 1.2, h: 0.05, fill: { color: CYAN } });

        // Bullets
        const bulletObjs = slide.bullets.map((b) => ({
          text: b,
          options: { bullet: { type: "number" as const }, fontSize: 16, color: WHITE, paraSpaceAfter: 8 },
        }));
        s.addText(bulletObjs, { x: 0.4, y: 1.45, w: "90%", h: 4.5, valign: "top" });
      }

      // Corner accent
      s.addShape(pptx.ShapeType.rect, { x: 0, y: 6.9, w: 0.5, h: 0.1, fill: { color: AMBER } });
      s.addText(slide.title, { x: 0.6, y: 6.88, w: "80%", h: 0.18, fontSize: 9, color: MUTED });
    }

    return pptx.write({ outputType: "nodebuffer" }) as Promise<Buffer>;
  });
}

router.post("/architect/pitch-deck", async (req: Request, res: Response): Promise<void> => {
  const body = (req.body ?? {}) as Record<string, unknown>;
  const company_name = asText(body.company_name);
  const funding_ask = asText(body.funding_ask);
  const blueprint = body.blueprint as Record<string, unknown> | undefined;

  if (!company_name || !funding_ask || !blueprint) {
    res.status(400).json({ error: "Missing required fields: company_name, funding_ask, blueprint" });
    return;
  }

  const tagline = typeof body.tagline === "string" && body.tagline.trim() ? body.tagline.trim() : null;

  const userPrompt = `You are drafting an investor pitch deck for a startup. Here is their Founder Strategy Blueprint:

Company name: ${company_name}
${tagline ? `Tagline: ${tagline}` : ""}
Funding ask: ${funding_ask}

Blueprint summary:
- Business concept: ${String(blueprint.business_concept ?? "")}
- Target customer: ${String(blueprint.target_customer ?? "")}
- Problem: ${String(blueprint.problem_strength ?? "")}
- Value proposition: ${String(blueprint.value_proposition ?? "")}
- Competitive positioning: ${String(blueprint.competitive_positioning ?? "")}
- Business model: ${String(blueprint.recommended_business_model ?? "")}
- Pricing: ${String(blueprint.pricing_approach ?? "")}
- GTM: ${String(blueprint.go_to_market_strategy ?? "")}

Draft exactly 11 slides as a JSON array, in this EXACT order of "key" values: cover, problem, solution, market_opportunity, product, business_model, competition, traction, go_to_market, the_ask, vision. Each slide has: "key", "title" (the slide label), "headline" (one punchy sentence), "bullets" (array of 3-5 concrete strings — every bullet must be a plain string).
For "cover": headline is the tagline (write a great one if not provided), bullets are 3 key stats/facts (founding date or "Founded 2024", market size, funding ask).
For "the_ask": bullets must include the funding amount, use of funds (3 items), and expected milestone.
Return ONLY the JSON array — no markdown, no preamble.`;

  try {
    const client = getClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: "You are an expert pitch deck writer. Output a JSON object with a single key 'slides' whose value is the array of 11 slide objects." },
        { role: "user", content: userPrompt },
      ],
    });

    const raw = response.choices[0]?.message?.content ?? "{}";
    const parsed = JSON.parse(raw) as { slides?: unknown };
    const slides = parsed.slides;

    if (!Array.isArray(slides) || slides.length !== 11) {
      res.status(502).json({ error: "AI returned an unexpected deck format. Please try again." });
      return;
    }

    const isStr = (v: unknown): v is string => typeof v === "string" && v.trim().length > 0;
    const validSlides = slides.every(
      (s: unknown, i: number) =>
        typeof s === "object" && s !== null &&
        (s as Record<string, unknown>).key === DECK_SLIDES[i] &&
        isStr((s as Record<string, unknown>).title) &&
        isStr((s as Record<string, unknown>).headline) &&
        Array.isArray((s as Record<string, unknown>).bullets) &&
        ((s as Record<string, unknown>).bullets as unknown[]).length >= 2 &&
        ((s as Record<string, unknown>).bullets as unknown[]).length <= 6 &&
        ((s as Record<string, unknown>).bullets as unknown[]).every(isStr),
    );
    if (!validSlides) {
      res.status(502).json({ error: "AI returned malformed slide data. Please try again." });
      return;
    }

    // Build PPTX
    const pptxBuffer = await buildPptx(company_name, slides as Slide[]);

    res.json({
      slides,
      pptx_base64: pptxBuffer.toString("base64"),
    });
  } catch (err: any) {
    console.error("architect/pitch-deck error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Pitch deck generation failed" });
  }
});

export default router;
