import { Router, type IRouter, type Request, type Response } from "express";
import { db, reportsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router: IRouter = Router();

// POST /api/reports — save a report
router.post("/reports", async (req: Request, res: Response) => {
  try {
    const { companyName, dataQuality, reportJson } = req.body as {
      companyName: string;
      dataQuality: string;
      reportJson: unknown;
    };

    if (!companyName || !reportJson) {
      res.status(400).json({ error: "companyName and reportJson are required" });
      return;
    }

    const [row] = await db
      .insert(reportsTable)
      .values({
        companyName,
        dataQuality: dataQuality ?? "partial",
        reportJson,
      })
      .returning();

    res.json({ id: row.id, createdAt: row.createdAt });
  } catch (err) {
    console.error("POST /reports error:", err);
    res.status(500).json({ error: "Failed to save report" });
  }
});

// GET /api/reports — list most recent 20
router.get("/reports", async (_req: Request, res: Response) => {
  try {
    const rows = await db
      .select({
        id: reportsTable.id,
        companyName: reportsTable.companyName,
        dataQuality: reportsTable.dataQuality,
        createdAt: reportsTable.createdAt,
      })
      .from(reportsTable)
      .orderBy(desc(reportsTable.createdAt))
      .limit(20);

    res.json(rows);
  } catch (err) {
    console.error("GET /reports error:", err);
    res.status(500).json({ error: "Failed to fetch reports" });
  }
});

// GET /api/reports/by-company/:name — get all reports for a company (scores only, newest first)
router.get("/reports/by-company/:name", async (req: Request, res: Response) => {
  try {
    const rawName = Array.isArray(req.params.name) ? req.params.name[0] : req.params.name;
    const name = decodeURIComponent(rawName ?? "").trim();
    if (!name) {
      res.status(400).json({ error: "Company name required" });
      return;
    }

    const rows = await db
      .select()
      .from(reportsTable)
      .orderBy(desc(reportsTable.createdAt));

    // Case-insensitive match on companyName
    const matched = rows
      .filter(r => r.companyName.trim().toLowerCase() === name.toLowerCase())
      .map(r => ({
        id: r.id,
        companyName: r.companyName,
        createdAt: r.createdAt,
        businessScore: (r.reportJson as any)?.businessScore ?? null,
      }));

    res.json(matched);
  } catch (err) {
    console.error("GET /reports/by-company/:name error:", err);
    res.status(500).json({ error: "Failed to fetch company reports" });
  }
});

// GET /api/reports/:id — get a single report
router.get("/reports/:id", async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      res.status(400).json({ error: "Invalid report ID" });
      return;
    }

    const [row] = await db
      .select()
      .from(reportsTable)
      .where(eq(reportsTable.id, id))
      .limit(1);

    if (!row) {
      res.status(404).json({ error: "Report not found" });
      return;
    }

    res.json(row);
  } catch (err) {
    console.error("GET /reports/:id error:", err);
    res.status(500).json({ error: "Failed to fetch report" });
  }
});

export default router;
