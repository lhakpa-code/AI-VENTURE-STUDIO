import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, businessesTable, assessmentsTable } from "@workspace/db";
import {
  CreateAssessmentBody,
  CreateAssessmentParams,
  ListAssessmentsParams,
  GetAssessmentParams,
} from "@workspace/api-zod";
import { generateAssessment } from "../lib/strategyEngine";

const router: IRouter = Router();

router.get("/businesses/:id/assessments", async (req, res): Promise<void> => {
  const params = ListAssessmentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const assessments = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.businessId, params.data.id))
    .orderBy(desc(assessmentsTable.createdAt));
  res.json(assessments);
});

router.post("/businesses/:id/assessments", async (req, res): Promise<void> => {
  const params = CreateAssessmentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateAssessmentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [business] = await db
    .select()
    .from(businessesTable)
    .where(eq(businessesTable.id, params.data.id));

  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }

  // Create a pending record
  const [pending] = await db
    .insert(assessmentsTable)
    .values({
      businessId: params.data.id,
      status: "pending",
      additionalContext: parsed.data.additionalContext,
      strengths: [],
      weaknesses: [],
      opportunities: [],
      threats: [],
      recommendations: [],
    })
    .returning();

  // Generate assessment using the strategy engine
  const result = generateAssessment(business, parsed.data.additionalContext);

  const [assessment] = await db
    .update(assessmentsTable)
    .set({
      status: "completed",
      identitySummary: result.identitySummary,
      strengths: result.strengths,
      weaknesses: result.weaknesses,
      opportunities: result.opportunities,
      threats: result.threats,
      strengthScore: result.strengthScore,
      weaknessScore: result.weaknessScore,
      opportunityScore: result.opportunityScore,
      threatScore: result.threatScore,
      recommendations: result.recommendations,
    })
    .where(eq(assessmentsTable.id, pending.id))
    .returning();

  res.status(201).json(assessment);
});

router.get("/assessments/:id", async (req, res): Promise<void> => {
  const params = GetAssessmentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [assessment] = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.id, params.data.id));
  if (!assessment) {
    res.status(404).json({ error: "Assessment not found" });
    return;
  }
  res.json(assessment);
});

export default router;
