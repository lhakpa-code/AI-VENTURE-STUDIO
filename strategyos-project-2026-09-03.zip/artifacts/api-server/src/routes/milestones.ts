import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, milestonesTable, kpiLogsTable } from "@workspace/db";
import { UpdateMilestoneBody, UpdateMilestoneParams } from "@workspace/api-zod";

const router: IRouter = Router();

router.patch("/milestones/:id", async (req, res): Promise<void> => {
  const params = UpdateMilestoneParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateMilestoneBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updateData: Record<string, unknown> = { updatedAt: new Date() };
  if (parsed.data.status !== undefined) updateData.status = parsed.data.status;
  if (parsed.data.title !== undefined) updateData.title = parsed.data.title;
  if (parsed.data.description !== undefined) updateData.description = parsed.data.description;
  if (parsed.data.timeframe !== undefined) updateData.timeframe = parsed.data.timeframe;

  const [milestone] = await db
    .update(milestonesTable)
    .set(updateData)
    .where(eq(milestonesTable.id, params.data.id))
    .returning();

  if (!milestone) {
    res.status(404).json({ error: "Milestone not found" });
    return;
  }

  res.json(milestone);
});

router.get("/milestones/:id/kpi-logs", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid milestone id" });
    return;
  }
  const logs = await db
    .select()
    .from(kpiLogsTable)
    .where(eq(kpiLogsTable.milestoneId, id))
    .orderBy(desc(kpiLogsTable.loggedAt));
  res.json(logs);
});

router.post("/milestones/:id/kpi-logs", async (req, res): Promise<void> => {
  const id = Number(req.params.id);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid milestone id" });
    return;
  }
  const [milestone] = await db.select().from(milestonesTable).where(eq(milestonesTable.id, id));
  if (!milestone) {
    res.status(404).json({ error: "Milestone not found" });
    return;
  }
  const { actualValue, note } = req.body as { actualValue?: string; note?: string };
  if (!actualValue || typeof actualValue !== "string" || actualValue.trim() === "") {
    res.status(400).json({ error: "actualValue is required" });
    return;
  }
  const [log] = await db
    .insert(kpiLogsTable)
    .values({ milestoneId: id, actualValue: actualValue.trim(), note: note ?? null })
    .returning();
  res.status(201).json(log);
});

export default router;
