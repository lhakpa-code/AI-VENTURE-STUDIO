import { Router, type Request, type Response } from "express";
import OpenAI from "openai";
import { db, ventureAnalysesTable } from "@workspace/db";
import { desc } from "drizzle-orm";

const router = Router();

function getClient(): OpenAI {
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

// ── Shared request body type ──────────────────────────────────────────────────

interface VentureBody {
  company_name: string;
  business_description: string;
  target_market: string;
  pricing_tier?: string;
}

function validate(body: Partial<VentureBody>, res: Response): body is VentureBody {
  const missing: string[] = [];
  if (!body.company_name?.trim())          missing.push("company_name");
  if (!body.business_description?.trim())  missing.push("business_description");
  if (!body.target_market?.trim())         missing.push("target_market");
  if (missing.length) {
    res.status(400).json({ error: `Missing required fields: ${missing.join(", ")}` });
    return false;
  }
  return true;
}

async function callOpenAI(systemPrompt: string, userPrompt: string): Promise<unknown> {
  const client = getClient();
  const response = await client.chat.completions.create({
    model: "gpt-4o",
    response_format: { type: "json_object" },
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user",   content: userPrompt },
    ],
  });
  const raw = response.choices[0]?.message?.content ?? "{}";
  return JSON.parse(raw);
}

// ── 1. Business Model & Idea Optimizer ───────────────────────────────────────

router.post("/venture/business-model", async (req: Request, res: Response): Promise<void> => {
  const body = req.body as Partial<VentureBody>;
  if (!validate(body, res)) return;

  const { company_name, business_description, target_market } = body;

  const userPrompt = `Act as a veteran Venture Builder. Analyze this business concept and suggest the optimal business model.
Company: ${company_name}
Description: ${business_description}
Target Market: ${target_market}

Return a JSON object with:
- recommended_model: Name of the model (e.g., Freemium B2B SaaS, Marketplace, Usage-based)
- monetization_streams: array of 3 strings, each one core revenue channel
- pricing_strategy: a single STRING (2-4 sentences) describing suggested pricing tiers and reasoning — NOT an object
- unit_economics: a single STRING (2-3 sentences) with estimated LTV/CAC ratio targets and gross margins — NOT an object

All field values must be plain strings (or an array of strings for monetization_streams). Do not use nested objects.`;

  try {
    const data = await callOpenAI("You are a startup founder advisor. Output JSON only.", userPrompt);
    res.json(data);
  } catch (err: any) {
    console.error("venture/business-model error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── 2. 3-Year Pro-Forma Financial Model ──────────────────────────────────────

router.post("/venture/financial-model", async (req: Request, res: Response): Promise<void> => {
  const body = req.body as Partial<VentureBody>;
  if (!validate(body, res)) return;

  const { company_name, business_description, pricing_tier = "Subscription SaaS" } = body;

  const userPrompt = `Build a realistic 3-Year Financial Forecast for ${company_name}.
Business Model: ${pricing_tier}
Description: ${business_description}

Return a JSON object with:
- year_1: { "revenue": 0, "cogs": 0, "opex": 0, "net_profit": 0, "paid_customers": 0 }
- year_2: { "revenue": 0, "cogs": 0, "opex": 0, "net_profit": 0, "paid_customers": 0 }
- year_3: { "revenue": 0, "cogs": 0, "opex": 0, "net_profit": 0, "paid_customers": 0 }
- key_assumptions: List of 4 critical financial assumptions (e.g., monthly churn %, CAC, ARPU)`;

  try {
    const data = await callOpenAI(
      "You are a Startup CFO. Output valid JSON with numeric values for financial fields.",
      userPrompt,
    );
    res.json(data);
  } catch (err: any) {
    console.error("venture/financial-model error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── 3. 10-Slide Investor Pitch Deck ──────────────────────────────────────────

router.post("/venture/pitch-deck", async (req: Request, res: Response): Promise<void> => {
  const body = req.body as Partial<VentureBody>;
  if (!validate(body, res)) return;

  const { company_name, business_description, target_market } = body;

  const userPrompt = `Create a high-converting 10-Slide Investor Pitch Deck outline for ${company_name}.
Description: ${business_description}
Target Market: ${target_market}

Return a JSON object containing an array of 10 slides.
Each slide must have:
- slide_number: int
- title: str (e.g., The Problem, The Solution, Market Size, Traction, The Ask)
- headline: str (One punchy sentence)
- bullet_points: List of 3 key takeaways for investors`;

  try {
    const data = await callOpenAI("You are a Sequoia VC partner. Output JSON only.", userPrompt);
    res.json(data);
  } catch (err: any) {
    console.error("venture/pitch-deck error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── 4. Interactive Prototype / Wireframe Specification ───────────────────────

router.post("/venture/prototype-spec", async (req: Request, res: Response): Promise<void> => {
  const body = req.body as Partial<VentureBody>;
  if (!validate(body, res)) return;

  const { company_name, business_description } = body;

  const userPrompt = `Design an interactive MVP UI/UX Prototype specification for ${company_name}.
Description: ${business_description}

Return a JSON object with:
- core_user_flow: List of steps from onboarding to primary value moment
- key_screens: List of 3 main app screens with titles, components, and key actions
- html_mockup_snippet: A clean Tailwind HTML wireframe component representing the main app dashboard`;

  try {
    const data = await callOpenAI("You are a Lead Product Designer. Output JSON only.", userPrompt);
    res.json(data);
  } catch (err: any) {
    console.error("venture/prototype-spec error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── 5. Go-To-Market (GTM) Outreach Campaign ──────────────────────────────────

router.post("/venture/gtm-campaign", async (req: Request, res: Response): Promise<void> => {
  const body = req.body as Partial<VentureBody>;
  if (!validate(body, res)) return;

  const { company_name, target_market } = body;

  const userPrompt = `Create an outbound Go-To-Market (GTM) launch campaign for ${company_name}.
Target Market: ${target_market}

Return a JSON object with:
- ideal_customer_profile: Clear description of the decision-maker
- cold_email_sequence: Array of 3 emails (Initial Hook, Value Add, Final Follow-up) with Subject and Body
- linkedin_outreach_sequence: Array of 2 connection request messages & follow-ups
- launch_channels: Top 3 channels to acquire initial 100 users`;

  try {
    const data = await callOpenAI("You are a Head of Growth. Output JSON only.", userPrompt);
    res.json(data);
  } catch (err: any) {
    console.error("venture/gtm-campaign error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
});

// ── 6. Save a completed Venture Studio analysis ───────────────────────────────

router.post("/venture/save", async (req: Request, res: Response): Promise<void> => {
  try {
    const { companyName, results } = req.body as {
      companyName: string;
      results: unknown;
    };

    if (!companyName || !results) {
      res.status(400).json({ error: "companyName and results are required" });
      return;
    }

    const [row] = await db
      .insert(ventureAnalysesTable)
      .values({ companyName, resultsJson: results })
      .returning();

    res.json({ id: row.id, createdAt: row.createdAt });
  } catch (err: any) {
    console.error("POST /venture/save error:", err?.message);
    res.status(500).json({ error: "Failed to save venture analysis" });
  }
});

// ── 7. List saved Venture Studio analyses ─────────────────────────────────────

router.get("/venture/history", async (_req: Request, res: Response): Promise<void> => {
  try {
    const rows = await db
      .select({
        id: ventureAnalysesTable.id,
        companyName: ventureAnalysesTable.companyName,
        resultsJson: ventureAnalysesTable.resultsJson,
        createdAt: ventureAnalysesTable.createdAt,
      })
      .from(ventureAnalysesTable)
      .orderBy(desc(ventureAnalysesTable.createdAt))
      .limit(50);

    res.json(rows);
  } catch (err: any) {
    console.error("GET /venture/history error:", err?.message);
    res.status(500).json({ error: "Failed to fetch venture history" });
  }
});

export default router;
