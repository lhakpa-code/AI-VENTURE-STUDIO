import { Router, type IRouter, type Request, type Response } from "express";
import OpenAI from "openai";

const router: IRouter = Router();

function getClient(): OpenAI {
  if (!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY not set");
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

// ─── JSON Schema for Structured Output ───────────────────────────────────────

const SWOT_ITEM_SCHEMA = {
  type: "object",
  properties: {
    point: { type: "string" },
    evidence: { type: "string" },
    strategic_impact: { type: "string" },
    confidence_score: { type: "string", enum: ["high", "medium", "low"] },
    citation: { type: "string" },
  },
  required: ["point", "evidence", "strategic_impact", "confidence_score", "citation"],
  additionalProperties: false,
};

const REPORT_SCHEMA = {
  type: "object",
  properties: {
    dataQuality: { type: "string", enum: ["sufficient", "partial", "insufficient"] },
    dataNote: { type: "string" },
    swot: {
      type: "object",
      properties: {
        strengths: { type: "array", items: SWOT_ITEM_SCHEMA },
        weaknesses: { type: "array", items: SWOT_ITEM_SCHEMA },
        opportunities: { type: "array", items: SWOT_ITEM_SCHEMA },
        threats: { type: "array", items: SWOT_ITEM_SCHEMA },
      },
      required: ["strengths", "weaknesses", "opportunities", "threats"],
      additionalProperties: false,
    },
    executiveSummary: { type: "string" },
    strategicPriorities: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          rationale: { type: "string" },
          keyAction: { type: "string" },
          citation: { type: "string" },
        },
        required: ["title", "rationale", "keyAction", "citation"],
        additionalProperties: false,
      },
    },
    majorRisks: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          description: { type: "string" },
          impact: { type: "string", enum: ["High", "Medium", "Low"] },
          mitigation: { type: "string" },
          citation: { type: "string" },
          confidence_score: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["title", "description", "impact", "mitigation", "citation", "confidence_score"],
        additionalProperties: false,
      },
    },
    keyOpportunities: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          description: { type: "string" },
          advantage: { type: "string" },
          timeframe: { type: "string" },
          citation: { type: "string" },
          confidence_score: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["title", "description", "advantage", "timeframe", "citation", "confidence_score"],
        additionalProperties: false,
      },
    },
    actionPlan90Days: {
      type: "array",
      items: {
        type: "object",
        properties: {
          phase: { type: "string" },
          focus: { type: "string" },
          actions: { type: "array", items: { type: "string" } },
          milestone: { type: "string" },
        },
        required: ["phase", "focus", "actions", "milestone"],
        additionalProperties: false,
      },
    },
    competitiveMatrix: {
      type: "object",
      properties: {
        targetMoats: { type: "array", items: { type: "string" } },
        targetVulnerabilities: { type: "array", items: { type: "string" } },
        benchmarkSummary: { type: "string" },
        competitors: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              pricingModel: { type: "string" },
              marketShareEstimate: { type: "string" },
              techStackIndicators: { type: "string" },
              hiringTrends: { type: "string" },
              keyMoat: { type: "string" },
              keyVulnerability: { type: "string" },
              vsTargetCompany: { type: "string" },
            },
            required: ["name", "pricingModel", "marketShareEstimate", "techStackIndicators", "hiringTrends", "keyMoat", "keyVulnerability", "vsTargetCompany"],
            additionalProperties: false,
          },
        },
      },
      required: ["targetMoats", "targetVulnerabilities", "benchmarkSummary", "competitors"],
      additionalProperties: false,
    },
    businessScore: {
      type: "object",
      properties: {
        overallScore: { type: "integer" },
        healthGrade: { type: "string", enum: ["A+", "A", "B+", "B", "C+", "C", "D", "F"] },
        executiveSummary: { type: "string" },
        categories: {
          type: "array",
          items: {
            type: "object",
            properties: {
              categoryName: { type: "string" },
              score: { type: "integer" },
              rating: { type: "string", enum: ["Excellent", "Strong", "Moderate", "Weak", "Critical"] },
              rationale: { type: "string" },
              subCriteria: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    label: { type: "string" },
                    finding: { type: "string" },
                  },
                  required: ["label", "finding"],
                  additionalProperties: false,
                },
              },
            },
            required: ["categoryName", "score", "rating", "rationale", "subCriteria"],
            additionalProperties: false,
          },
        },
        quickWins: {
          type: "array",
          items: { type: "string" },
        },
      },
      required: ["overallScore", "healthGrade", "executiveSummary", "categories", "quickWins"],
      additionalProperties: false,
    },
  },
  required: ["dataQuality", "dataNote", "swot", "executiveSummary", "strategicPriorities", "majorRisks", "keyOpportunities", "actionPlan90Days", "competitiveMatrix", "businessScore"],
  additionalProperties: false,
};

const REFINE_SCHEMA = {
  type: "object",
  properties: {
    executiveSummary: { type: "string" },
    strategicPriorities: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          rationale: { type: "string" },
          keyAction: { type: "string" },
          citation: { type: "string" },
        },
        required: ["title", "rationale", "keyAction", "citation"],
        additionalProperties: false,
      },
    },
    majorRisks: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          description: { type: "string" },
          impact: { type: "string", enum: ["High", "Medium", "Low"] },
          mitigation: { type: "string" },
          citation: { type: "string" },
          confidence_score: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["title", "description", "impact", "mitigation", "citation", "confidence_score"],
        additionalProperties: false,
      },
    },
    keyOpportunities: {
      type: "array",
      items: {
        type: "object",
        properties: {
          title: { type: "string" },
          description: { type: "string" },
          advantage: { type: "string" },
          timeframe: { type: "string" },
          citation: { type: "string" },
          confidence_score: { type: "string", enum: ["high", "medium", "low"] },
        },
        required: ["title", "description", "advantage", "timeframe", "citation", "confidence_score"],
        additionalProperties: false,
      },
    },
    actionPlan90Days: {
      type: "array",
      items: {
        type: "object",
        properties: {
          phase: { type: "string" },
          focus: { type: "string" },
          actions: { type: "array", items: { type: "string" } },
          milestone: { type: "string" },
        },
        required: ["phase", "focus", "actions", "milestone"],
        additionalProperties: false,
      },
    },
    scenarioNote: { type: "string" },
  },
  required: ["executiveSummary", "strategicPriorities", "majorRisks", "keyOpportunities", "actionPlan90Days", "scenarioNote"],
  additionalProperties: false,
};

// ─── Internal Agent Data Contracts ────────────────────────────────────────────

interface NewsItem {
  headline: string;
  date: string;
  source: string;
  url: string;
  significance: string;
}

interface CompetitorData {
  name: string;
  positioning: string;
  pricingModel: string;
  marketShareEstimate: string;
  techStackIndicators: string;
  hiringTrends: string;
  comparison: string;
}

interface Agent1Pack {
  companyProfile: { name: string; type: string; sector: string; businessModel: string };
  secFindings: { found: boolean; latestFiling: string; url: string; highlights: string[] };
  newsItems: NewsItem[];
  sentimentSignals: { overall: string; employeeNote: string; customerNote: string; sources: string[] };
  competitors: CompetitorData[];
  keyRegulatoryIssues: string[];
  dataQuality: "sufficient" | "partial" | "insufficient";
  rawText: string;
}

interface MetricItem {
  label: string;
  value: string;
  source: string;
}

interface Agent2Pack {
  companyType: string;
  revenue: { figure: string; period: string; source: string };
  growthRate: { yoy: string; trend: string };
  margins: { gross: string; net: string; ebitda: string };
  burnAndRunway: { applicable: boolean; monthlyBurn: string; runway: string };
  stockOrFunding: { type: string; value: string; details: string };
  peerBenchmarks: Array<{ company: string; revenue: string; margin: string }>;
  metrics: MetricItem[];
  dataAvailability: "full" | "limited" | "none";
  notes: string;
  rawText: string;
}

// ─── Public Report Types ──────────────────────────────────────────────────────

export interface SwotItem {
  point: string;
  evidence: string;
  strategic_impact: string;
  confidence_score: "high" | "medium" | "low";
  citation: string;
}

export interface StrategicPriority {
  title: string;
  rationale: string;
  keyAction: string;
  citation: string;
}

export interface RiskItem {
  title: string;
  description: string;
  impact: "High" | "Medium" | "Low";
  mitigation: string;
  citation: string;
  confidence_score: "high" | "medium" | "low";
}

export interface OpportunityItem {
  title: string;
  description: string;
  advantage: string;
  timeframe: string;
  citation: string;
  confidence_score: "high" | "medium" | "low";
}

export interface ActionPhase {
  phase: string;
  focus: string;
  actions: string[];
  milestone: string;
}

export interface CompetitorProfile {
  name: string;
  pricingModel: string;
  marketShareEstimate: string;
  techStackIndicators: string;
  hiringTrends: string;
  keyMoat: string;
  keyVulnerability: string;
  vsTargetCompany: string;
}

export interface CompetitiveMatrix {
  targetMoats: string[];
  targetVulnerabilities: string[];
  benchmarkSummary: string;
  competitors: CompetitorProfile[];
}

export interface ReportSources {
  agent1: {
    secFound: boolean;
    secFiling: string;
    newsItems: Array<{ headline: string; date: string; source: string; url: string }>;
    sentimentSummary: string;
    competitors: Array<{ name: string; positioning: string }>;
    dataQuality: string;
  };
  agent2: {
    companyType: string;
    metrics: MetricItem[];
    dataAvailability: string;
    notes: string;
  };
}

export interface FullReport {
  companyName: string;
  dataQuality: "sufficient" | "partial" | "insufficient";
  dataNote: string;
  swot: {
    strengths: SwotItem[];
    weaknesses: SwotItem[];
    opportunities: SwotItem[];
    threats: SwotItem[];
  };
  executiveSummary: string;
  strategicPriorities: StrategicPriority[];
  majorRisks: RiskItem[];
  keyOpportunities: OpportunityItem[];
  actionPlan90Days: ActionPhase[];
  competitiveMatrix: CompetitiveMatrix;
  sources: ReportSources;
}

export interface RefineUpdates {
  executiveSummary: string;
  strategicPriorities: StrategicPriority[];
  majorRisks: RiskItem[];
  keyOpportunities: OpportunityItem[];
  actionPlan90Days: ActionPhase[];
  scenarioNote: string;
}

// ─── SSE Helper ───────────────────────────────────────────────────────────────

type SSEEvent =
  | { type: "agent_start"; agent: 1 | 2 | 3; label: string; role: string }
  | { type: "agent_update"; agent: 1 | 2 | 3; detail: string }
  | { type: "agent_complete"; agent: 1 | 2 | 3; summary: Record<string, string> }
  | { type: "report"; data: FullReport }
  | { type: "refine_start"; mode: string; label: string }
  | { type: "refine_update"; detail: string }
  | { type: "refine_complete"; updates: RefineUpdates }
  | { type: "error"; message: string };

function emit(res: Response, event: SSEEvent): void {
  if (!res.writableEnded) res.write(`data: ${JSON.stringify(event)}\n\n`);
}

function sseHeaders(res: Response): void {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-store, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();
}

// ─── JSON Extraction Helper ───────────────────────────────────────────────────

function extractJson(text: string): any {
  try { return JSON.parse(text.trim()); } catch {}
  const fenced = text.match(/```(?:json)?\s*([\s\S]+?)\s*```/);
  if (fenced) { try { return JSON.parse(fenced[1]); } catch {} }
  const s = text.indexOf("{"), e = text.lastIndexOf("}");
  if (s !== -1 && e > s) { try { return JSON.parse(text.slice(s, e + 1)); } catch {} }
  return null;
}

// ─── Agent 1: Data Aggregator & Grounding ─────────────────────────────────────

async function runAgent1(
  client: OpenAI,
  companyName: string,
  additionalContext: string,
  res: Response
): Promise<Agent1Pack> {
  emit(res, { type: "agent_update", agent: 1, detail: "Searching SEC EDGAR for 10-K / 10-Q filings..." });

  const ctx = additionalContext ? `\n\nUser context: ${additionalContext}` : "";

  const fallback: Agent1Pack = {
    companyProfile: { name: companyName, type: "unknown", sector: "unknown", businessModel: "" },
    secFindings: { found: false, latestFiling: "Not found", url: "", highlights: [] },
    newsItems: [],
    sentimentSignals: { overall: "unknown", employeeNote: "Not available", customerNote: "Not available", sources: [] },
    competitors: [],
    keyRegulatoryIssues: [],
    dataQuality: "insufficient",
    rawText: "",
  };

  try {
    const response = await (client as any).responses.create({
      model: "gpt-4o",
      tools: [{ type: "web_search_preview" }],
      tool_choice: "required",
      input: `You are a data aggregation agent. Gather structured evidence about "${companyName}". Do NOT analyse — only collect facts.${ctx}

Execute these searches in order:
1. "${companyName} SEC 10-K annual report 10-Q quarterly filing 2024 2025 investor relations"
2. "${companyName} news acquisitions product launch partnership layoffs expansion 2024 2025"
3. "${companyName} Glassdoor employee reviews OR Reddit sentiment community 2024 2025"
4. "${companyName} main competitors market share competitive landscape 2024 2025"
5. Top competitor pricing models and tech stack: "${companyName} vs [competitor 1] [competitor 2] pricing model subscription pricing 2024"
6. Competitor hiring signals: "[competitor names from search 4] engineering hiring trends job postings 2024 2025"

Return ONLY valid JSON — no prose before or after:

{
  "companyProfile": {
    "name": "${companyName}",
    "type": "public OR private OR startup",
    "sector": "sector name",
    "businessModel": "1-2 sentences on how they make money"
  },
  "secFindings": {
    "found": true or false,
    "latestFiling": "e.g. 10-K FY2024 filed Feb 2025 OR Not found",
    "url": "direct URL to filing or investor relations page, or empty string if not found",
    "highlights": ["key highlight 1", "key highlight 2", "key highlight 3"]
  },
  "newsItems": [
    {
      "headline": "exact news headline",
      "date": "Month YYYY",
      "source": "publication name",
      "url": "article URL if available, otherwise empty string",
      "significance": "1 sentence on strategic relevance"
    }
  ],
  "sentimentSignals": {
    "overall": "positive OR neutral OR negative OR mixed",
    "employeeNote": "1-2 sentences from Glassdoor/employee sources. Cite source.",
    "customerNote": "1-2 sentences from Reddit/customer sources. Cite source.",
    "sources": ["Glassdoor", "Reddit r/..."]
  },
  "competitors": [
    {
      "name": "competitor name",
      "positioning": "their 1-sentence market position",
      "pricingModel": "their pricing model e.g. freemium, per-seat, usage-based, enterprise contract",
      "marketShareEstimate": "estimated market share percentage or relative position (e.g. #2 by revenue)",
      "techStackIndicators": "known tech stack or engineering signals from job postings or public info",
      "hiringTrends": "hiring up/down/flat, focus areas (e.g. 'expanding AI team, reducing sales headcount')",
      "comparison": "1 sentence on how they compare to ${companyName}"
    }
  ],
  "keyRegulatoryIssues": ["specific regulatory issue 1 if found", "issue 2 if found"],
  "dataQuality": "sufficient OR partial OR insufficient"
}

CRITICAL: Minimum 4 newsItems if any exist. Include 2-3 competitors with full competitive data. Never fabricate — write "Not found" for missing fields. Always include source URLs when available.`,
    });

    const rawText: string =
      typeof response.output_text === "string"
        ? response.output_text
        : JSON.stringify(response.output ?? response);

    emit(res, { type: "agent_update", agent: 1, detail: "Cataloguing competitor pricing, tech stack, and hiring data..." });

    const parsed = extractJson(rawText);
    if (!parsed) return { ...fallback, rawText, dataQuality: "partial" };

    return {
      companyProfile: parsed.companyProfile ?? fallback.companyProfile,
      secFindings: { ...fallback.secFindings, ...parsed.secFindings },
      newsItems: Array.isArray(parsed.newsItems) ? parsed.newsItems : [],
      sentimentSignals: parsed.sentimentSignals ?? fallback.sentimentSignals,
      competitors: Array.isArray(parsed.competitors) ? parsed.competitors : [],
      keyRegulatoryIssues: Array.isArray(parsed.keyRegulatoryIssues) ? parsed.keyRegulatoryIssues : [],
      dataQuality: parsed.dataQuality ?? "partial",
      rawText,
    };
  } catch (err) {
    console.error("Agent 1 error:", err);
    return fallback;
  }
}

// ─── Agent 2: Quantitative Financial Analyst ──────────────────────────────────

async function runAgent2(
  client: OpenAI,
  companyName: string,
  additionalContext: string,
  res: Response
): Promise<Agent2Pack> {
  emit(res, { type: "agent_update", agent: 2, detail: "Pulling revenue, growth rates, and margin data..." });

  const ctx = additionalContext ? `\n\nUser context: ${additionalContext}` : "";

  const fallback: Agent2Pack = {
    companyType: "unknown",
    revenue: { figure: "Not available", period: "", source: "" },
    growthRate: { yoy: "Not available", trend: "unknown" },
    margins: { gross: "Not available", net: "Not available", ebitda: "Not available" },
    burnAndRunway: { applicable: false, monthlyBurn: "N/A", runway: "N/A" },
    stockOrFunding: { type: "unknown", value: "Not available", details: "" },
    peerBenchmarks: [],
    metrics: [],
    dataAvailability: "none",
    notes: "Financial data unavailable.",
    rawText: "",
  };

  try {
    const response = await (client as any).responses.create({
      model: "gpt-4o",
      tools: [{ type: "web_search_preview" }],
      tool_choice: "required",
      input: `You are a quantitative financial analyst. Extract hard financial metrics for "${companyName}". Never estimate — only report what you find.${ctx}

Execute these searches:
1. "${companyName} annual revenue fiscal year 2023 2024 earnings financial results"
2. "${companyName} revenue growth rate YoY gross margin net margin EBITDA profitability 2024"
3. "${companyName} stock price market cap OR funding round valuation series 2024 2025"
4. "${companyName} burn rate cash runway 2024"
5. "${companyName} vs competitors revenue financial comparison market share 2024"

Return ONLY valid JSON:

{
  "companyType": "public OR private OR startup",
  "revenue": { "figure": "e.g. $5.8B (FY2024) OR Not publicly available", "period": "FY2024", "source": "Company 10-K" },
  "growthRate": { "yoy": "e.g. +34% YoY OR Not available", "trend": "accelerating OR decelerating OR stable OR unknown" },
  "margins": { "gross": "e.g. 71% OR Not available", "net": "e.g. 15% OR Not available", "ebitda": "e.g. 22% OR Not available" },
  "burnAndRunway": { "applicable": true or false, "monthlyBurn": "e.g. $8M/month OR N/A", "runway": "e.g. ~24 months OR N/A" },
  "stockOrFunding": { "type": "stock OR funding OR private", "value": "e.g. $247/share OR Series D $4.2B valuation", "details": "e.g. +28% YTD OR led by a16z Jan 2024" },
  "peerBenchmarks": [{ "company": "name", "revenue": "figure", "margin": "gross or net margin" }],
  "metrics": [{ "label": "metric name", "value": "value with units", "source": "source name" }],
  "dataAvailability": "full OR limited OR none",
  "notes": "Caveats on data reliability or gaps."
}`,
    });

    const rawText: string =
      typeof response.output_text === "string"
        ? response.output_text
        : JSON.stringify(response.output ?? response);

    emit(res, { type: "agent_update", agent: 2, detail: "Benchmarking against peer companies..." });

    const parsed = extractJson(rawText);
    if (!parsed) return { ...fallback, rawText, dataAvailability: "limited" };

    // Synthesize metrics array
    const metrics: MetricItem[] = Array.isArray(parsed.metrics) && parsed.metrics.length > 0
      ? parsed.metrics
      : [
          { label: "Revenue", value: parsed.revenue?.figure, source: parsed.revenue?.source ?? "" },
          { label: "YoY Growth", value: parsed.growthRate?.yoy, source: "Agent 2" },
          { label: "Gross Margin", value: parsed.margins?.gross, source: "Agent 2" },
          { label: "Net Margin", value: parsed.margins?.net, source: "Agent 2" },
          { label: "EBITDA Margin", value: parsed.margins?.ebitda, source: "Agent 2" },
          { label: "Stock / Funding", value: parsed.stockOrFunding?.value, source: "Agent 2" },
          parsed.burnAndRunway?.applicable ? { label: "Monthly Burn", value: parsed.burnAndRunway.monthlyBurn, source: "Agent 2" } : null,
          parsed.burnAndRunway?.applicable ? { label: "Runway", value: parsed.burnAndRunway.runway, source: "Agent 2" } : null,
        ].filter((m): m is MetricItem => !!m?.value && m.value !== "Not available" && m.value !== "N/A");

    return {
      companyType: parsed.companyType ?? "unknown",
      revenue: parsed.revenue ?? fallback.revenue,
      growthRate: parsed.growthRate ?? fallback.growthRate,
      margins: parsed.margins ?? fallback.margins,
      burnAndRunway: parsed.burnAndRunway ?? fallback.burnAndRunway,
      stockOrFunding: parsed.stockOrFunding ?? fallback.stockOrFunding,
      peerBenchmarks: Array.isArray(parsed.peerBenchmarks) ? parsed.peerBenchmarks : [],
      metrics,
      dataAvailability: parsed.dataAvailability ?? "limited",
      notes: parsed.notes ?? "",
      rawText,
    };
  } catch (err) {
    console.error("Agent 2 error:", err);
    return fallback;
  }
}

// ─── Agent 3: Senior Consultant Synthesis (Structured Output) ─────────────────

function buildContextBlock(companyName: string, a1: Agent1Pack, a2: Agent2Pack): string {
  return `=== AGENT 1: DATA AGGREGATOR ===
Company: ${a1.companyProfile.name} | Type: ${a1.companyProfile.type} | Sector: ${a1.companyProfile.sector}
Business Model: ${a1.companyProfile.businessModel}

SEC Filing: ${a1.secFindings.found ? `${a1.secFindings.latestFiling}${a1.secFindings.url ? ` (${a1.secFindings.url})` : ""}` : "Not found"}
${a1.secFindings.highlights.length ? `Highlights:\n${a1.secFindings.highlights.map((h) => `  - ${h}`).join("\n")}` : ""}

News (${a1.newsItems.length} items):
${a1.newsItems.map((n) => `  - [${n.date}] "${n.headline}" — ${n.source}${n.url ? ` ${n.url}` : ""} — ${n.significance}`).join("\n") || "  None"}

Sentiment: ${a1.sentimentSignals.overall}
  Employee: ${a1.sentimentSignals.employeeNote}
  Customer: ${a1.sentimentSignals.customerNote}
  Sources: ${a1.sentimentSignals.sources.join(", ")}

Competitors:
${a1.competitors.map((c) => `  - ${c.name}: ${c.positioning}
      Pricing: ${c.pricingModel} | Market share: ${c.marketShareEstimate}
      Tech: ${c.techStackIndicators} | Hiring: ${c.hiringTrends}
      vs ${companyName}: ${c.comparison}`).join("\n") || "  None found"}

Regulatory issues: ${a1.keyRegulatoryIssues.join("; ") || "None"}
Data quality (Agent 1): ${a1.dataQuality}

=== AGENT 2: QUANT ANALYST ===
Revenue: ${a2.revenue.figure} (${a2.revenue.period}) — ${a2.revenue.source}
YoY Growth: ${a2.growthRate.yoy} (${a2.growthRate.trend})
Gross Margin: ${a2.margins.gross} | Net: ${a2.margins.net} | EBITDA: ${a2.margins.ebitda}
${a2.burnAndRunway.applicable ? `Burn: ${a2.burnAndRunway.monthlyBurn} | Runway: ${a2.burnAndRunway.runway}` : ""}
Stock/Funding: ${a2.stockOrFunding.value} — ${a2.stockOrFunding.details}
Peers: ${a2.peerBenchmarks.map((p) => `${p.company} (rev: ${p.revenue}, margin: ${p.margin})`).join("; ") || "None"}
Financial data availability: ${a2.dataAvailability}
Notes: ${a2.notes}`.trim();
}

async function runAgent3(
  client: OpenAI,
  companyName: string,
  a1: Agent1Pack,
  a2: Agent2Pack,
  res: Response
): Promise<FullReport> {
  emit(res, { type: "agent_update", agent: 3, detail: "Synthesising evidence with grounding validation..." });

  const contextBlock = buildContextBlock(companyName, a1, a2);

  const systemPrompt = `You are a Senior Strategy Consultant with 20+ years advising boards and C-suites. You are the SYNTHESIS layer in a three-agent intelligence pipeline. You have received structured data from two agents: a Data Aggregator (Agent 1) and a Quant Analyst (Agent 2).

GROUNDING RULES — these are non-negotiable:
1. Every SWOT item, risk, and opportunity MUST be grounded in specific evidence from the corpus.
2. confidence_score assignment:
   - "high": direct numeric evidence or a named event in the corpus (e.g. "Agent 2: gross margin 71%", "Agent 1 Reuters Nov 2024: acquired XYZ")
   - "medium": plausible inference from corpus data but not directly evidenced
   - "low": minimal corpus support — primarily based on general industry knowledge. YOU MUST still include these but they will be flagged to the user for review.
3. citation must reference the actual source: "Agent 2: [source]" or "Agent 1: [Publication, Date]" or "SEC 10-K FY2024" or "Agent inference (low confidence)" for low-confidence items. Never fabricate a citation.
4. evidence field must contain the specific data that supports the point — quote figures, name events, cite publications. If you can't quote specific evidence, set confidence_score to "low".
5. For the competitive matrix, use ONLY what Agent 1 found. If a competitor field was "Not found", reflect that honestly.
6. ZERO generic phrases: "intensifying competition", "supply chain risk", "growing demand", "cost optimization", "regulatory changes", "talent retention". Rewrite with specifics.

BUSINESS SCORE PERSONA — when computing businessScore, adopt the mindset of a veteran venture capitalist and private equity analyst evaluating a potential investment:
- Be candid and rigorous. Do NOT inflate scores out of politeness.
- Scores in the 85-100 range are RESERVED for exceptional companies (Apple, Microsoft tier) with deep, multi-dimensional moats, top-tier financials, and low systematic risk. Most companies score 50-75.
- If a specific financial or operational metric is missing from the corpus, DOCK POINTS in that category for uncertainty and state why in the subCriterion finding.
- Score only what the evidence supports. Optimistic inference is not evidence.`;

  const userPrompt = `Produce the full strategic intelligence report on "${companyName}" using the verified data below.

${contextBlock}

CITATION FORMAT GUIDE:
- SEC filing: "10-K FY[year], SEC EDGAR"  
- News item: "[Publication], [Month Year]"
- Financial metric: "Agent 2: [Source], [Period]"
- Competitor data: "Agent 1: Competitive research"
- Sentiment: "Agent 1: [Platform, Year]"
- Insufficient data: "Agent inference (low confidence)"

For the competitive matrix:
- targetMoats: 2-3 specific structural advantages ${companyName} has over ALL competitors listed
- targetVulnerabilities: 2-3 specific structural weaknesses vs competitors
- benchmarkSummary: 2-3 sentences comparing ${companyName}'s financial and market position to the peer set
- competitors: use the competitor data from Agent 1. If pricing/tech/hiring data was "Not found", write that honestly.

Rules: 4 SWOT items per quadrant, 3 strategic priorities, 3-5 risks, 3-5 opportunities, exactly 3 action phases.

BUSINESS SCORE — produce the businessScore object using the schema exactly. Score each category 0-20 based strictly on corpus evidence.

CATEGORY DEFINITIONS AND SUB-CRITERIA:

1. categoryName: "Market Attractiveness" (0-20)
   Sub-criteria to evaluate (provide label + one-sentence finding for each):
   - "TAM": Size of total addressable market; is it large, growing, or saturating?
   - "Industry Growth Rate": CAGR or directional growth signal from corpus data.
   - "Market Trends": Macro/category tailwinds or headwinds shaping demand.
   Anchors: 0-7 = niche/shrinking/commoditised; 8-13 = moderate or contested growth; 14-20 = large TAM, strong growth, clear demand pull.

2. categoryName: "Competitive Moat" (0-20)
   Sub-criteria to evaluate:
   - "Pricing Power": Ability to raise prices without losing customers; premium vs. race-to-bottom signals.
   - "IP & Proprietary Tech": Patents, trade secrets, or proprietary data advantages.
   - "Switching Costs & Brand": How sticky the product is and how strong brand recognition is.
   Anchors: 0-7 = easily replicated, commodity pricing; 8-13 = moderate moat; 14-20 = durable structural advantages across multiple dimensions.

3. categoryName: "Execution Capability" (0-20)
   Sub-criteria to evaluate:
   - "Leadership Efficiency": Track record of the leadership team; founder-market fit; management quality signals.
   - "Organizational Agility": Speed of iteration, product velocity, ability to pivot (hiring patterns, product launches).
   - "Supply Chain Strength": Reliability and resilience of operations, partnerships, or delivery infrastructure.
   Anchors: 0-7 = weak execution or leadership risk; 8-13 = adequate execution; 14-20 = proven team, fast iteration, resilient operations.

4. categoryName: "Financial Health" (0-20)
   Sub-criteria to evaluate:
   - "Margin Profitability": Gross and operating margins; trajectory (expanding vs. compressing).
   - "Capital Intensity": Asset-heavy vs. asset-light model; CapEx burden relative to revenue.
   - "Revenue Diversity": Mix across products, geographies, or customer segments; reliance on single revenue stream.
   Anchors: 0-7 = cash-constrained, compressing margins, concentrated revenue; 8-13 = adequate; 14-20 = healthy margins, capital-efficient, diversified.

5. categoryName: "Risk & Vulnerability" (0-20) — HIGHER SCORE = LOWER RISK (inverse scale)
   Sub-criteria to evaluate:
   - "Regulatory Exposure": Active litigation, pending regulation, or compliance burden.
   - "Customer Churn": Evidence of churn, NPS signals, retention risk, or contract tenure.
   - "Customer Concentration": Revenue dependence on top customers or geographies.
   Anchors: 0-7 = severe risks (heavy regulation, high churn, concentrated revenue); 8-13 = moderate; 14-20 = well-diversified, low regulatory exposure, strong retention.

SCORING RULES:
- overallScore = exact integer sum of all five category scores (max 100).
- healthGrade mapping (strict — no grade inflation):
    A+ = 93-100  (Exceptional — market leaders with deep multi-dimensional moats)
    A  = 85-92   (Strong — clear category leaders with minor vulnerabilities)
    B+ = 78-84   (Above average — solid business with one notable gap)
    B  = 70-77   (Solid — competitive but with meaningful headwinds)
    C+ = 62-69   (Average+ — moderate resilience, execution risk evident)
    C  = 50-61   (Average — significant financial or competitive vulnerabilities)
    D  = 35-49   (Below average — distressed signals, high execution risk)
    F  = 0-34    (At risk — severe operational or financial threats)
- rating per category (strict):
    Excellent = 16-20 (green — outperforming)
    Strong    = 16-20 (green — solid performer; use Excellent for 18-20, Strong for 16-17)
    Moderate  = 11-15 (yellow — watch list, needs monitoring)
    Weak      = 6-10  (red — priority area, immediate attention required)
    Critical  = 0-5   (red — high risk, existential concern)
- executiveSummary = exactly 2 sentences: first sentence states the overall grade and primary strength; second states the single biggest risk or gap.
- quickWins = exactly 3 strings. Write one per the 3 lowest-scoring categories, in ascending score order (lowest first). Each string must be a single concrete action sentence: start with a verb, name a specific target/metric, and state a measurable outcome (e.g. "Negotiate multi-year supply contracts with 3 tier-1 vendors to reduce single-source dependency below 30% within 6 months.").
- Each subCriterion finding must cite a specific figure, event, or data point from the corpus — no generic statements. If data is unavailable, write: "No public data found — scoring conservatively."`;

  // Try structured output with json_schema; fallback to json_object
  let raw: string | null = null;
  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-2024-08-06",
      temperature: 0.3,
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "strategic_intelligence_report",
          strict: true,
          schema: REPORT_SCHEMA,
        },
      } as any,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
    });
    raw = response.choices[0]?.message?.content ?? null;
  } catch (schemaErr) {
    console.warn("json_schema mode failed, falling back to json_object:", (schemaErr as any)?.message);
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      temperature: 0.3,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt + "\n\nReturn ONLY valid JSON matching the schema. Include all required fields including competitiveMatrix." },
      ],
    });
    raw = response.choices[0]?.message?.content ?? null;
  }

  if (!raw) throw new Error("Agent 3 returned empty response");

  let parsed: any;
  try { parsed = JSON.parse(raw); }
  catch { parsed = extractJson(raw); }
  if (!parsed) throw new Error("Agent 3 response could not be parsed");

  const overallQuality: "sufficient" | "partial" | "insufficient" =
    a1.dataQuality === "sufficient" && a2.dataAvailability === "full" ? "sufficient"
    : a1.dataQuality === "insufficient" && a2.dataAvailability === "none" ? "insufficient"
    : "partial";

  const sources: FullReport["sources"] = {
    agent1: {
      secFound: a1.secFindings.found,
      secFiling: a1.secFindings.latestFiling,
      newsItems: a1.newsItems.map((n) => ({ headline: n.headline, date: n.date, source: n.source, url: n.url || "" })),
      sentimentSummary: `${a1.sentimentSignals.overall} overall — ${a1.sentimentSignals.employeeNote}`.trim(),
      competitors: a1.competitors.map((c) => ({ name: c.name, positioning: c.positioning })),
      dataQuality: a1.dataQuality,
    },
    agent2: {
      companyType: a2.companyType,
      metrics: a2.metrics,
      dataAvailability: a2.dataAvailability,
      notes: a2.notes,
    },
  };

  // Ensure competitive matrix has required fields
  const cm = parsed.competitiveMatrix ?? {};
  const competitiveMatrix: FullReport["competitiveMatrix"] = {
    targetMoats: cm.targetMoats ?? [],
    targetVulnerabilities: cm.targetVulnerabilities ?? [],
    benchmarkSummary: cm.benchmarkSummary ?? "",
    competitors: Array.isArray(cm.competitors) ? cm.competitors : [],
  };

  return {
    companyName,
    dataQuality: parsed.dataQuality ?? overallQuality,
    dataNote: parsed.dataNote ?? "",
    swot: {
      strengths: parsed.swot?.strengths ?? [],
      weaknesses: parsed.swot?.weaknesses ?? [],
      opportunities: parsed.swot?.opportunities ?? [],
      threats: parsed.swot?.threats ?? [],
    },
    executiveSummary: parsed.executiveSummary ?? "",
    strategicPriorities: parsed.strategicPriorities ?? [],
    majorRisks: parsed.majorRisks ?? [],
    keyOpportunities: parsed.keyOpportunities ?? [],
    actionPlan90Days: parsed.actionPlan90Days ?? [],
    competitiveMatrix,
    sources,
  };
}

// ─── Refine: Scenario Simulation + Post-Edit Synthesis ────────────────────────

async function runRefine(
  client: OpenAI,
  report: FullReport,
  editedSwot: FullReport["swot"] | null,
  scenario: string | null,
  res: Response
): Promise<RefineUpdates> {
  emit(res, { type: "refine_update", detail: "Rebuilding strategic framework with new inputs..." });

  const activeSwot = editedSwot ?? report.swot;

  const swotBlock = [
    "STRENGTHS:\n" + activeSwot.strengths.map((s) => `  - ${s.point} | Evidence: ${s.evidence} | Citation: ${s.citation}`).join("\n"),
    "WEAKNESSES:\n" + activeSwot.weaknesses.map((s) => `  - ${s.point} | Evidence: ${s.evidence} | Citation: ${s.citation}`).join("\n"),
    "OPPORTUNITIES:\n" + activeSwot.opportunities.map((s) => `  - ${s.point} | Evidence: ${s.evidence} | Citation: ${s.citation}`).join("\n"),
    "THREATS:\n" + activeSwot.threats.map((s) => `  - ${s.point} | Evidence: ${s.evidence} | Citation: ${s.citation}`).join("\n"),
  ].join("\n\n");

  const metricsBlock = report.sources.agent2.metrics.length > 0
    ? "Financial metrics: " + report.sources.agent2.metrics.map((m) => `${m.label}: ${m.value} (${m.source})`).join("; ")
    : "Financial metrics: limited/unavailable";

  const scenarioBlock = scenario
    ? `\n\nACTIVE SCENARIO FOR SIMULATION:\n"${scenario}"\nAdjust the 90-day action plan, strategic priorities, and risks/opportunities to reflect this scenario. Make changes specific and concrete — not just add the scenario as a caveat.`
    : "";

  const editNote = editedSwot ? "\n\nNote: The SWOT has been EDITED by the user. Regenerate the executive summary, priorities, risks, opportunities, and 90-day plan based on the updated SWOT above." : "";

  emit(res, { type: "refine_update", detail: scenario ? `Simulating: "${scenario.slice(0, 60)}..."` : "Regenerating from edited SWOT..." });

  let raw: string | null = null;
  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-2024-08-06",
      temperature: 0.35,
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "refined_report_sections",
          strict: true,
          schema: REFINE_SCHEMA,
        },
      } as any,
      messages: [
        {
          role: "system",
          content: `You are a Senior Strategy Consultant regenerating specific sections of a strategic report for "${report.companyName}". Work from the provided SWOT and financial context. Be specific, evidence-driven, and concrete.`,
        },
        {
          role: "user",
          content: `Company: ${report.companyName}
${metricsBlock}

CURRENT SWOT (after any user edits):
${swotBlock}
${scenarioBlock}${editNote}

Regenerate: executiveSummary, strategicPriorities (3), majorRisks (3-5), keyOpportunities (3-5), actionPlan90Days (exactly 3 phases).
For scenarioNote: ${scenario ? `Write 1-2 sentences explaining how the scenario "${scenario}" specifically affects this company's strategic position and why the plan changed.` : "Write 'Executive report regenerated from updated SWOT analysis.'"}
Maintain citation fields throughout. Confidence scores must follow the same grounding rules as the original report.`,
        },
      ],
    });
    raw = response.choices[0]?.message?.content ?? null;
  } catch {
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      temperature: 0.35,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: `You are a Senior Strategy Consultant regenerating specific sections of a strategic report for "${report.companyName}". Return ONLY valid JSON.`,
        },
        {
          role: "user",
          content: `Company: ${report.companyName}
${metricsBlock}

CURRENT SWOT:
${swotBlock}
${scenarioBlock}${editNote}

Return JSON with keys: executiveSummary, strategicPriorities, majorRisks, keyOpportunities, actionPlan90Days, scenarioNote. Follow the same schema as the original report (citation and confidence_score on all items).`,
        },
      ],
    });
    raw = response.choices[0]?.message?.content ?? null;
  }

  if (!raw) throw new Error("Refine agent returned empty response");
  let parsed: any;
  try { parsed = JSON.parse(raw); } catch { parsed = extractJson(raw); }
  if (!parsed) throw new Error("Refine response could not be parsed");

  return {
    executiveSummary: parsed.executiveSummary ?? report.executiveSummary,
    strategicPriorities: parsed.strategicPriorities ?? report.strategicPriorities,
    majorRisks: parsed.majorRisks ?? report.majorRisks,
    keyOpportunities: parsed.keyOpportunities ?? report.keyOpportunities,
    actionPlan90Days: parsed.actionPlan90Days ?? report.actionPlan90Days,
    scenarioNote: parsed.scenarioNote ?? "",
  };
}

// ─── POST /v3/generate-landing-page  (also aliased at /swot/generate-landing-page) ───

async function handleGenerateLandingPage(req: Request, res: Response): Promise<void> {
  const {
    companyName, executiveSummary, strategicPriorities,
    quickWins, businessScore, competitiveMatrix, keyOpportunities, style,
  } = req.body as {
    companyName: string;
    style?: string;
    executiveSummary: string;
    strategicPriorities: Array<{ title: string; rationale: string; keyAction: string }>;
    quickWins: string[];
    businessScore: { overallScore: number; healthGrade: string; categories: Array<{ categoryName: string; score: number; rating: string }> };
    competitiveMatrix: { targetMoats: string[]; benchmarkSummary: string };
    keyOpportunities: Array<{ title: string; description: string }>;
  };

  if (!companyName?.trim()) {
    res.status(400).json({ error: "companyName is required" });
    return;
  }

  const SHARED_RULES = `1. LAYOUT & GRID SYSTEM (NEVER STACK CARDS VERTICALLY):
   - All feature/strategic pillar sections MUST use a multi-column CSS grid: <div class="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto px-4">.
   - Never generate full-width stacked text cards for features.

5. OUTPUT DIRECTIVE:
   - Return standard, production-ready HTML ONLY — COMPLETE from <!DOCTYPE html> to </html>. Do NOT stop after the Hero section.
   - Include Tailwind script: <script src="https://cdn.tailwindcss.com"></script>.
   - Do NOT wrap in markdown block text.`;

  const STYLE_PROMPTS: Record<string, string> = {
    "dark-glass": `You are a Lead Designer at Framer / Vercel.
Transform the strategic business context into an AWARD-WINNING, ultra-modern SaaS landing page.

CRITICAL DESIGN REQUIREMENTS (10/10 POLISH):

${SHARED_RULES.split("\n\n")[0]}

2. GLASSMORPHISM & DEPTH:
   - Page Background: Pitch dark radial glow (\`bg-slate-950 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(120,119,198,0.2),rgba(255,255,255,0))]\`).
   - Cards: \`bg-slate-900/80 border border-slate-800 rounded-2xl p-6 backdrop-blur-md shadow-xl hover:-translate-y-1 hover:border-cyan-500/50 hover:shadow-cyan-500/10 transition-all duration-300\`.

3. TYPOGRAPHY & CONTRAST:
   - Section Eyebrow (Badge): <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 mb-4">Strategic Pillar</span>
   - Card Titles: <h3 class="text-xl font-bold text-white mb-2">
   - Body Text: <p class="text-slate-400 text-sm leading-relaxed">

4. ACCENT ICONS:
   - Enclose icons inside glowing containers: <div class="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center mb-4 text-cyan-400"> [SVG/Emoji] </div>.

${SHARED_RULES.split("\n\n")[1]}`,

    "light-minimal": `You are a Lead Designer at Linear / Stripe.
Transform the strategic business context into a PRISTINE, light, minimal SaaS landing page — generous whitespace, restrained color, editorial typography.

CRITICAL DESIGN REQUIREMENTS (10/10 POLISH):

${SHARED_RULES.split("\n\n")[0]}

2. LIGHT MINIMAL AESTHETIC:
   - Page Background: clean white (\`bg-white\`) with subtle warm-gray sections (\`bg-gray-50\`) to separate content bands. NO dark backgrounds anywhere.
   - Cards: \`bg-white border border-gray-200 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-gray-300 transition-all duration-300\`.
   - One single accent color only (indigo-600) used sparingly for CTAs and links.

3. TYPOGRAPHY & CONTRAST:
   - Section Eyebrow (Badge): <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-indigo-50 text-indigo-600 border border-indigo-100 mb-4">Strategic Pillar</span>
   - Headlines: near-black (\`text-gray-900\`), tight tracking (\`tracking-tight\`), large but not shouty.
   - Card Titles: <h3 class="text-xl font-semibold text-gray-900 mb-2">
   - Body Text: <p class="text-gray-500 text-sm leading-relaxed">

4. ACCENT ICONS:
   - Simple monochrome containers: <div class="w-10 h-10 rounded-xl bg-gray-100 flex items-center justify-center mb-4 text-indigo-600"> [SVG/Emoji] </div>.
   - No glows, no gradients, no heavy shadows.

${SHARED_RULES.split("\n\n")[1]}`,

    "bold-gradient": `You are a Lead Designer at Vercel / Superhuman working on a bold, high-energy brand.
Transform the strategic business context into a VIBRANT, gradient-drenched SaaS landing page that feels loud, confident, and modern.

CRITICAL DESIGN REQUIREMENTS (10/10 POLISH):

${SHARED_RULES.split("\n\n")[0]}

2. BOLD GRADIENTS & ENERGY:
   - Page Background: deep base (\`bg-gray-950\`) with vivid multi-stop gradient hero: \`bg-gradient-to-br from-fuchsia-600 via-purple-600 to-indigo-700\`.
   - Cards: \`bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur hover:-translate-y-1 hover:border-fuchsia-400/50 transition-all duration-300\`.
   - CTAs: large pill buttons with gradient fill \`bg-gradient-to-r from-fuchsia-500 to-indigo-500 hover:from-fuchsia-400 hover:to-indigo-400 shadow-lg shadow-fuchsia-500/30\`.

3. TYPOGRAPHY & CONTRAST:
   - Hero headline uses gradient text: <h1 class="text-5xl md:text-7xl font-extrabold bg-gradient-to-r from-fuchsia-400 via-purple-300 to-indigo-300 bg-clip-text text-transparent">
   - Section Eyebrow (Badge): <span class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-fuchsia-500/10 text-fuchsia-300 border border-fuchsia-500/20 mb-4">Strategic Pillar</span>
   - Card Titles: <h3 class="text-xl font-bold text-white mb-2">
   - Body Text: <p class="text-gray-300 text-sm leading-relaxed">

4. ACCENT ICONS:
   - Gradient icon containers: <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-fuchsia-500/20 to-indigo-500/20 border border-fuchsia-400/20 flex items-center justify-center mb-4 text-fuchsia-300"> [SVG/Emoji] </div>.

${SHARED_RULES.split("\n\n")[1]}`,
  };

  const styleKey = typeof style === "string" && STYLE_PROMPTS[style] ? style : "dark-glass";
  const systemPrompt = STYLE_PROMPTS[styleKey];

  const pillarsText = (strategicPriorities ?? []).slice(0, 3)
    .map((p, i) => `${i + 1}. ${p.title}: ${p.rationale} → Action: ${p.keyAction}`)
    .join("\n");

  const moatsText = (competitiveMatrix?.targetMoats ?? []).join(", ") || "Not specified";
  const opportunitiesText = (keyOpportunities ?? []).slice(0, 2)
    .map(o => `• ${o.title}: ${o.description}`).join("\n");
  const quickWinsText = (quickWins ?? []).slice(0, 3).join("\n• ");
  const bsText = businessScore
    ? `Overall Score: ${businessScore.overallScore}/100 (${businessScore.healthGrade}) — ${businessScore.categories.map(c => `${c.categoryName} ${c.score}/20`).join(", ")}`
    : "Not available";

  const userContent = `Company Name: ${companyName}
Value Proposition: ${executiveSummary ?? ""}
Strategic Pillars: ${pillarsText}
Checkout/Action URL: #get-started

Generate a sleek, modern, single-page website where all CTAs are fully clickable and functional.`;

  try {
    const client = getClient();
    const response = await client.chat.completions.create({
      model: "gpt-4o",
      temperature: 0.7,
      max_tokens: 3000,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userContent },
      ],
    });

    let html = response.choices[0]?.message?.content?.trim() ?? "";
    // Strip any accidental markdown fences
    html = html.replace(/^```(?:html)?\s*/i, "").replace(/\s*```\s*$/i, "").trim();

    if (!html.toLowerCase().startsWith("<!doctype")) {
      const idx = html.toLowerCase().indexOf("<!doctype");
      html = idx !== -1 ? html.slice(idx) : html;
    }

    res.json({ status: "success", html });
  } catch (err: any) {
    console.error("Landing page generation error:", err?.message);
    res.status(500).json({ error: err?.message ?? "Generation failed" });
  }
}

// Register at both paths — /v3/generate-landing-page is the canonical endpoint
router.post("/v3/generate-landing-page", handleGenerateLandingPage);
router.post("/swot/generate-landing-page", handleGenerateLandingPage);

// ─── POST /swot/generate — Main Pipeline (SSE) ───────────────────────────────

router.post("/swot/generate", async (req: Request, res: Response): Promise<void> => {
  const { companyName, additionalContext } = req.body as { companyName?: string; additionalContext?: string };

  if (!companyName?.trim()) {
    res.status(400).json({ error: "companyName is required" });
    return;
  }

  req.socket.setTimeout(0);
  req.socket.setNoDelay(true);
  req.socket.setKeepAlive(true);
  sseHeaders(res);

  const name = companyName.trim();
  const context = (additionalContext ?? "").trim();
  const heartbeat = setInterval(() => { if (!res.writableEnded) res.write(": heartbeat\n\n"); }, 20000);

  try {
    const client = getClient();

    emit(res, { type: "agent_start", agent: 1, label: "Data Aggregator & Grounding", role: "SEC filings · News · Sentiment · Competitive intelligence" });
    emit(res, { type: "agent_start", agent: 2, label: "Quantitative Financial Analyst", role: "Revenue · Margins · Growth · Stock / Funding" });

    const [a1, a2] = await Promise.all([
      runAgent1(client, name, context, res),
      runAgent2(client, name, context, res),
    ]);

    // Agent 1 complete summary
    const a1Sum: Record<string, string> = {};
    if (a1.secFindings.found) a1Sum["SEC Filing"] = a1.secFindings.latestFiling;
    if (a1.newsItems.length) a1Sum["News items"] = `${a1.newsItems.length} found`;
    if (a1.competitors.length) a1Sum["Competitors"] = a1.competitors.slice(0, 3).map((c) => c.name).join(", ");
    if (a1.sentimentSignals.overall !== "unknown") a1Sum["Sentiment"] = a1.sentimentSignals.overall;
    if (!Object.keys(a1Sum).length) a1Sum["Status"] = `Data quality: ${a1.dataQuality}`;
    emit(res, { type: "agent_complete", agent: 1, summary: a1Sum });

    // Agent 2 complete summary
    const a2Sum: Record<string, string> = {};
    if (a2.revenue.figure !== "Not available") a2Sum["Revenue"] = a2.revenue.figure;
    if (a2.growthRate.yoy !== "Not available") a2Sum["YoY Growth"] = a2.growthRate.yoy;
    if (a2.margins.gross !== "Not available") a2Sum["Gross Margin"] = a2.margins.gross;
    if (a2.stockOrFunding.value !== "Not available") a2Sum["Stock / Funding"] = a2.stockOrFunding.value.slice(0, 55);
    if (!Object.keys(a2Sum).length) a2Sum["Status"] = `Data: ${a2.dataAvailability}`;
    emit(res, { type: "agent_complete", agent: 2, summary: a2Sum });

    emit(res, { type: "agent_start", agent: 3, label: "Senior Consultant Synthesis", role: "Structured SWOT · Citations · Competitive matrix · 90-day plan" });
    const report = await runAgent3(client, name, a1, a2, res);

    emit(res, {
      type: "agent_complete", agent: 3,
      summary: {
        "Data quality": report.dataQuality,
        "SWOT items": `${Object.values(report.swot).flat().length}`,
        "Competitors": `${report.competitiveMatrix.competitors.length}`,
        "Schema": "json_schema strict",
      },
    });

    emit(res, { type: "report", data: report });
    res.end();
  } catch (err: any) {
    console.error("Pipeline error:", err);
    try { emit(res, { type: "error", message: err?.message ?? "Pipeline failed." }); } catch {}
    res.end();
  } finally {
    clearInterval(heartbeat);
  }
});

// ─── POST /swot/refine — Scenario + Post-Edit (SSE) ─────────────────────────

router.post("/swot/refine", async (req: Request, res: Response): Promise<void> => {
  const { report, editedSwot, scenario } = req.body as {
    report?: FullReport;
    editedSwot?: FullReport["swot"] | null;
    scenario?: string | null;
  };

  if (!report?.companyName) {
    res.status(400).json({ error: "report is required" });
    return;
  }

  req.socket.setTimeout(0);
  req.socket.setNoDelay(true);
  sseHeaders(res);

  const mode = editedSwot && scenario ? "both" : scenario ? "scenario" : "edit";
  const label = scenario
    ? `Simulating: "${scenario.slice(0, 50)}${scenario.length > 50 ? "..." : ""}"`
    : "Regenerating from edited SWOT";

  const heartbeat = setInterval(() => { if (!res.writableEnded) res.write(": heartbeat\n\n"); }, 20000);

  try {
    const client = getClient();
    emit(res, { type: "refine_start", mode, label });

    const updates = await runRefine(client, report, editedSwot ?? null, scenario ?? null, res);

    emit(res, { type: "refine_complete", updates });
    res.end();
  } catch (err: any) {
    console.error("Refine error:", err);
    try { emit(res, { type: "error", message: err?.message ?? "Refine failed." }); } catch {}
    res.end();
  } finally {
    clearInterval(heartbeat);
  }
});

export default router;
