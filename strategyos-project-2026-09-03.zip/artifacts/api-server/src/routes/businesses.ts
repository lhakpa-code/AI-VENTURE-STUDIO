import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import {
  db,
  businessesTable,
  assessmentsTable,
  strategiesTable,
  milestonesTable,
  strategyPillarsTable,
  kpiLogsTable,
} from "@workspace/db";
import {
  CreateBusinessBody,
  UpdateBusinessBody,
  GetBusinessParams,
  UpdateBusinessParams,
  DeleteBusinessParams,
  GetBusinessDashboardParams,
} from "@workspace/api-zod";
import { generateAssessment } from "../lib/strategyEngine";

const router: IRouter = Router();

router.get("/businesses", async (_req, res): Promise<void> => {
  const businesses = await db
    .select()
    .from(businessesTable)
    .orderBy(desc(businessesTable.createdAt));
  res.json(businesses);
});

router.post("/businesses", async (req, res): Promise<void> => {
  const parsed = CreateBusinessBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [business] = await db
    .insert(businessesTable)
    .values(parsed.data)
    .returning();

  // Auto-generate SWOT assessment immediately on business creation
  const assessmentResult = generateAssessment(business, "");
  const [assessment] = await db
    .insert(assessmentsTable)
    .values({
      businessId: business.id,
      status: "completed",
      additionalContext: "",
      identitySummary: assessmentResult.identitySummary,
      strengths: assessmentResult.strengths,
      weaknesses: assessmentResult.weaknesses,
      opportunities: assessmentResult.opportunities,
      threats: assessmentResult.threats,
      strengthScore: assessmentResult.strengthScore,
      weaknessScore: assessmentResult.weaknessScore,
      opportunityScore: assessmentResult.opportunityScore,
      threatScore: assessmentResult.threatScore,
      recommendations: assessmentResult.recommendations,
    })
    .returning();

  res.status(201).json({ ...business, autoAssessmentId: assessment.id });
});

router.get("/businesses/:id", async (req, res): Promise<void> => {
  const params = GetBusinessParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [business] = await db
    .select()
    .from(businessesTable)
    .where(eq(businessesTable.id, params.data.id));
  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  res.json(business);
});

router.patch("/businesses/:id", async (req, res): Promise<void> => {
  const params = UpdateBusinessParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateBusinessBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [business] = await db
    .update(businessesTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(businessesTable.id, params.data.id))
    .returning();
  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  res.json(business);
});

router.delete("/businesses/:id", async (req, res): Promise<void> => {
  const params = DeleteBusinessParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [deleted] = await db
    .delete(businessesTable)
    .where(eq(businessesTable.id, params.data.id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Business not found" });
    return;
  }
  res.sendStatus(204);
});

router.get("/businesses/:id/briefing", async (req, res): Promise<void> => {
  const params = GetBusinessDashboardParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const businessId = params.data.id;

  const [business] = await db.select().from(businessesTable).where(eq(businessesTable.id, businessId));
  if (!business) {
    res.status(404).json({ error: "Business not found" });
    return;
  }

  const allAssessments = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.businessId, businessId))
    .orderBy(desc(assessmentsTable.createdAt));
  const latestAssessment = allAssessments[0] ?? null;

  const allStrategies = await db
    .select()
    .from(strategiesTable)
    .where(eq(strategiesTable.businessId, businessId));

  // Gather all milestones with pillar info
  type MilestoneWithPillar = typeof milestonesTable.$inferSelect & { pillarTitle: string };
  let allMilestones: MilestoneWithPillar[] = [];

  if (allStrategies.length > 0) {
    const strategyIds = allStrategies.map((s) => s.id);
    const pillars = await db
      .select()
      .from(strategyPillarsTable)
      .where(
        strategyIds.length === 1
          ? eq(strategyPillarsTable.strategyId, strategyIds[0])
          : strategyPillarsTable.strategyId.in(strategyIds)
      );

    if (pillars.length > 0) {
      const pillarIds = pillars.map((p) => p.id);
      const rawMilestones = await db
        .select()
        .from(milestonesTable)
        .where(
          pillarIds.length === 1
            ? eq(milestonesTable.pillarId, pillarIds[0])
            : milestonesTable.pillarId.in(pillarIds)
        );
      allMilestones = rawMilestones.map((m) => ({
        ...m,
        pillarTitle: pillars.find((p) => p.id === m.pillarId)?.title ?? "General",
      }));
    }
  }

  // Milestone stats
  const totalMilestones = allMilestones.length;
  const completedMilestones = allMilestones.filter((m) => m.status === "completed").length;
  const inProgressMilestones = allMilestones.filter((m) => m.status === "in_progress").length;
  const executionRate = totalMilestones > 0 ? Math.round((completedMilestones / totalMilestones) * 100) : 0;

  // KPI log counts
  const milestonesWithKpi = allMilestones.filter((m) => m.kpi);
  let kpisWithLogs = 0;
  if (milestonesWithKpi.length > 0) {
    const kpiMilestoneIds = milestonesWithKpi.map((m) => m.id);
    const logs = await db
      .select()
      .from(kpiLogsTable)
      .where(
        kpiMilestoneIds.length === 1
          ? eq(kpiLogsTable.milestoneId, kpiMilestoneIds[0])
          : kpiLogsTable.milestoneId.in(kpiMilestoneIds)
      );
    const loggedMilestoneIds = new Set(logs.map((l) => l.milestoneId));
    kpisWithLogs = loggedMilestoneIds.size;
  }
  const kpisPendingLog = milestonesWithKpi.length - kpisWithLogs;

  // SWOT scores
  const swotAvg = latestAssessment
    ? Math.round(
        ((latestAssessment.strengthScore ?? 50) +
          (latestAssessment.weaknessScore ?? 50) +
          (latestAssessment.opportunityScore ?? 50) +
          (latestAssessment.threatScore ?? 50)) /
          4
      )
    : 0;

  const healthScore = allStrategies.length > 0
    ? Math.round(swotAvg * 0.5 + executionRate * 0.5)
    : swotAvg;

  // Weekly priorities — top 3 milestones to act on
  const actionable = allMilestones.filter((m) => m.status !== "completed");
  const inProgress = actionable.filter((m) => m.status === "in_progress");
  const notStartedWithKpi = actionable.filter((m) => m.status === "not_started" && m.kpi);
  const notStartedPlain = actionable.filter((m) => m.status === "not_started" && !m.kpi);
  const priorityPool = [...inProgress, ...notStartedWithKpi, ...notStartedPlain].slice(0, 3);

  const weeklyPriorities = priorityPool.map((m) => ({
    milestoneId: m.id,
    title: m.title,
    pillarTitle: m.pillarTitle,
    kpi: m.kpi ?? null,
    target: m.target ?? null,
    timeframe: m.timeframe ?? null,
    urgency: m.status === "in_progress" ? "high" : m.kpi ? "medium" : "low",
    reason:
      m.status === "in_progress"
        ? `Already in progress — close this out to maintain momentum in the ${m.pillarTitle} area.`
        : m.kpi
        ? `Has a defined KPI (${m.kpi}) with target ${m.target ?? "TBD"} — start measuring now.`
        : `Next logical step in the ${m.pillarTitle} area.`,
  }));

  // Risk radar — from SWOT
  const riskRadar: Array<{ id: string; text: string; category: string; urgency: string; countermove: string }> = [];

  if (latestAssessment) {
    const threatCountermoves = [
      "Accelerate differentiation — build a moat before this threat intensifies.",
      "Lock in key customer contracts now to reduce exposure to market shifts.",
      "Invest in partnerships that buffer against this risk.",
      "Run a scenario plan for this threat and set a tripwire metric to monitor it.",
    ];
    const weaknessCountermoves = [
      "Close this gap with a targeted hire or external specialist.",
      "Build a process or system to eliminate this bottleneck.",
      "Prioritize one milestone in your strategy that directly addresses this weakness.",
      "Set a 30-day sprint to resolve this before it compounds.",
    ];

    (latestAssessment.threats ?? []).slice(0, 3).forEach((t, i) => {
      riskRadar.push({
        id: `threat-${i}`,
        text: t,
        category: "threat",
        urgency: i === 0 ? "high" : "medium",
        countermove: threatCountermoves[i % threatCountermoves.length],
      });
    });
    (latestAssessment.weaknesses ?? []).slice(0, 2).forEach((w, i) => {
      riskRadar.push({
        id: `weakness-${i}`,
        text: w,
        category: "weakness",
        urgency: "medium",
        countermove: weaknessCountermoves[i % weaknessCountermoves.length],
      });
    });
  }

  // CSO narrative
  const name = business.name;
  let briefingParts: string[] = [];

  if (allAssessments.length === 0) {
    briefingParts.push(`I'm still waiting for assessment data on ${name}. Run a SWOT assessment to unlock strategic intelligence.`);
  } else {
    if (healthScore >= 70) {
      briefingParts.push(`${name} is tracking well — health score of ${healthScore} indicates a strong strategic foundation.`);
    } else if (healthScore >= 45) {
      briefingParts.push(`${name} has the right building blocks but a health score of ${healthScore} signals material gaps that need closing before scaling.`);
    } else {
      briefingParts.push(`${name} is at an early critical stage. Health score of ${healthScore} means the fundamentals need hardening before any aggressive moves.`);
    }

    if (totalMilestones === 0) {
      briefingParts.push(`No active strategy yet — I recommend generating one to turn your SWOT insights into an execution plan.`);
    } else if (executionRate === 0) {
      briefingParts.push(`Strategy is defined but execution hasn't started. Pick one milestone and begin this week — momentum compounds.`);
    } else if (executionRate < 30) {
      briefingParts.push(`Execution is at ${executionRate}% — early stage. ${inProgressMilestones} action${inProgressMilestones !== 1 ? "s" : ""} in progress.`);
    } else if (executionRate < 70) {
      briefingParts.push(`Execution at ${executionRate}%. Good progress — don't let the in-progress milestones stall.`);
    } else {
      briefingParts.push(`Exceptional execution at ${executionRate}%. ${completedMilestones} of ${totalMilestones} actions complete — maintain this pace.`);
    }

    if (kpisPendingLog > 0) {
      briefingParts.push(`${kpisPendingLog} KPI${kpisPendingLog !== 1 ? "s" : ""} defined but not yet measured. Log actuals to know if you're on track — strategy without data is guesswork.`);
    }

    const highRisks = riskRadar.filter((r) => r.urgency === "high");
    if (highRisks.length > 0) {
      briefingParts.push(`High-urgency risk on my radar: "${highRisks[0].text}" — ${highRisks[0].countermove}`);
    }
  }

  const csoBriefingText = briefingParts.join(" ");

  res.json({
    businessId,
    healthScore,
    executionRate,
    totalMilestones,
    completedMilestones,
    inProgressMilestones,
    kpisWithLogs,
    kpisPendingLog,
    activeRisks: riskRadar.filter((r) => r.urgency === "high").length,
    csoBriefingText,
    weeklyPriorities,
    riskRadar,
  });
});

router.get("/businesses/:id/dashboard", async (req, res): Promise<void> => {
  const params = GetBusinessDashboardParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const businessId = params.data.id;

  const [assessmentCount] = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.businessId, businessId));

  const allAssessments = await db
    .select()
    .from(assessmentsTable)
    .where(eq(assessmentsTable.businessId, businessId))
    .orderBy(desc(assessmentsTable.createdAt));

  const allStrategies = await db
    .select()
    .from(strategiesTable)
    .where(eq(strategiesTable.businessId, businessId))
    .orderBy(desc(strategiesTable.createdAt));

  const latestAssessment = allAssessments[0] ?? null;
  const latestStrategy = allStrategies[0] ?? null;

  // Get milestone stats for all strategies of this business
  let milestoneStats = { total: 0, completed: 0, inProgress: 0, notStarted: 0 };

  if (allStrategies.length > 0) {
    const strategyIds = allStrategies.map((s) => s.id);
    const pillars = await db
      .select()
      .from(strategyPillarsTable)
      .where(
        strategyIds.length === 1
          ? eq(strategyPillarsTable.strategyId, strategyIds[0])
          : strategyPillarsTable.strategyId.in(strategyIds)
      );

    if (pillars.length > 0) {
      const pillarIds = pillars.map((p) => p.id);
      const allMilestones = await db
        .select()
        .from(milestonesTable)
        .where(
          pillarIds.length === 1
            ? eq(milestonesTable.pillarId, pillarIds[0])
            : milestonesTable.pillarId.in(pillarIds)
        );

      milestoneStats = {
        total: allMilestones.length,
        completed: allMilestones.filter((m) => m.status === "completed").length,
        inProgress: allMilestones.filter((m) => m.status === "in_progress").length,
        notStarted: allMilestones.filter((m) => m.status === "not_started").length,
      };
    }
  }

  res.json({
    businessId,
    assessmentCount: allAssessments.length,
    strategyCount: allStrategies.length,
    latestAssessmentId: latestAssessment?.id ?? null,
    latestStrategyId: latestStrategy?.id ?? null,
    milestoneStats,
    swotScores: latestAssessment
      ? {
          strengthScore: latestAssessment.strengthScore,
          weaknessScore: latestAssessment.weaknessScore,
          opportunityScore: latestAssessment.opportunityScore,
          threatScore: latestAssessment.threatScore,
        }
      : null,
  });
});

export default router;
