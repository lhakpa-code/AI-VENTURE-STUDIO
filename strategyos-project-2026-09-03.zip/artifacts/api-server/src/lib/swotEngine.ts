/**
 * SWOT Engine
 * Generates structured, context-aware SWOT analysis based on
 * company name, industry, and country. Each output is personalized
 * using the actual company name and regional/sector context.
 */

export interface SwotResult {
  companyName: string;
  industry: string;
  country: string;
  strengths: SwotItem[];
  weaknesses: SwotItem[];
  opportunities: SwotItem[];
  threats: SwotItem[];
  summary: string;
}

export interface SwotItem {
  title: string;
  detail: string;
}

// Industry knowledge base
const INDUSTRY_DATA: Record<string, {
  strengthDrivers: string[];
  weaknessDrivers: string[];
  opportunityDrivers: string[];
  threatDrivers: string[];
  sector: string;
}> = {
  technology: {
    sector: "Technology",
    strengthDrivers: ["technical expertise", "IP ownership", "scalable architecture", "data assets", "developer talent"],
    weaknessDrivers: ["high customer acquisition cost", "technical debt", "talent retention", "long sales cycles in enterprise", "dependence on key engineers"],
    opportunityDrivers: ["AI/ML adoption wave", "cloud migration demand", "API economy growth", "remote work infrastructure", "digital transformation spend"],
    threatDrivers: ["Big Tech platform risk", "open-source alternatives", "cybersecurity exposure", "rapid technology obsolescence", "regulatory scrutiny on data"],
  },
  manufacturing: {
    sector: "Manufacturing",
    strengthDrivers: ["production capacity", "supply chain relationships", "quality certifications", "operational efficiency", "existing customer base"],
    weaknessDrivers: ["high fixed costs", "capital intensity", "dependency on raw material suppliers", "skilled labour shortage", "slow product iteration cycles"],
    opportunityDrivers: ["Industry 4.0 automation", "nearshoring trends", "sustainability mandates", "EV and clean energy supply chains", "emerging market demand"],
    threatDrivers: ["commodity price volatility", "labour cost inflation", "geopolitical supply chain disruption", "cheaper imports", "environmental compliance costs"],
  },
  retail: {
    sector: "Retail",
    strengthDrivers: ["brand recognition", "customer loyalty", "physical footprint", "supplier relationships", "merchandising expertise"],
    weaknessDrivers: ["thin margins", "inventory management", "e-commerce gap", "high operating costs", "seasonal revenue concentration"],
    opportunityDrivers: ["omnichannel retail expansion", "social commerce growth", "loyalty program monetisation", "D2C brand building", "personalisation technology"],
    threatDrivers: ["Amazon and marketplace dominance", "shifting consumer habits", "economic downturns reducing discretionary spend", "supply chain disruptions", "fast fashion competition"],
  },
  healthcare: {
    sector: "Healthcare",
    strengthDrivers: ["clinical expertise", "patient trust", "regulatory approvals", "proprietary treatment protocols", "strong referral networks"],
    weaknessDrivers: ["regulatory complexity", "long product approval timelines", "high R&D costs", "reimbursement uncertainty", "dependence on specialist staff"],
    opportunityDrivers: ["telemedicine and digital health adoption", "aging global population", "preventive care demand", "AI diagnostics", "underserved market access"],
    threatDrivers: ["regulatory policy changes", "healthcare cost containment pressure", "insurance reimbursement cuts", "liability exposure", "staff shortage crisis"],
  },
  fintech: {
    sector: "Financial Technology",
    strengthDrivers: ["regulatory licences", "technology infrastructure", "data analytics capability", "user-friendly UX", "low cost-to-serve"],
    weaknessDrivers: ["regulatory compliance costs", "customer trust gap vs. banks", "fraud and risk exposure", "limited credit history data", "high marketing spend needed"],
    opportunityDrivers: ["unbanked and underbanked populations", "open banking regulations", "embedded finance growth", "cross-border payment demand", "crypto/DeFi convergence"],
    threatDrivers: ["incumbent bank digital products", "regulatory crackdowns", "cybersecurity breaches", "economic downturns increasing defaults", "margin compression from competition"],
  },
  ecommerce: {
    sector: "E-Commerce",
    strengthDrivers: ["brand community", "customer data and analytics", "logistics partnerships", "product catalogue depth", "SEO and digital presence"],
    weaknessDrivers: ["customer acquisition costs", "returns management", "last-mile delivery costs", "thin margins", "platform dependency (Google/Meta ads)"],
    opportunityDrivers: ["cross-border trade expansion", "live commerce and video shopping", "subscription model adoption", "B2B e-commerce growth", "AI-driven personalisation"],
    threatDrivers: ["marketplace giants undercutting pricing", "ad cost inflation", "payment fraud", "supply chain disruptions", "consumer data privacy regulations"],
  },
  food: {
    sector: "Food & Beverage",
    strengthDrivers: ["brand recognition", "distribution network", "product quality and taste", "loyal customer base", "proprietary recipes or formulations"],
    weaknessDrivers: ["perishable inventory", "supply chain fragility", "price sensitivity", "food safety compliance costs", "limited shelf life"],
    opportunityDrivers: ["health-conscious consumer trend", "plant-based alternatives growth", "food delivery platform penetration", "export market expansion", "functional foods demand"],
    threatDrivers: ["commodity price volatility", "regulatory changes on labelling", "copycat competition", "consumer trend shifts", "food recall risk"],
  },
  education: {
    sector: "Education",
    strengthDrivers: ["curriculum quality", "accreditation", "faculty expertise", "alumni network", "brand reputation"],
    weaknessDrivers: ["high content production costs", "learner retention rates", "slow curriculum updates", "low price tolerance", "difficulty proving ROI to learners"],
    opportunityDrivers: ["online and hybrid learning adoption", "corporate training budgets", "lifelong learning demand", "upskilling for AI/tech transition", "emerging market demand for quality education"],
    threatDrivers: ["free content competition (YouTube, MOOCs)", "credential questioning by employers", "economic pressure on education spending", "regulatory accreditation changes", "AI-generated content disruption"],
  },
  logistics: {
    sector: "Logistics & Supply Chain",
    strengthDrivers: ["route network", "warehouse infrastructure", "carrier relationships", "tracking technology", "customer contracts"],
    weaknessDrivers: ["high fuel and operating costs", "driver/staff shortage", "thin margins", "weather and disruption sensitivity", "ageing fleet or infrastructure"],
    opportunityDrivers: ["e-commerce fulfilment demand", "cold chain expansion", "autonomous vehicle logistics", "same-day delivery demand", "reshoring manufacturing logistics"],
    threatDrivers: ["fuel price volatility", "regulatory changes on emissions", "Amazon and Alibaba in-house logistics", "last-mile cost pressure", "labour market tightness"],
  },
  saas: {
    sector: "SaaS",
    strengthDrivers: ["recurring revenue model", "low marginal cost to serve", "product stickiness", "usage data for product improvement", "global reach"],
    weaknessDrivers: ["high churn risk", "onboarding complexity", "customer success costs", "feature bloat", "long enterprise sales cycles"],
    opportunityDrivers: ["vertical SaaS opportunity in underserved industries", "AI feature integration", "international expansion", "platform and ecosystem plays", "usage-based pricing adoption"],
    threatDrivers: ["well-funded competitors", "Microsoft/Google/Salesforce bundling", "customer consolidation", "AI native alternatives replacing legacy SaaS", "economic downturns triggering SaaS spend cuts"],
  },
  consulting: {
    sector: "Consulting & Professional Services",
    strengthDrivers: ["domain expertise", "client relationships", "reputation and case studies", "proprietary frameworks", "senior talent"],
    weaknessDrivers: ["revenue tied to headcount", "key person dependency", "difficulty scaling", "long sales cycles", "high talent attrition"],
    opportunityDrivers: ["digital transformation advisory demand", "AI strategy consulting", "ESG and sustainability consulting", "emerging market advisory", "specialised niche practices"],
    threatDrivers: ["Big 4 competition", "automation replacing routine consulting work", "client insourcing", "price pressure on deliverables", "knowledge commoditisation via AI"],
  },
  real_estate: {
    sector: "Real Estate",
    strengthDrivers: ["property portfolio", "local market knowledge", "developer relationships", "brand trust", "financing access"],
    weaknessDrivers: ["illiquidity of assets", "high capital requirements", "market cycle sensitivity", "regulatory exposure", "geographic concentration"],
    opportunityDrivers: ["proptech and digital sales channels", "co-living and flexible workspace demand", "affordable housing development", "logistics real estate boom", "ESG-compliant building demand"],
    threatDrivers: ["interest rate rises", "regulatory rent controls", "economic recession reducing demand", "remote work reducing commercial real estate value", "construction cost inflation"],
  },
  energy: {
    sector: "Energy",
    strengthDrivers: ["energy production assets", "regulatory licences", "long-term customer contracts", "infrastructure", "engineering expertise"],
    weaknessDrivers: ["high capital expenditure", "fossil fuel dependency", "ageing infrastructure", "environmental liability", "complex regulatory compliance"],
    opportunityDrivers: ["renewable energy transition", "energy storage investment", "government green subsidies", "EV charging infrastructure", "carbon credit markets"],
    threatDrivers: ["commodity price swings", "clean energy disrupting fossil fuels", "regulatory carbon taxes", "geopolitical supply risk", "stranded asset risk"],
  },
  media: {
    sector: "Media & Entertainment",
    strengthDrivers: ["content library", "audience and subscriber base", "brand recognition", "creator relationships", "distribution platform"],
    weaknessDrivers: ["content production costs", "piracy", "audience fragmentation", "dependence on ad revenue", "platform algorithm dependency"],
    opportunityDrivers: ["streaming and subscription model shift", "creator economy partnerships", "live and interactive content", "international content localisation", "AI-assisted content production"],
    threatDrivers: ["streaming wars eroding margins", "ad revenue decline", "user-generated content competition", "platform giants crowding out independent media", "short-form video shifting attention"],
  },
};

// Country/region context
const COUNTRY_CONTEXT: Record<string, {
  region: string;
  marketLabel: string;
  economicContext: string;
  regulatoryNote: string;
  opportunity: string;
  threat: string;
}> = {
  "united states": { region: "North America", marketLabel: "the US market", economicContext: "the world's largest consumer economy", regulatoryNote: "SEC, FTC, and state-level regulatory frameworks", opportunity: "access to the world's deepest venture capital and enterprise market", threat: "intense domestic competition and high customer acquisition costs" },
  "united kingdom": { region: "Europe", marketLabel: "the UK market", economicContext: "a post-Brexit economy undergoing trade realignment", regulatoryNote: "FCA, ICO, and CMA oversight", opportunity: "a highly digital-savvy consumer base and strong fintech ecosystem", threat: "ongoing post-Brexit trade friction and talent sourcing constraints" },
  "germany": { region: "Europe", marketLabel: "the German market", economicContext: "Europe's largest industrial economy", regulatoryNote: "strict GDPR and BaFin financial regulation", opportunity: "engineering-driven SME modernisation and EU single market access", threat: "energy cost pressures and slow digital adoption in traditional industries" },
  "india": { region: "Asia-Pacific", marketLabel: "the Indian market", economicContext: "one of the fastest-growing major economies", regulatoryNote: "SEBI, RBI, and evolving startup regulation", opportunity: "a 1.4 billion consumer market with rapid digital adoption and a thriving startup ecosystem", threat: "infrastructure constraints, complex compliance, and intense price competition" },
  "china": { region: "Asia-Pacific", marketLabel: "the Chinese market", economicContext: "the world's second-largest economy with state-led growth", regulatoryNote: "SAMR, PBOC, and strict data sovereignty laws", opportunity: "massive domestic consumer market and manufacturing cost advantages", threat: "geopolitical tensions, regulatory unpredictability, and intellectual property risks" },
  "nigeria": { region: "Africa", marketLabel: "the Nigerian market", economicContext: "Africa's largest economy by GDP", regulatoryNote: "CBN and SEC Nigeria financial oversight", opportunity: "a young, fast-growing population of 220M+ and a leading African tech ecosystem", threat: "currency volatility, infrastructure gaps, and regulatory inconsistency" },
  "brazil": { region: "Latin America", marketLabel: "the Brazilian market", economicContext: "Latin America's largest economy", regulatoryNote: "LGPD data law, Bacen, and CVM oversight", opportunity: "a large unbanked population driving fintech adoption and a growing middle class", threat: "political volatility, high tax burden, and FX risk" },
  "australia": { region: "Asia-Pacific", marketLabel: "the Australian market", economicContext: "a high-income, resource-rich economy with strong Asia ties", regulatoryNote: "ASIC, ACCC, and state regulatory bodies", opportunity: "proximity to high-growth Asian markets and a mature digital consumer base", threat: "small domestic market limiting scale and high labour costs" },
  "canada": { region: "North America", marketLabel: "the Canadian market", economicContext: "a stable, resource and services economy closely tied to the US", regulatoryNote: "PIPEDA, OSFI, and provincial regulators", opportunity: "strong immigration-driven talent pipeline and proximity to the US market", threat: "US trade dependency and talent drain to larger markets" },
  "france": { region: "Europe", marketLabel: "the French market", economicContext: "a major EU economy with strong state influence in industry", regulatoryNote: "AMF, CNIL, and French labour code constraints", opportunity: "EU single market access, strong luxury and agri-food sectors, and Paris as a tech hub", threat: "labour market rigidity and high regulatory compliance burden" },
  "singapore": { region: "Asia-Pacific", marketLabel: "the Singapore market", economicContext: "a global financial and logistics hub in Southeast Asia", regulatoryNote: "MAS, PDPA, and pro-business MNC-friendly regulation", opportunity: "gateway to ASEAN's 680M consumer market and world-class digital infrastructure", threat: "small domestic market requiring immediate regional strategy" },
  "south africa": { region: "Africa", marketLabel: "the South African market", economicContext: "Africa's most industrialised economy", regulatoryNote: "FSCA, POPIA, and B-BBEE compliance requirements", opportunity: "most developed financial infrastructure in Africa and growing tech ecosystem", threat: "infrastructure challenges, electricity supply disruptions, and currency volatility" },
  "uae": { region: "Middle East", marketLabel: "the UAE market", economicContext: "a diversified, high-income Gulf economy with ambitions beyond oil", regulatoryNote: "CBUAE, DIFC, and ADGM regulatory frameworks", opportunity: "tax-friendly environment, strategic global connectivity, and a wealthy consumer base", threat: "heavy dependence on oil-linked government spending and a small national population" },
  "indonesia": { region: "Asia-Pacific", marketLabel: "the Indonesian market", economicContext: "Southeast Asia's largest economy with 280M+ people", regulatoryNote: "OJK, Kominfo, and evolving data localisation rules", opportunity: "a massive young digital population and fastest-growing e-commerce market in SEA", threat: "regulatory data localisation requirements and logistics fragmentation across 17,000 islands" },
  "kenya": { region: "Africa", marketLabel: "the Kenyan market", economicContext: "East Africa's economic hub and mobile money pioneer", regulatoryNote: "CMA Kenya and CBK oversight", opportunity: "Africa's most advanced mobile money ecosystem and regional hub for pan-African expansion", threat: "political uncertainty, currency depreciation, and regional infrastructure gaps" },
  "mexico": { region: "Latin America", marketLabel: "the Mexican market", economicContext: "Latin America's second-largest economy and a manufacturing nearshoring hub", regulatoryNote: "CNBV, COFECE, and the Fintech Law", opportunity: "nearshoring boom from US-China decoupling and a large underbanked population", threat: "security concerns in certain regions, public institution reliability, and FX risk" },
};

function getCountryContext(country: string) {
  const key = country.toLowerCase().trim();
  return COUNTRY_CONTEXT[key] ?? {
    region: "international",
    marketLabel: `the ${country} market`,
    economicContext: "a growing economy with emerging opportunities",
    regulatoryNote: "local regulatory compliance requirements",
    opportunity: `local market growth and potential for regional expansion from ${country}`,
    threat: `market entry barriers, regulatory changes, and currency risk in ${country}`,
  };
}

function getIndustryData(industry: string) {
  const key = industry.toLowerCase().trim();
  // Fuzzy match
  for (const [k, v] of Object.entries(INDUSTRY_DATA)) {
    if (key.includes(k) || k.includes(key)) return { key: k, ...v };
  }
  // Check common synonyms
  if (key.includes("software") || key.includes("tech") || key.includes("it ") || key.includes("app")) return { key: "technology", ...INDUSTRY_DATA.technology };
  if (key.includes("bank") || key.includes("finance") || key.includes("payment") || key.includes("insurance")) return { key: "fintech", ...INDUSTRY_DATA.fintech };
  if (key.includes("shop") || key.includes("store") || key.includes("commerce") || key.includes("e-comm")) return { key: "ecommerce", ...INDUSTRY_DATA.ecommerce };
  if (key.includes("pharma") || key.includes("medical") || key.includes("health") || key.includes("biotech")) return { key: "healthcare", ...INDUSTRY_DATA.healthcare };
  if (key.includes("school") || key.includes("learn") || key.includes("train") || key.includes("academy")) return { key: "education", ...INDUSTRY_DATA.education };
  if (key.includes("restaurant") || key.includes("beverage") || key.includes("agri") || key.includes("farm")) return { key: "food", ...INDUSTRY_DATA.food };
  if (key.includes("transport") || key.includes("freight") || key.includes("shipping") || key.includes("deliver")) return { key: "logistics", ...INDUSTRY_DATA.logistics };
  if (key.includes("oil") || key.includes("gas") || key.includes("power") || key.includes("solar") || key.includes("renew")) return { key: "energy", ...INDUSTRY_DATA.energy };
  if (key.includes("property") || key.includes("estate") || key.includes("construc") || key.includes("building")) return { key: "real_estate", ...INDUSTRY_DATA.real_estate };
  if (key.includes("entertainment") || key.includes("music") || key.includes("film") || key.includes("publish")) return { key: "media", ...INDUSTRY_DATA.media };
  if (key.includes("consult") || key.includes("advisory") || key.includes("legal") || key.includes("accounti")) return { key: "consulting", ...INDUSTRY_DATA.consulting };
  if (key.includes("manufactur") || key.includes("factor") || key.includes("assembl") || key.includes("product")) return { key: "manufacturing", ...INDUSTRY_DATA.manufacturing };

  // Generic fallback
  return {
    key: "general",
    sector: industry.charAt(0).toUpperCase() + industry.slice(1),
    strengthDrivers: ["established market presence", "core product or service quality", "customer relationships", "operational experience", "team expertise"],
    weaknessDrivers: ["limited brand awareness", "resource constraints", "narrow product range", "operational inefficiencies", "limited digital presence"],
    opportunityDrivers: ["market digitisation", "underserved customer segments", "strategic partnerships", "product line expansion", "geographic growth"],
    threatDrivers: ["competitive pressure from established players", "economic uncertainty", "regulatory changes", "shifting consumer preferences", "technology disruption"],
  };
}

export function generateSwot(companyName: string, industry: string, country: string): SwotResult {
  const name = companyName.trim();
  const ind = getIndustryData(industry);
  const ctx = getCountryContext(country);

  const strengths: SwotItem[] = [
    {
      title: `${ind.sector} Sector Positioning`,
      detail: `${name} operates in the ${ind.sector} sector — a domain where ${ind.strengthDrivers[0]} and ${ind.strengthDrivers[1]} create durable competitive advantages when properly leveraged.`,
    },
    {
      title: "Market Knowledge & Domain Expertise",
      detail: `As a player in ${ctx.marketLabel}, ${name} has the opportunity to build deep local knowledge of customer behaviour, regulatory nuances, and distribution channels that outsiders struggle to replicate.`,
    },
    {
      title: "Agility and Speed-to-Market",
      detail: `${name}'s size and focus allows it to move faster than larger incumbents — adapting to market signals, shipping new offerings, and pivoting strategy without the inertia of bureaucratic decision-making.`,
    },
    {
      title: `${ind.strengthDrivers[2].charAt(0).toUpperCase() + ind.strengthDrivers[2].slice(1)} Advantage`,
      detail: `In the ${ind.sector} space, companies that invest early in ${ind.strengthDrivers[2]} and ${ind.strengthDrivers[3]} tend to compound competitive moats over time. ${name} is positioned to build this foundation.`,
    },
  ];

  const weaknesses: SwotItem[] = [
    {
      title: "Brand Recognition Gap",
      detail: `${name} is likely still building market visibility in ${ctx.marketLabel}. Without strong brand trust, customer acquisition remains expensive and competitive — especially when established players already own mindshare.`,
    },
    {
      title: `${ind.weaknessDrivers[0].charAt(0).toUpperCase() + ind.weaknessDrivers[0].slice(1)}`,
      detail: `A common structural challenge in the ${ind.sector} industry is ${ind.weaknessDrivers[0]}. ${name} must proactively address this or risk it becoming a performance ceiling as the business grows.`,
    },
    {
      title: "Resource Constraints",
      detail: `Limited capital, talent, or operational bandwidth can constrain ${name}'s ability to pursue all opportunities simultaneously. Prioritisation and focus are critical to avoid spreading thin across too many fronts.`,
    },
    {
      title: `${ind.weaknessDrivers[1].charAt(0).toUpperCase() + ind.weaknessDrivers[1].slice(1)}`,
      detail: `${ind.sector} businesses in ${ctx.region} frequently struggle with ${ind.weaknessDrivers[1]}. ${name} should diagnose its current exposure to this challenge and build mitigation into its operating model.`,
    },
  ];

  const opportunities: SwotItem[] = [
    {
      title: `${ctx.region} Market Tailwinds`,
      detail: `${name} is positioned to benefit from ${ctx.opportunity}. The structural dynamics of ${ctx.economicContext} create demand that aligned businesses can capture with the right go-to-market approach.`,
    },
    {
      title: `${ind.opportunityDrivers[0].charAt(0).toUpperCase() + ind.opportunityDrivers[0].slice(1)}`,
      detail: `One of the most significant growth vectors in the ${ind.sector} sector right now is ${ind.opportunityDrivers[0]}. ${name} can build a differentiated position if it moves early and with intent.`,
    },
    {
      title: `${ind.opportunityDrivers[1].charAt(0).toUpperCase() + ind.opportunityDrivers[1].slice(1)}`,
      detail: `${ind.opportunityDrivers[1]} is creating new customer segments and revenue streams in ${ind.sector}. Businesses like ${name} that capitalise on this shift can acquire customers at lower cost and with higher lifetime value.`,
    },
    {
      title: "Strategic Partnerships & Ecosystem Plays",
      detail: `In ${ctx.marketLabel}, forming partnerships with complementary businesses, distributors, or platforms can accelerate ${name}'s reach without proportional increases in cost — a key lever for capital-efficient growth.`,
    },
  ];

  const threats: SwotItem[] = [
    {
      title: "Competitive Intensity",
      detail: `The ${ind.sector} market in ${ctx.region} is attracting both local challengers and well-capitalised global players. ${name} must continuously sharpen its differentiation or risk being commoditised on price.`,
    },
    {
      title: `Regulatory & Compliance Risk`,
      detail: `Operating in ${country} means navigating ${ctx.regulatoryNote}. Changes in policy, new compliance requirements, or enforcement actions can create unexpected costs and operational disruptions for ${name}.`,
    },
    {
      title: `${ind.threatDrivers[0].charAt(0).toUpperCase() + ind.threatDrivers[0].slice(1)}`,
      detail: `${name} faces a real risk from ${ind.threatDrivers[0]}. This is not hypothetical — it has materially impacted peers in the ${ind.sector} space. Building resilience against this threat is a strategic priority.`,
    },
    {
      title: `Macroeconomic and Market Risk`,
      detail: `${ctx.threat}. These structural conditions can affect customer purchasing power, credit availability, and partner reliability — all of which directly impact ${name}'s revenue predictability.`,
    },
  ];

  const summary = `${name} is a ${ind.sector} business operating in ${ctx.marketLabel} — ${ctx.economicContext}. The analysis identifies ${strengths.length} key strengths it can leverage, ${weaknesses.length} structural weaknesses to address, ${opportunities.length} material market opportunities to pursue, and ${threats.length} active threats to monitor. The most time-sensitive priority is capitalising on ${ind.opportunityDrivers[0].toLowerCase()} before competition intensifies, while closing the gap on ${ind.weaknessDrivers[0].toLowerCase()} which represents the highest internal risk.`;

  return { companyName: name, industry: ind.sector, country, strengths, weaknesses, opportunities, threats, summary };
}
