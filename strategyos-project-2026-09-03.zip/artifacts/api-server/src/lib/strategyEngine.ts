/**
 * Rule-based business assessment & strategy generation engine.
 * Produces company-personalized SWOT analysis and formula-structured growth strategies.
 * Formula: Strategy Area → Strategic Objective → KPI → Target → Timeframe
 * Can be swapped for an LLM call by replacing the exported functions.
 */

export interface BusinessProfile {
  name: string;
  industry: string;
  stage: string;
  description?: string | null;
  targetMarket?: string | null;
  teamSize?: string | null;
  revenueRange?: string | null;
  mainGoal?: string | null;
}

export interface AssessmentResult {
  identitySummary: string;
  strengths: string[];
  weaknesses: string[];
  opportunities: string[];
  threats: string[];
  strengthScore: number;
  weaknessScore: number;
  opportunityScore: number;
  threatScore: number;
  recommendations: string[];
}

export interface MilestoneDef {
  title: string;        // Strategic Objective
  description: string;  // How to execute it
  kpi: string;          // Key Performance Indicator
  target: string;       // Specific measurable target
  timeframe: string;    // When to achieve it
  order: number;
}

export interface StrategyPillarDef {
  title: string;        // Strategy Area
  description: string;
  priority: number;
  milestones: MilestoneDef[];
}

export interface StrategyResult {
  overview: string;
  pillars: StrategyPillarDef[];
}

// ─── SWOT DATA BANKS ──────────────────────────────────────────────────────────

function getStrengths(name: string, stage: string, teamSize: string, revenue: string): string[] {
  const stageMap: Record<string, string[]> = {
    idea: [
      `${name} has high creative freedom and zero legacy technical debt to work around`,
      "Ability to design operations from scratch using current best practices",
      "Founder-led decision-making enables rapid pivots without committee approval",
      "Low overhead allows aggressive experimentation with minimal financial risk",
    ],
    "pre-revenue": [
      `${name} has a proven concept with early product or service already in development`,
      "Strong founder conviction and early team alignment on the mission",
      "Low burn rate enables rapid experimentation before committing to scale",
      "No customer churn risk — full freedom to build the ideal version first",
    ],
    "early-stage": [
      `${name} has validated demand from real paying customers`,
      "Lean team structure enables faster execution than incumbent competitors",
      "Direct founder-to-customer relationships provide unfiltered market insight",
      `Demonstrated willingness to pay proves ${name}'s core value proposition`,
    ],
    growth: [
      `${name} has established product-market fit with repeatable, predictable revenue`,
      "Growing brand recognition creates compounding acquisition advantages",
      "Existing customer base generates referrals and expansion revenue opportunities",
      "Systems and processes are in place and beginning to scale efficiently",
    ],
    scale: [
      `${name} has a proven business model with strong unit economics`,
      "Established brand equity reduces customer acquisition cost over time",
      "Resources available to invest in strategic M&A or market expansion",
      "Large customer base provides data advantage over smaller competitors",
    ],
  };
  const key = stage.toLowerCase().replace(/[^a-z-]/g, '');
  return (stageMap[key] || stageMap["early-stage"]).slice(0, 4);
}

function getWeaknesses(name: string, stage: string, teamSize: string, revenue: string): string[] {
  const stageMap: Record<string, string[]> = {
    idea: [
      `${name} has no validated revenue stream or paying customers yet`,
      "Limited market data makes confident strategic decisions difficult",
      "High dependency on founder(s) with no supporting team to absorb workload",
      "No proven go-to-market playbook — all channels must be tested from zero",
    ],
    "pre-revenue": [
      `${name} is burning cash without incoming revenue, creating runway pressure`,
      "Unproven assumptions about customer willingness to pay at target price points",
      "Limited operational experience executing at scale under real market conditions",
      "No sales process or pipeline management system yet established",
    ],
    "early-stage": [
      `${name} has an inconsistent sales process leading to unpredictable monthly revenue`,
      "Founder bottlenecks are limiting throughput, delegation, and team autonomy",
      "Limited marketing reach constrains the top of the acquisition funnel",
      "Product gaps relative to well-funded competitors may increase churn risk",
    ],
    growth: [
      `${name}'s internal processes may not yet support rapid scale without breaking`,
      "Team hiring and culture management is becoming increasingly complex",
      "Unit economics may not be fully optimized, compressing margins at scale",
      "Customer success infrastructure not yet mature enough to reduce churn at scale",
    ],
    scale: [
      `${name}'s organizational complexity is slowing decision-making velocity`,
      "Risk of losing the operational agility that drove early competitive advantage",
      "Higher fixed cost base increases exposure to revenue downturns or market shifts",
      "Brand reputation risk increases as public scrutiny grows with company scale",
    ],
  };
  const key = stage.toLowerCase().replace(/[^a-z-]/g, '');
  return (stageMap[key] || stageMap["early-stage"]).slice(0, 4);
}

function getOpportunities(name: string, industry: string, targetMarket: string): string[] {
  const ind = industry.toLowerCase();
  const map: Record<string, string[]> = {
    saas: [
      `AI-assisted development tools can dramatically reduce ${name}'s cost to ship new features`,
      "Vertical SaaS demand is surging as businesses seek purpose-built tools over generic suites",
      "Usage-based pricing models are expanding the addressable market for SaaS products",
      `${targetMarket ? `${targetMarket} segments` : "Underserved niches"} are actively seeking alternatives to bloated legacy platforms`,
    ],
    software: [
      `AI-assisted development tools can dramatically reduce ${name}'s cost to ship new features`,
      "Vertical SaaS demand is surging as businesses seek purpose-built tools over generic suites",
      "API-first architectures are enabling new partnership and distribution channels",
      `${targetMarket ? `${targetMarket} segments` : "Underserved niches"} are actively seeking alternatives to bloated legacy platforms`,
    ],
    "e-commerce": [
      `Social commerce and short-form video are creating new low-CAC acquisition channels for ${name}`,
      "Direct-to-consumer models enable ${name} to capture higher margins vs. marketplace-dependent models",
      "Subscription and membership models can transform transactional buyers into loyal recurring revenue",
      "Cross-border e-commerce is expanding the total addressable market beyond domestic limits",
    ],
    agency: [
      `Demand for specialized expertise is growing as businesses seek partners over generalist agencies`,
      `${name} can leverage AI tools to multiply output per team member without proportional cost increases`,
      "Productized service models create scalable revenue without linear headcount growth",
      "Retainer-based relationships with anchor clients create predictable, recurring revenue",
    ],
    fintech: [
      `Open banking APIs are enabling ${name} to build embedded finance products at lower infrastructure cost`,
      "Underserved demographics represent substantial untapped market potential in financial services",
      "Regulatory sandboxes in key markets are accelerating the path to product authorization",
      "Partnership channels with established financial institutions can provide instant distribution at scale",
    ],
    healthcare: [
      `Telehealth adoption has permanently expanded digital health access, benefiting ${name}'s market`,
      "Value-based care models are rewarding outcomes-driven providers with stronger economics",
      "Aging population demographics create sustained, long-term demand for healthcare innovation",
      "AI-assisted diagnostics and workflow automation can multiply clinical team capacity",
    ],
    education: [
      `Online learning adoption has created a global addressable market ${name} can access from day one`,
      "Corporate upskilling budgets are growing, creating B2B revenue opportunities alongside B2C",
      "Micro-credentialing is disrupting traditional qualification pathways, opening new product categories",
      "AI-powered personalization can dramatically improve learner outcomes and reduce churn",
    ],
    hardware: [
      `Supply chain diversification trends are creating opportunities for agile manufacturers like ${name}`,
      "IoT connectivity is enabling hardware companies to add recurring software revenue to one-time sales",
      "Reshoring initiatives are creating policy tailwinds for domestic manufacturing operations",
      "D2C hardware channels eliminate distributor margins and build direct customer relationships",
    ],
  };

  const indKey = Object.keys(map).find(k => ind.includes(k)) || null;
  const base = indKey ? map[indKey] : [
    `Digital transformation in ${industry} is creating space for agile new entrants like ${name}`,
    "Niche focus can outcompete generalist players with more tailored value propositions",
    "Strategic partnerships can multiply reach without proportional cost increases",
    `${targetMarket ? `${targetMarket} buyers` : "Target buyers"} are increasingly willing to switch from established vendors for better experiences`,
  ];
  return base.slice(0, 4);
}

function getThreats(name: string, stage: string, industry: string): string[] {
  const stageMap: Record<string, string[]> = {
    idea: [
      `Well-funded competitors may enter ${name}'s target market before validation is complete`,
      "Changing macro conditions could invalidate core business assumptions before launch",
      "Founder burnout risk before achieving the first meaningful product-market fit signal",
      "IP and idea replication risk if concept gains visibility without legal protection",
    ],
    "pre-revenue": [
      `Runway expiration before ${name} achieves first revenue milestone`,
      "Competitive products launching with superior funding during the development window",
      "Key technical or commercial talent departures during the uncertain pre-revenue period",
      "Market timing risk — window of opportunity may narrow faster than product development",
    ],
    "early-stage": [
      `Customer churn from an immature product could damage ${name}'s early market reputation`,
      "Larger competitors copying successful features once traction becomes publicly visible",
      "Cash flow gaps between signing customers and receiving payment threatening runway",
      "Over-reliance on a small number of anchor customers creating revenue concentration risk",
    ],
    growth: [
      `Scaling ${name}'s operations faster than infrastructure and team can sustainably support`,
      "Market saturation risk if growth strategy depends on a single acquisition channel",
      "Talent acquisition costs rising rapidly in competitive labor markets",
      "Increasing competition from well-funded entrants attracted by visible traction",
    ],
    scale: [
      `Disruptive new entrants targeting ${name}'s core market with leaner, AI-native models`,
      "Regulatory changes in key markets affecting core business model viability",
      "Economic cycle risk given higher fixed cost structure at scale",
      "Platform or distribution dependency creating single-point-of-failure concentration risk",
    ],
  };
  const key = stage.toLowerCase().replace(/[^a-z-]/g, '');
  return (stageMap[key] || stageMap["early-stage"]).slice(0, 4);
}

function getRecommendations(name: string, stage: string, mainGoal: string): string[] {
  const stageMap: Record<string, string[]> = {
    idea: [
      `Run 20 customer discovery interviews in the next 30 days — ask about the problem, not the solution`,
      `Define one measurable demand-validation hypothesis for ${name} and test it within 4 weeks`,
      "Build a landing page with a clear value proposition and measure click-to-signup conversion before building",
      `Set a hard 60-day deadline: if ${name} can't get 3 people to pay or commit, revisit the core thesis`,
    ],
    "pre-revenue": [
      `Set a public commitment: ${name} will sign its first paying customer within 30 days`,
      "Cut scope ruthlessly to the smallest version someone would pay for today",
      "Identify and personally remove every obstacle between the current state and a signed contract",
      `Start every week with a clear answer to: what is the single most important thing ${name} must do this week to get revenue?`,
    ],
    "early-stage": [
      `Document ${name}'s sales process step-by-step so it can be measured, taught, and improved`,
      `Interview your top 3 customers: understand exactly why they bought and what they'd pay more for`,
      "Set up financial tracking so you know monthly burn rate, runway, and revenue to the dollar",
      `Identify the single biggest reason deals are stalling and fix it this month`,
    ],
    growth: [
      `Build playbooks for every core ${name} operation so delegation becomes possible without quality loss`,
      "Establish a proactive hiring pipeline — never recruit from a position of urgency",
      "Invest in a structured customer success function to protect and expand existing revenue base",
      `Run a quarterly unit economics audit and set explicit improvement targets for CAC, LTV, and gross margin`,
    ],
    scale: [
      `Audit ${name}'s unit economics quarterly and set explicit improvement targets for each metric`,
      "Create structured leadership development paths to retain high-performing managers",
      `Identify ${name}'s next geographic or vertical expansion opportunity and assign a dedicated owner`,
      "Diversify revenue concentration risk — no single customer should exceed 20% of total ARR",
    ],
  };
  const key = stage.toLowerCase().replace(/[^a-z-]/g, '');
  return (stageMap[key] || stageMap["early-stage"]).slice(0, 4);
}

// ─── SCORING ──────────────────────────────────────────────────────────────────

function getScores(stage: string, contextLength: number): { s: number; w: number; o: number; t: number } {
  const stageScores: Record<string, { s: number; w: number; o: number; t: number }> = {
    idea:           { s: 55, w: 75, o: 85, t: 70 },
    "pre-revenue":  { s: 60, w: 70, o: 80, t: 65 },
    "early-stage":  { s: 65, w: 60, o: 75, t: 60 },
    growth:         { s: 75, w: 55, o: 70, t: 55 },
    scale:          { s: 85, w: 50, o: 65, t: 50 },
  };
  const key = stage.toLowerCase().replace(/[^a-z-]/g, '');
  const base = stageScores[key] || stageScores["early-stage"];
  const bonus = contextLength > 100 ? 3 : 0;
  return {
    s: Math.min(100, base.s + bonus),
    w: Math.max(10, base.w - bonus),
    o: Math.min(100, base.o),
    t: Math.max(10, base.t),
  };
}

// ─── EXPORTED FUNCTIONS ───────────────────────────────────────────────────────

export function generateAssessment(
  profile: BusinessProfile,
  additionalContext: string
): AssessmentResult {
  const name = profile.name;
  const stage = profile.stage || "early-stage";
  const industry = profile.industry || "your industry";
  const teamSize = profile.teamSize || "small";
  const revenue = profile.revenueRange || "early-stage levels";
  const market = profile.targetMarket || "";
  const goal = profile.mainGoal || "";

  const strengths    = getStrengths(name, stage, teamSize, revenue);
  const weaknesses   = getWeaknesses(name, stage, teamSize, revenue);
  const opportunities = getOpportunities(name, industry, market);
  const threats      = getThreats(name, stage, industry);
  const recommendations = getRecommendations(name, stage, goal);
  const scores       = getScores(stage, additionalContext.length);

  const goalNote = goal.length > 0 ? ` The stated growth target is: ${goal}.` : "";
  const contextNote = additionalContext.length > 20 ? ` Additional context provided: ${additionalContext}` : "";

  const identitySummary =
    `${name} is a ${stage} business operating in the ${industry} space` +
    (market ? `, serving ${market}` : "") +
    `. ${profile.description ? profile.description + " " : ""}` +
    `Current team size is ${teamSize} with revenue at ${revenue}.${goalNote}${contextNote} ` +
    `The analysis below maps ${name}'s internal capabilities against external market conditions to identify the clearest path from the current ${stage} stage to the next growth threshold.`;

  return {
    identitySummary,
    strengths,
    weaknesses,
    opportunities,
    threats,
    strengthScore: scores.s,
    weaknessScore: scores.w,
    opportunityScore: scores.o,
    threatScore: scores.t,
    recommendations,
  };
}

// ─── STRATEGY ENGINE ──────────────────────────────────────────────────────────
// Each milestone maps to the formula:
//   Strategy Area (pillar.title) → Strategic Objective (milestone.title)
//   → KPI (milestone.kpi) → Target (milestone.target) → Timeframe (milestone.timeframe)

export function generateStrategy(
  profile: BusinessProfile,
  title: string,
  focusAreas: string[],
  assessmentResult?: AssessmentResult | null
): StrategyResult {
  const name = profile.name;
  const stage = profile.stage || "early-stage";
  const industry = profile.industry || "your industry";
  const revenue = profile.revenueRange || "early-stage";

  // Infer revenue tier for target-setting
  const isPreRevenue = revenue === "$0" || stage === "idea" || stage === "pre-revenue";
  const isEarly = stage === "early-stage";
  const isGrowth = stage === "growth" || stage === "scale";

  const overview =
    `This growth strategy for ${name} translates the SWOT analysis into a concrete execution roadmap. ` +
    `Each strategic area contains specific objectives with measurable KPIs, defined targets, and clear timeframes — ` +
    `so every action is tied to an outcome ${name} can track and report. ` +
    (assessmentResult
      ? `The priorities below directly address ${name}'s identified weaknesses while capitalizing on the highest-value opportunities. `
      : "") +
    `The roadmap is organized into 90-day execution windows to maintain momentum and accountability.`;

  const allPillars: StrategyPillarDef[] = [];

  // ── PILLAR 1: Revenue & Customer Acquisition ───────────────────────────────
  if (focusAreas.length === 0 || focusAreas.includes("Sales") || focusAreas.includes("Marketing")) {
    allPillars.push({
      title: "Revenue Growth",
      description: `Build a repeatable, scalable revenue engine for ${name} with measurable pipeline and conversion targets.`,
      priority: 1,
      milestones: [
        {
          title: "Define and document the Ideal Customer Profile (ICP)",
          description: `Write a one-page profile of ${name}'s best-fit customer — who they are, the specific problem they need solved, and why they choose ${name} over alternatives.`,
          kpi: "ICP document completeness score",
          target: "1 validated ICP document with 3 firmographic and 3 behavioral criteria defined",
          timeframe: "Week 1",
          order: 1,
        },
        {
          title: "Map and instrument the full sales process end-to-end",
          description: `Document every step a ${name} prospect goes through from first contact to signed deal. Identify the stage where deals stall most often.`,
          kpi: "Sales cycle length (days)",
          target: isPreRevenue ? "First signed deal within 30 days" : isEarly ? "Reduce average sales cycle by 20%" : "Sales cycle documented and CRM adoption at 100%",
          timeframe: "Week 1–2",
          order: 2,
        },
        {
          title: "Set monthly revenue target with a weekly leading indicator",
          description: `Choose one leading metric (demos booked, proposals sent, calls completed) that reliably predicts ${name}'s revenue and track it weekly.`,
          kpi: isPreRevenue ? "Number of sales conversations" : "Monthly Recurring Revenue (MRR)",
          target: isPreRevenue ? "10 qualified sales conversations per month" : isEarly ? "20% month-over-month MRR growth" : "Hit monthly revenue target for 3 consecutive months",
          timeframe: "Week 2",
          order: 3,
        },
        {
          title: "Launch one focused acquisition channel experiment",
          description: `Pick the single channel most likely to reach ${name}'s ICP. Run a 30-day test with a specific hypothesis, budget, and success criterion.`,
          kpi: "Customer Acquisition Cost (CAC) from tested channel",
          target: isPreRevenue ? "3 qualified leads within 30 days" : isEarly ? "CAC below current average within 60 days" : "New channel contributing 15% of total pipeline",
          timeframe: "Month 1",
          order: 4,
        },
        {
          title: "Establish a systematic follow-up cadence for all active prospects",
          description: `No deal should go cold without at least 3 structured touches. Build a follow-up sequence and enforce it consistently across every open opportunity.`,
          kpi: "Pipeline follow-up compliance rate",
          target: "100% of active prospects receive structured follow-up within 48 hours",
          timeframe: "Month 1",
          order: 5,
        },
      ],
    });
  }

  // ── PILLAR 2: Product & Delivery Excellence ────────────────────────────────
  if (focusAreas.length === 0 || focusAreas.includes("Product") || focusAreas.includes("Operations")) {
    allPillars.push({
      title: "Product & Delivery",
      description: `Sharpen ${name}'s core delivery so customers consistently achieve the promised outcome and return for more.`,
      priority: 2,
      milestones: [
        {
          title: "Collect structured feedback from recent customers",
          description: `Run 15-minute calls or a 5-question survey with your last 5–10 customers. Ask what they value most, what frustrated them, and what nearly stopped them from buying.`,
          kpi: "Net Promoter Score (NPS)",
          target: isGrowth ? "NPS above 50" : "NPS baseline established with at least 5 responses",
          timeframe: "Week 1–2",
          order: 1,
        },
        {
          title: `Eliminate the #1 friction point in ${name}'s delivery process`,
          description: `Based on customer feedback, identify and fix the single biggest complaint or bottleneck. Document the before/after and measure the impact on satisfaction.`,
          kpi: "Customer satisfaction score (CSAT) post-delivery",
          target: "CSAT improvement of 15% vs. baseline after fix is implemented",
          timeframe: "Month 1",
          order: 2,
        },
        {
          title: "Document core delivery workflow as a repeatable SOP",
          description: `Write down exactly how ${name} delivers its product or service, step by step. This is the foundation for delegation, quality control, and onboarding new team members.`,
          kpi: "SOP completion and adoption rate",
          target: "100% of delivery steps documented; new team member can execute without founder involvement",
          timeframe: "Month 1",
          order: 3,
        },
        {
          title: `Define ${name}'s 90-day product roadmap priorities`,
          description: `List the top 3 improvements most likely to increase customer retention or referral likelihood. Assign an owner and delivery date to each.`,
          kpi: "Feature delivery on-time rate",
          target: "3 prioritized roadmap items with owners and delivery dates; 80% delivered on time",
          timeframe: "Month 2",
          order: 4,
        },
      ],
    });
  }

  // ── PILLAR 3: Team & Operational Capacity ──────────────────────────────────
  if (focusAreas.length === 0 || focusAreas.includes("Team")) {
    allPillars.push({
      title: "Team & Capacity",
      description: `Build the people systems and operational capacity at ${name} to sustain growth without founder bottlenecks.`,
      priority: 3,
      milestones: [
        {
          title: "Conduct a full time audit across one working week",
          description: `Log every task for 5 business days. Categorize by: only-I-can-do-this, delegate, eliminate. This is the source data for all capacity decisions.`,
          kpi: "% of founder time on high-leverage activities",
          target: "Founder time on low-leverage tasks reduced by 30% within 4 weeks of audit",
          timeframe: "Week 1",
          order: 1,
        },
        {
          title: "Delegate or eliminate the three lowest-leverage tasks",
          description: `Based on the time audit, remove or hand off the three activities that consume the most time relative to their business impact.`,
          kpi: "Hours per week reclaimed by founder",
          target: "Minimum 5 hours per week reclaimed within 30 days",
          timeframe: "Week 2–3",
          order: 2,
        },
        {
          title: `Define ${name}'s next critical hire or contractor role`,
          description: `Write a role brief: what they own, what 90-day success looks like, the skills required, and the budget available.`,
          kpi: "Time-to-fill for the defined role",
          target: isGrowth ? "Role filled within 45 days" : "Role brief completed; first candidate interviewed within 30 days",
          timeframe: "Month 1",
          order: 3,
        },
        {
          title: "Establish a weekly team operating rhythm with a standing agenda",
          description: `A 30-minute weekly sync with a clear structure prevents misalignment and keeps everyone moving toward the same goals.`,
          kpi: "Weekly standup consistency rate",
          target: "Weekly team sync maintained for 8 consecutive weeks with 100% attendance",
          timeframe: "Month 1",
          order: 4,
        },
      ],
    });
  }

  // ── PILLAR 4: Financial Clarity & Control ─────────────────────────────────
  if (focusAreas.length === 0 || focusAreas.includes("Finance")) {
    allPillars.push({
      title: "Financial Control",
      description: `Give ${name} the financial visibility to make confident decisions and protect runway through every growth stage.`,
      priority: 4,
      milestones: [
        {
          title: "Build a rolling 12-month cash flow forecast",
          description: `Project monthly revenue, expenses, and net cash position. Identify the earliest point where cash goes below a 3-month safety buffer.`,
          kpi: "Cash runway (months)",
          target: isPreRevenue ? "Minimum 6 months runway visibility at all times" : "Rolling 12-month forecast updated monthly; runway always above 6 months",
          timeframe: "Week 1–2",
          order: 1,
        },
        {
          title: "Identify and evaluate the top 3 cost line items for reduction",
          description: `For each major expense, ask: is this driving growth? Is there a lower-cost alternative? Can it be deferred without impact?`,
          kpi: "Monthly operating expense (OpEx) as % of revenue",
          target: isGrowth ? "OpEx as % of revenue reduced by 10% within 90 days" : "3 cost line items reviewed; at least 1 reduced or eliminated",
          timeframe: "Week 2",
          order: 2,
        },
        {
          title: "Implement a monthly financial review cadence",
          description: `Block 60 minutes at the end of each month to review actuals vs. forecast. This single habit improves the quality of every subsequent financial decision.`,
          kpi: "Forecast accuracy (actuals vs. plan variance %)",
          target: "Monthly review completed for 3 consecutive months; forecast variance below 15%",
          timeframe: "Month 1",
          order: 3,
        },
        {
          title: `Calculate ${name}'s unit economics: CAC, LTV, and gross margin`,
          description: `Even rough estimates of these three numbers will tell you whether the business model is fundamentally healthy and scalable.`,
          kpi: "LTV:CAC ratio",
          target: isGrowth ? "LTV:CAC ratio above 3:1" : "Unit economics calculated and documented; LTV:CAC pathway to 3:1 identified",
          timeframe: "Month 2",
          order: 4,
        },
      ],
    });
  }

  // ── PILLAR 5: Market Positioning & Brand ──────────────────────────────────
  if (focusAreas.includes("Marketing") && !focusAreas.includes("Sales")) {
    allPillars.push({
      title: "Market Positioning",
      description: `Build a clear, memorable position for ${name} in the market that makes choosing you the obvious decision.`,
      priority: 2,
      milestones: [
        {
          title: `Write ${name}'s one-sentence positioning statement`,
          description: `Structure: For [target customer], ${name} is the [category] that [unique benefit] because [reason to believe]. Test it with 5 prospects and refine.`,
          kpi: "Prospect recall rate of positioning statement",
          target: "Positioning statement tested with 5 prospects; 4 of 5 can accurately describe it back",
          timeframe: "Week 1",
          order: 1,
        },
        {
          title: `Audit ${name}'s website and top marketing channels for positioning alignment`,
          description: `Does every surface reflect the positioning statement? Score each channel 1–5 and fix the biggest gap this month.`,
          kpi: "Brand consistency score across channels",
          target: "All primary channels scoring 4+ on positioning alignment within 30 days",
          timeframe: "Week 2",
          order: 2,
        },
        {
          title: "Launch a consistent content cadence on the highest-ROI channel",
          description: `Commit to publishing once per week on the channel where ${name}'s ICP is most active. Consistency compounds — volume is secondary.`,
          kpi: "Organic inbound leads from content channel",
          target: "Weekly content published for 8 consecutive weeks; content driving 10% of inbound leads",
          timeframe: "Month 1",
          order: 3,
        },
      ],
    });
  }

  const maxPillars = focusAreas.length > 0 ? Math.min(focusAreas.length + 1, 4) : 3;
  const finalPillars = allPillars.slice(0, maxPillars);

  return { overview, pillars: finalPillars };
}
