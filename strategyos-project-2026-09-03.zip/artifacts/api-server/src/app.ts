import express, { type Express, type Request, type Response, type NextFunction } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import rateLimit from "express-rate-limit";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

// Behind Replit's reverse proxy — lets rate limiting see the real client IP.
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// General API limit: generous ceiling against runaway clients.
app.use(
  "/api",
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 300,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Too many requests. Please slow down and try again shortly." },
  }),
);

// Strict limit on expensive AI-generation endpoints (cost protection).
const aiLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "You've hit the AI generation limit. Please wait a few minutes and try again." },
  skip: (req) => req.method === "GET",
});
app.use(["/api/architect", "/api/venture", "/api/swot", "/api/reports"], aiLimiter);

app.use("/api", router);

// Friendly status page so the preview pane isn't blank when pointed at the API server
app.get("/", (_req, res) => {
  res.status(200).send(`<!DOCTYPE html>
<html><head><title>StrategyOS API</title><script src="https://cdn.tailwindcss.com"></script></head>
<body class="bg-slate-950 text-slate-100 flex items-center justify-center min-h-screen">
  <div class="text-center p-8">
    <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 mb-4">● API Server Running</div>
    <h1 class="text-2xl font-bold mb-2">StrategyOS API</h1>
    <p class="text-slate-400 text-sm">This is the backend service. To use the app, switch the preview dropdown to <span class="text-cyan-400 font-semibold">AI Strategy Platform</span>.</p>
  </div>
</body></html>`);
});

// Crash prevention: one bad request must never take the server down.
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  logger.error({ err, url: req.url }, "Unhandled request error");
  if (!res.headersSent) {
    res.status(500).json({ error: "Something went wrong on the server. Please try again." });
  }
});

export default app;
