import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import type { FullReport } from "@/types/report";

const STORAGE_KEY = "strategyos:saved_reports";
const MAX_SAVED = 20;

export interface SavedReport {
  id: string;
  companyName: string;
  timestamp: number;
  report: FullReport;
}

interface ReportContextType {
  report: FullReport | null;
  companyName: string;
  setReport: (report: FullReport, companyName: string) => void;
  clearReport: () => void;
  savedReports: SavedReport[];
  loadSavedReport: (saved: SavedReport) => void;
  deleteSavedReport: (id: string) => Promise<void>;
}

const ReportContext = createContext<ReportContextType | null>(null);

export function ReportProvider({ children }: { children: React.ReactNode }) {
  const [report, setReportState] = useState<FullReport | null>(null);
  const [companyName, setCompanyNameState] = useState<string>("");
  const [savedReports, setSavedReports] = useState<SavedReport[]>([]);

  // Load saved reports from AsyncStorage on mount
  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then((raw) => {
      if (!raw) return;
      try {
        const parsed = JSON.parse(raw) as SavedReport[];
        if (Array.isArray(parsed)) setSavedReports(parsed);
      } catch {
        // ignore malformed storage
      }
    });
  }, []);

  const persist = useCallback(async (reports: SavedReport[]) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch {
      // storage failure is non-fatal
    }
  }, []);

  const setReport = useCallback(
    (r: FullReport, name: string) => {
      setReportState(r);
      setCompanyNameState(name);

      // Auto-save to history — deduplicate by company name (case-insensitive), keep newest
      const entry: SavedReport = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        companyName: name,
        timestamp: Date.now(),
        report: r,
      };

      setSavedReports((prev) => {
        const filtered = prev.filter(
          (s) => s.companyName.toLowerCase() !== name.toLowerCase()
        );
        const next = [entry, ...filtered].slice(0, MAX_SAVED);
        persist(next);
        return next;
      });
    },
    [persist]
  );

  const clearReport = useCallback(() => {
    setReportState(null);
    setCompanyNameState("");
  }, []);

  const loadSavedReport = useCallback((saved: SavedReport) => {
    setReportState(saved.report);
    setCompanyNameState(saved.companyName);
  }, []);

  const deleteSavedReport = useCallback(
    async (id: string) => {
      setSavedReports((prev) => {
        const next = prev.filter((s) => s.id !== id);
        persist(next);
        return next;
      });
    },
    [persist]
  );

  return (
    <ReportContext.Provider
      value={{
        report,
        companyName,
        setReport,
        clearReport,
        savedReports,
        loadSavedReport,
        deleteSavedReport,
      }}
    >
      {children}
    </ReportContext.Provider>
  );
}

export function useReport() {
  const ctx = useContext(ReportContext);
  if (!ctx) throw new Error("useReport must be used within ReportProvider");
  return ctx;
}
