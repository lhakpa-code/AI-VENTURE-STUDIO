import React, { useRef, useState, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Platform,
  Alert,
} from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Swipeable } from "react-native-gesture-handler";
import { useColors } from "@/hooks/useColors";
import { useReport, type SavedReport } from "@/context/ReportContext";

// ─── Recent analysis row (swipeable) ──────────────────────────────────────────

function RecentRow({
  item,
  onOpen,
  onDelete,
  colors,
}: {
  item: SavedReport;
  onOpen: () => void;
  onDelete: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  const swipeRef = useRef<Swipeable>(null);

  const renderRightActions = () => (
    <TouchableOpacity
      style={[rowStyles.deleteAction, { backgroundColor: "#EF4444" }]}
      onPress={() => {
        swipeRef.current?.close();
        onDelete();
      }}
      activeOpacity={0.85}
    >
      <Ionicons name="trash-outline" size={20} color="#fff" />
    </TouchableOpacity>
  );

  const relative = formatRelative(item.timestamp);

  return (
    <Swipeable
      ref={swipeRef}
      renderRightActions={renderRightActions}
      rightThreshold={60}
      friction={2}
      overshootRight={false}
    >
      <TouchableOpacity
        style={[rowStyles.row, { backgroundColor: colors.card, borderColor: colors.border }]}
        onPress={onOpen}
        activeOpacity={0.75}
      >
        <View style={[rowStyles.iconWrap, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "25" }]}>
          <Ionicons name="analytics-outline" size={16} color={colors.primary} />
        </View>
        <View style={rowStyles.text}>
          <Text style={[rowStyles.name, { color: colors.foreground }]} numberOfLines={1}>
            {item.companyName}
          </Text>
          <Text style={[rowStyles.time, { color: colors.mutedForeground }]}>{relative}</Text>
        </View>
        <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
      </TouchableOpacity>
    </Swipeable>
  );
}

function formatRelative(ts: number): string {
  const diff = Date.now() - ts;
  const minutes = Math.floor(diff / 60_000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  return new Date(ts).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderWidth: 1,
    borderRadius: 12,
    marginBottom: 8,
  },
  iconWrap: {
    width: 34,
    height: 34,
    borderRadius: 9,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  text: { flex: 1, gap: 2 },
  name: { fontSize: 14, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  time: { fontSize: 12, fontFamily: "Inter_400Regular" },
  deleteAction: {
    width: 72,
    alignItems: "center",
    justifyContent: "center",
    borderRadius: 12,
    marginBottom: 8,
  },
});

// ─── Home screen ──────────────────────────────────────────────────────────────

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [company, setCompany] = useState("");
  const [context, setContext] = useState("");
  const [showContext, setShowContext] = useState(false);
  const contextRef = useRef<TextInput>(null);

  const { savedReports, loadSavedReport, deleteSavedReport } = useReport();

  const canRun = company.trim().length > 1;

  const handleRun = async () => {
    if (!canRun) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    router.push({
      pathname: "/analysis",
      params: { companyName: company.trim(), additionalContext: context.trim() },
    });
  };

  const handleOpen = useCallback(
    (item: SavedReport) => {
      loadSavedReport(item);
      router.push("/result");
    },
    [loadSavedReport]
  );

  const handleDelete = useCallback(
    (item: SavedReport) => {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      Alert.alert(
        "Delete report?",
        `Remove the "${item.companyName}" analysis from your history?`,
        [
          { text: "Cancel", style: "cancel" },
          {
            text: "Delete",
            style: "destructive",
            onPress: () => deleteSavedReport(item.id),
          },
        ]
      );
    },
    [deleteSavedReport]
  );

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const styles = makeStyles(colors);

  return (
    <ScrollView
      style={[styles.root, { paddingTop: topPad }]}
      contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 24 }]}
      keyboardShouldPersistTaps="handled"
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.logoWrap}>
          <Ionicons name="analytics" size={28} color={colors.primary} />
        </View>
        <View>
          <Text style={styles.appName}>StrategyOS</Text>
          <Text style={styles.tagline}>AI-powered competitive intelligence</Text>
        </View>
      </View>

      {/* Hero */}
      <View style={styles.hero}>
        <Text style={styles.heroTitle}>Analyse any company</Text>
        <Text style={styles.heroSub}>
          Three AI agents deliver a board-level SWOT, priorities, and 90-day plan
          in under 90 seconds.
        </Text>
      </View>

      {/* Input card */}
      <View style={styles.card}>
        <Text style={styles.inputLabel}>Company name</Text>
        <View style={styles.inputWrap}>
          <Ionicons name="business-outline" size={18} color={colors.mutedForeground} style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            value={company}
            onChangeText={setCompany}
            placeholder="e.g. OpenAI, Stripe, Nvidia…"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="words"
            returnKeyType="next"
            onSubmitEditing={() => {
              if (!showContext) setShowContext(true);
              else contextRef.current?.focus();
            }}
            testID="company-input"
          />
        </View>

        {/* Optional context toggle */}
        <TouchableOpacity
          style={styles.contextToggle}
          onPress={() => setShowContext((v) => !v)}
          activeOpacity={0.7}
        >
          <Ionicons
            name={showContext ? "chevron-up" : "add-circle-outline"}
            size={16}
            color={colors.primary}
          />
          <Text style={styles.contextToggleText}>
            {showContext ? "Hide context" : "Add context (optional)"}
          </Text>
        </TouchableOpacity>

        {showContext && (
          <>
            <Text style={[styles.inputLabel, { marginTop: 4 }]}>Additional context</Text>
            <View style={[styles.inputWrap, styles.textAreaWrap]}>
              <TextInput
                ref={contextRef}
                style={[styles.input, styles.textArea]}
                value={context}
                onChangeText={setContext}
                placeholder="e.g. Focus on AI strategy, recent fundraising, enterprise segment…"
                placeholderTextColor={colors.mutedForeground}
                multiline
                numberOfLines={3}
                textAlignVertical="top"
                returnKeyType="done"
              />
            </View>
          </>
        )}

        {/* Run button */}
        <TouchableOpacity
          style={[styles.runBtn, !canRun && styles.runBtnDisabled]}
          onPress={handleRun}
          disabled={!canRun}
          activeOpacity={0.85}
          testID="run-btn"
        >
          <Text style={styles.runBtnText}>Run Analysis</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Feature pills */}
      <View style={styles.pills}>
        {[
          { icon: "shield-checkmark-outline" as const, label: "SEC filings" },
          { icon: "stats-chart-outline" as const, label: "Financials" },
          { icon: "git-network-outline" as const, label: "Competitors" },
        ].map((f) => (
          <View key={f.label} style={styles.pill}>
            <Ionicons name={f.icon} size={14} color={colors.primary} />
            <Text style={styles.pillText}>{f.label}</Text>
          </View>
        ))}
      </View>

      {/* Venture Studio card */}
      <TouchableOpacity
        style={[styles.ventureCard, { backgroundColor: colors.card, borderColor: "#8B5CF6" + "30" }]}
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          router.push("/venture-studio" as any);
        }}
        activeOpacity={0.8}
      >
        <View style={[styles.ventureIconWrap, { backgroundColor: "#8B5CF6" + "15", borderColor: "#8B5CF6" + "30" }]}>
          <Ionicons name="flask-outline" size={20} color="#8B5CF6" />
        </View>
        <View style={styles.ventureText}>
          <Text style={[styles.ventureTitle, { color: colors.foreground }]}>Venture Studio</Text>
          <Text style={[styles.ventureSub, { color: colors.mutedForeground }]}>
            Business model · Financials · Pitch deck · GTM
          </Text>
        </View>
        <Ionicons name="arrow-forward" size={16} color={colors.mutedForeground} />
      </TouchableOpacity>

      {/* Recent Analyses */}
      {savedReports.length > 0 && (
        <View style={styles.recentSection}>
          <View style={styles.recentHeader}>
            <Ionicons name="time-outline" size={16} color={colors.mutedForeground} />
            <Text style={[styles.recentTitle, { color: colors.foreground }]}>Recent Analyses</Text>
            <Text style={[styles.recentHint, { color: colors.mutedForeground }]}>Swipe to delete</Text>
          </View>
          {savedReports.map((item) => (
            <RecentRow
              key={item.id}
              item={item}
              colors={colors}
              onOpen={() => handleOpen(item)}
              onDelete={() => handleDelete(item)}
            />
          ))}
        </View>
      )}
    </ScrollView>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: {
      flex: 1,
      backgroundColor: colors.background,
    },
    scroll: {
      flexGrow: 1,
      paddingHorizontal: 20,
      paddingTop: 20,
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      marginBottom: 32,
    },
    logoWrap: {
      width: 48,
      height: 48,
      borderRadius: 14,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      alignItems: "center",
      justifyContent: "center",
    },
    appName: {
      fontSize: 20,
      fontWeight: "700",
      color: colors.foreground,
      fontFamily: "Inter_700Bold",
    },
    tagline: {
      fontSize: 12,
      color: colors.mutedForeground,
      fontFamily: "Inter_400Regular",
    },
    hero: {
      marginBottom: 28,
    },
    heroTitle: {
      fontSize: 30,
      fontWeight: "800",
      color: colors.foreground,
      fontFamily: "Inter_700Bold",
      lineHeight: 36,
      marginBottom: 10,
    },
    heroSub: {
      fontSize: 15,
      color: colors.mutedForeground,
      fontFamily: "Inter_400Regular",
      lineHeight: 22,
    },
    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.border,
      padding: 20,
      marginBottom: 20,
    },
    inputLabel: {
      fontSize: 12,
      fontWeight: "600",
      color: colors.mutedForeground,
      fontFamily: "Inter_600SemiBold",
      textTransform: "uppercase",
      letterSpacing: 0.5,
      marginBottom: 8,
    },
    inputWrap: {
      flexDirection: "row",
      alignItems: "center",
      backgroundColor: colors.background,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: colors.border,
      paddingHorizontal: 14,
      marginBottom: 14,
    },
    inputIcon: {
      marginRight: 8,
    },
    input: {
      flex: 1,
      fontSize: 15,
      color: colors.foreground,
      fontFamily: "Inter_400Regular",
      paddingVertical: 13,
    },
    textAreaWrap: {
      alignItems: "flex-start",
      paddingVertical: 10,
    },
    textArea: {
      minHeight: 70,
      paddingVertical: 2,
    },
    contextToggle: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      marginBottom: 16,
      alignSelf: "flex-start",
    },
    contextToggleText: {
      fontSize: 13,
      color: colors.primary,
      fontFamily: "Inter_500Medium",
    },
    runBtn: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      backgroundColor: colors.primary,
      borderRadius: 12,
      paddingVertical: 15,
      marginTop: 4,
    },
    runBtnDisabled: {
      opacity: 0.35,
    },
    runBtnText: {
      fontSize: 16,
      fontWeight: "700",
      color: "#fff",
      fontFamily: "Inter_700Bold",
    },
    pills: {
      flexDirection: "row",
      gap: 8,
      flexWrap: "wrap",
      marginBottom: 32,
    },
    pill: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 20,
      paddingHorizontal: 12,
      paddingVertical: 7,
    },
    pillText: {
      fontSize: 12,
      color: colors.mutedForeground,
      fontFamily: "Inter_500Medium",
    },
    recentSection: {
      gap: 0,
    },
    recentHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 8,
      marginBottom: 12,
    },
    recentTitle: {
      flex: 1,
      fontSize: 15,
      fontWeight: "700" as const,
      fontFamily: "Inter_700Bold",
    },
    recentHint: {
      fontSize: 11,
      fontFamily: "Inter_400Regular",
    },
    ventureCard: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      padding: 16,
      borderRadius: 14,
      borderWidth: 1,
      marginBottom: 24,
    },
    ventureIconWrap: {
      width: 40,
      height: 40,
      borderRadius: 11,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    },
    ventureText: { flex: 1 },
    ventureTitle: {
      fontSize: 15,
      fontWeight: "600",
      fontFamily: "Inter_600SemiBold",
    },
    ventureSub: {
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: 2,
    },
  });
}
