import React, { useEffect, useRef, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  Platform,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  withSequence,
  Easing,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { fetch } from "expo/fetch";
import * as Haptics from "expo-haptics";
import { useKeepAwake } from "expo-keep-awake";
import { useColors } from "@/hooks/useColors";
import { useReport } from "@/context/ReportContext";
import type { SSEEvent, FullReport } from "@/types/report";

type AgentPhase = "idle" | "running" | "complete" | "error";

interface AgentState {
  phase: AgentPhase;
  label: string;
  role: string;
  currentDetail: string;
  summary: Record<string, string>;
}

const AGENT_DEFAULTS = {
  1: { label: "Data Aggregator", role: "SEC filings · News · Sentiment · Competitors", color: "#8B5CF6" },
  2: { label: "Financial Analyst", role: "Revenue · Margins · Growth · Funding", color: "#3B82F6" },
  3: { label: "Senior Consultant", role: "SWOT synthesis · Citations · Strategy", color: "#10B981" },
} as const;

function makeDefaultAgents(): Record<1 | 2 | 3, AgentState> {
  return {
    1: { phase: "idle", label: AGENT_DEFAULTS[1].label, role: AGENT_DEFAULTS[1].role, currentDetail: "", summary: {} },
    2: { phase: "idle", label: AGENT_DEFAULTS[2].label, role: AGENT_DEFAULTS[2].role, currentDetail: "", summary: {} },
    3: { phase: "idle", label: AGENT_DEFAULTS[3].label, role: AGENT_DEFAULTS[3].role, currentDetail: "", summary: {} },
  };
}

// Spinner animation component — extracted to avoid hooks-in-map
function SpinnerIcon({ color }: { color: string }) {
  const rotation = useSharedValue(0);
  useEffect(() => {
    rotation.value = withRepeat(withTiming(360, { duration: 900, easing: Easing.linear }), -1, false);
  }, [rotation]);
  const animStyle = useAnimatedStyle(() => ({ transform: [{ rotate: `${rotation.value}deg` }] }));
  return (
    <Animated.View style={animStyle}>
      <Ionicons name="sync" size={14} color={color} />
    </Animated.View>
  );
}

// Pulsing dot for "running" state
function PulseDot({ color }: { color: string }) {
  const opacity = useSharedValue(1);
  useEffect(() => {
    opacity.value = withRepeat(withSequence(withTiming(0.3, { duration: 600 }), withTiming(1, { duration: 600 })), -1, false);
  }, [opacity]);
  const s = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return <Animated.View style={[{ width: 6, height: 6, borderRadius: 3, backgroundColor: color }, s]} />;
}

function AgentCard({ n, state, colors }: { n: 1 | 2 | 3; state: AgentState; colors: ReturnType<typeof useColors> }) {
  const def = AGENT_DEFAULTS[n];
  const isDone = state.phase === "complete";
  const isRunning = state.phase === "running";

  return (
    <View style={[
      cardStyles.card,
      { borderColor: isDone || isRunning ? def.color + "40" : colors.border, backgroundColor: colors.card },
    ]}>
      <View style={cardStyles.row}>
        {/* Icon bubble */}
        <View style={[cardStyles.iconBubble, { backgroundColor: def.color + "15", borderColor: def.color + "30" }]}>
          {isDone
            ? <Ionicons name="checkmark" size={16} color={def.color} />
            : isRunning
              ? <SpinnerIcon color={def.color} />
              : <Ionicons name="ellipsis-horizontal" size={16} color={colors.mutedForeground} />
          }
        </View>

        {/* Text */}
        <View style={cardStyles.textWrap}>
          <View style={cardStyles.labelRow}>
            <View style={[cardStyles.agentBadge, { backgroundColor: (isDone || isRunning) ? def.color + "20" : colors.background, borderColor: (isDone || isRunning) ? def.color + "40" : colors.border }]}>
              <Text style={[cardStyles.agentNum, { color: (isDone || isRunning) ? def.color : colors.mutedForeground }]}>Agent {n}</Text>
            </View>
            {isRunning && <PulseDot color={def.color} />}
          </View>
          <Text style={[cardStyles.name, { color: isDone || isRunning ? colors.foreground : colors.mutedForeground }]}>
            {state.label}
          </Text>
          <Text style={[cardStyles.role, { color: colors.mutedForeground }]}>{state.role}</Text>
          {isRunning && state.currentDetail !== "" && (
            <Text style={[cardStyles.detail, { color: colors.mutedForeground }]} numberOfLines={2}>
              {state.currentDetail}
            </Text>
          )}
          {isDone && Object.keys(state.summary).length > 0 && (
            <View style={cardStyles.summaryRow}>
              {Object.entries(state.summary).slice(0, 3).map(([k, v]) => (
                <View key={k} style={[cardStyles.summaryChip, { backgroundColor: colors.background, borderColor: colors.border }]}>
                  <Text style={[cardStyles.summaryKey, { color: colors.mutedForeground }]}>{k}:</Text>
                  <Text style={[cardStyles.summaryVal, { color: colors.foreground }]}>{v}</Text>
                </View>
              ))}
            </View>
          )}
        </View>
      </View>
    </View>
  );
}

const cardStyles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    marginBottom: 10,
  },
  row: { flexDirection: "row", gap: 12 },
  iconBubble: {
    width: 36,
    height: 36,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    marginTop: 2,
  },
  textWrap: { flex: 1 },
  labelRow: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 4 },
  agentBadge: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 8, paddingVertical: 2 },
  agentNum: { fontSize: 11, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  name: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold", marginBottom: 2 },
  role: { fontSize: 11, fontFamily: "Inter_400Regular", lineHeight: 16 },
  detail: { fontSize: 11, fontFamily: "Inter_400Regular", marginTop: 6, lineHeight: 16 },
  summaryRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 },
  summaryChip: { flexDirection: "row", gap: 3, borderWidth: 1, borderRadius: 20, paddingHorizontal: 8, paddingVertical: 3 },
  summaryKey: { fontSize: 10, fontFamily: "Inter_400Regular" },
  summaryVal: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
});

export default function AnalysisScreen() {
  useKeepAwake();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ companyName: string; additionalContext: string }>();
  const { setReport } = useReport();

  const [agents, setAgents] = useState<Record<1 | 2 | 3, AgentState>>(makeDefaultAgents());
  const [done, setDone] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const companyName = params.companyName ?? "";
  const additionalContext = params.additionalContext ?? "";

  const progressWidth = useSharedValue(0);
  const progressStyle = useAnimatedStyle(() => ({ width: `${progressWidth.value}%` as any }));

  useEffect(() => {
    progressWidth.value = withTiming((done / 3) * 100, { duration: 600 });
  }, [done, progressWidth]);

  const updateAgent = (n: 1 | 2 | 3, patch: Partial<AgentState>) => {
    setAgents((prev) => ({ ...prev, [n]: { ...prev[n], ...patch } }));
  };

  useEffect(() => {
    const controller = new AbortController();
    abortRef.current = controller;

    async function run() {
      const domain = process.env.EXPO_PUBLIC_DOMAIN;
      const url = domain
        ? `https://${domain}/api/swot/generate`
        : "/api/swot/generate";

      try {
        const response = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ companyName, additionalContext }),
          signal: controller.signal,
        });

        if (!response.ok) {
          throw new Error(`Server error ${response.status}`);
        }

        const reader = response.body!.getReader();
        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done: streamDone, value } = await reader.read();
          if (streamDone) break;
          buffer += decoder.decode(value, { stream: true });
          const parts = buffer.split("\n\n");
          buffer = parts.pop() ?? "";

          for (const part of parts) {
            const line = part.trim();
            if (!line.startsWith("data: ")) continue;
            try {
              const event: SSEEvent = JSON.parse(line.slice(6));
              handleEvent(event);
            } catch {
              // skip malformed
            }
          }
        }
      } catch (err: any) {
        if (err?.name === "AbortError") return;
        setError(err?.message ?? "Analysis failed. Please try again.");
      }
    }

    run();
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function handleEvent(event: SSEEvent) {
    switch (event.type) {
      case "agent_start":
        updateAgent(event.agent, { phase: "running", label: event.label, role: event.role });
        break;
      case "agent_update":
        updateAgent(event.agent, { currentDetail: event.detail });
        break;
      case "agent_complete":
        updateAgent(event.agent, { phase: "complete", summary: event.summary });
        setDone((d) => d + 1);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        break;
      case "report":
        setReport(event.data, companyName);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/result");
        break;
      case "error":
        setError(event.message);
        break;
    }
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const styles = makeStyles(colors);

  if (error) {
    return (
      <View style={[styles.root, { paddingTop: topPad }]}>
        <View style={styles.errorWrap}>
          <View style={[styles.errorIcon, { backgroundColor: "#EF4444" + "15", borderColor: "#EF4444" + "30" }]}>
            <Ionicons name="warning-outline" size={32} color="#EF4444" />
          </View>
          <Text style={styles.errorTitle}>Analysis failed</Text>
          <Text style={styles.errorMsg}>{error}</Text>
          <TouchableOpacity style={[styles.retryBtn, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => router.back()} activeOpacity={0.7}>
            <Ionicons name="arrow-back" size={16} color={colors.foreground} />
            <Text style={[styles.retryTxt, { color: colors.foreground }]}>Go back</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.root, { paddingTop: topPad }]}>
      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 24 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Title */}
        <View style={styles.titleBlock}>
          <View style={[styles.brainIcon, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "30" }]}>
            <Ionicons name="analytics" size={26} color={colors.primary} />
          </View>
          <Text style={styles.title}>Analysing {companyName}</Text>
          <Text style={styles.subtitle}>
            {done === 0 ? "Spinning up the intelligence pipeline…" : done === 3 ? "Finalising your report…" : `${done} of 3 agents complete`}
          </Text>
        </View>

        {/* Progress bar */}
        <View style={[styles.progressTrack, { backgroundColor: colors.muted }]}>
          <Animated.View style={[styles.progressFill, progressStyle, { backgroundColor: colors.primary }]} />
        </View>

        {/* Agent cards */}
        <View style={styles.cards}>
          {([1, 2, 3] as const).map((n) => (
            <AgentCard key={n} n={n} state={agents[n]} colors={colors} />
          ))}
        </View>

        <Text style={[styles.hint, { color: colors.mutedForeground }]}>Usually takes 60–90 seconds</Text>
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    scroll: { flexGrow: 1, paddingHorizontal: 20, paddingTop: 32 },
    titleBlock: { alignItems: "center", marginBottom: 28 },
    brainIcon: {
      width: 56,
      height: 56,
      borderRadius: 16,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 16,
    },
    title: {
      fontSize: 22,
      fontWeight: "800" as const,
      color: colors.foreground,
      fontFamily: "Inter_700Bold",
      textAlign: "center",
      marginBottom: 6,
    },
    subtitle: {
      fontSize: 14,
      color: colors.mutedForeground,
      fontFamily: "Inter_400Regular",
      textAlign: "center",
    },
    progressTrack: {
      height: 4,
      borderRadius: 2,
      marginBottom: 24,
      overflow: "hidden",
    },
    progressFill: { height: 4, borderRadius: 2 },
    cards: { gap: 0 },
    hint: {
      textAlign: "center",
      fontSize: 12,
      fontFamily: "Inter_400Regular",
      marginTop: 20,
    },
    errorWrap: { flex: 1, alignItems: "center", justifyContent: "center", padding: 32, gap: 12 },
    errorIcon: { width: 72, height: 72, borderRadius: 20, borderWidth: 1, alignItems: "center", justifyContent: "center", marginBottom: 4 },
    errorTitle: { fontSize: 20, fontWeight: "700" as const, color: colors.foreground, fontFamily: "Inter_700Bold" },
    errorMsg: { fontSize: 14, color: colors.mutedForeground, textAlign: "center", fontFamily: "Inter_400Regular", lineHeight: 20 },
    retryBtn: { flexDirection: "row", alignItems: "center", gap: 8, borderWidth: 1, borderRadius: 12, paddingHorizontal: 20, paddingVertical: 12, marginTop: 8 },
    retryTxt: { fontSize: 14, fontFamily: "Inter_500Medium" },
  });
}
