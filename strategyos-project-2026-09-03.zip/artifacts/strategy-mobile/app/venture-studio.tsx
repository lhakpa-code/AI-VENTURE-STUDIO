import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Platform,
  ActivityIndicator,
  Alert,
} from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { fetch } from "expo/fetch";
import { useColors } from "@/hooks/useColors";

// ─── Types ────────────────────────────────────────────────────────────────────

interface VentureInput {
  company_name: string;
  business_description: string;
  target_market: string;
  pricing_tier: string;
}

interface AgentResult {
  status: "idle" | "loading" | "done" | "error";
  data: unknown;
  error?: string;
}

interface VentureResults {
  businessModel: AgentResult;
  financialModel: AgentResult;
  pitchDeck: AgentResult;
  prototypeSpec: AgentResult;
  gtmCampaign: AgentResult;
}

type TabKey = keyof VentureResults;

const TABS: { key: TabKey; label: string; icon: string }[] = [
  { key: "businessModel", label: "Business", icon: "briefcase-outline" },
  { key: "financialModel", label: "Financials", icon: "trending-up-outline" },
  { key: "pitchDeck", label: "Pitch Deck", icon: "easel-outline" },
  { key: "prototypeSpec", label: "Prototype", icon: "phone-portrait-outline" },
  { key: "gtmCampaign", label: "GTM", icon: "megaphone-outline" },
];

const AGENT_COLORS: Record<TabKey, string> = {
  businessModel: "#8B5CF6",
  financialModel: "#3B82F6",
  pitchDeck: "#10B981",
  prototypeSpec: "#F59E0B",
  gtmCampaign: "#EF4444",
};

function makeDefaultResults(): VentureResults {
  return {
    businessModel: { status: "idle", data: null },
    financialModel: { status: "idle", data: null },
    pitchDeck: { status: "idle", data: null },
    prototypeSpec: { status: "idle", data: null },
    gtmCampaign: { status: "idle", data: null },
  };
}

// ─── API helpers ──────────────────────────────────────────────────────────────

function getBaseUrl(): string {
  const domain = process.env.EXPO_PUBLIC_DOMAIN;
  return domain ? `https://${domain}` : "";
}

async function callEndpoint(path: string, body: object): Promise<unknown> {
  const res = await fetch(`${getBaseUrl()}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: "Request failed" }));
    throw new Error((err as { error?: string }).error ?? `HTTP ${res.status}`);
  }
  return res.json();
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function AgentStatus({
  tabKey,
  result,
  colors,
}: {
  tabKey: TabKey;
  result: AgentResult;
  colors: ReturnType<typeof useColors>;
}) {
  const accentColor = AGENT_COLORS[tabKey];
  const tab = TABS.find((t) => t.key === tabKey)!;
  const { status } = result;

  return (
    <View
      style={[
        agentStyles.card,
        {
          backgroundColor: colors.card,
          borderColor:
            status === "done"
              ? accentColor + "40"
              : status === "error"
              ? "#EF444440"
              : colors.border,
        },
      ]}
    >
      <View
        style={[
          agentStyles.iconBubble,
          { backgroundColor: accentColor + "15", borderColor: accentColor + "30" },
        ]}
      >
        {status === "loading" ? (
          <ActivityIndicator size="small" color={accentColor} />
        ) : status === "done" ? (
          <Ionicons name="checkmark" size={16} color={accentColor} />
        ) : status === "error" ? (
          <Ionicons name="close" size={16} color="#EF4444" />
        ) : (
          <Ionicons name={tab.icon as any} size={16} color={colors.mutedForeground} />
        )}
      </View>
      <View style={agentStyles.textWrap}>
        <Text style={[agentStyles.label, { color: colors.foreground }]}>{tab.label}</Text>
        <Text style={[agentStyles.status, { color: colors.mutedForeground }]}>
          {status === "idle"
            ? "Waiting…"
            : status === "loading"
            ? "Generating…"
            : status === "done"
            ? "Complete"
            : `Error: ${result.error ?? "failed"}`}
        </Text>
      </View>
    </View>
  );
}

const agentStyles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    marginBottom: 8,
  },
  iconBubble: {
    width: 36,
    height: 36,
    borderRadius: 10,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  textWrap: { flex: 1 },
  label: { fontSize: 14, fontWeight: "600", fontFamily: "Inter_600SemiBold" },
  status: { fontSize: 12, fontFamily: "Inter_400Regular", marginTop: 2 },
});

// ─── Result renderers ─────────────────────────────────────────────────────────

function Section({
  title,
  children,
  colors,
}: {
  title: string;
  children: React.ReactNode;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={[resultStyles.section, { borderColor: colors.border }]}>
      <Text style={[resultStyles.sectionTitle, { color: colors.mutedForeground }]}>{title}</Text>
      {children}
    </View>
  );
}

function Value({ text, colors }: { text: unknown; colors: ReturnType<typeof useColors> }) {
  const str =
    typeof text === "string"
      ? text
      : Array.isArray(text)
      ? text.map((v) => (typeof v === "string" ? v : JSON.stringify(v))).join("\n")
      : typeof text === "object" && text !== null
      ? Object.entries(text as object)
          .map(([k, v]) => `${k}: ${v}`)
          .join("\n")
      : String(text ?? "");
  return <Text style={[resultStyles.valueText, { color: colors.foreground }]}>{str}</Text>;
}

function BulletList({ items, colors }: { items: unknown[]; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={{ gap: 4 }}>
      {items.map((item, i) => (
        <View key={i} style={resultStyles.bulletRow}>
          <Text style={[resultStyles.bullet, { color: colors.primary }]}>•</Text>
          <Text style={[resultStyles.bulletText, { color: colors.foreground }]}>
            {typeof item === "string" ? item : JSON.stringify(item)}
          </Text>
        </View>
      ))}
    </View>
  );
}

function BusinessModelView({
  data,
  colors,
}: {
  data: Record<string, unknown>;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 0 }}>
      {Boolean(data.recommended_model) && (
        <Section title="Recommended Model" colors={colors}>
          <Value text={data.recommended_model} colors={colors} />
        </Section>
      )}
      {Array.isArray(data.monetization_streams) && (
        <Section title="Monetization Streams" colors={colors}>
          <BulletList items={data.monetization_streams} colors={colors} />
        </Section>
      )}
      {Boolean(data.pricing_strategy) && (
        <Section title="Pricing Strategy" colors={colors}>
          <Value text={data.pricing_strategy} colors={colors} />
        </Section>
      )}
      {Boolean(data.unit_economics) && (
        <Section title="Unit Economics" colors={colors}>
          <Value text={data.unit_economics} colors={colors} />
        </Section>
      )}
    </View>
  );
}

function FinancialModelView({
  data,
  colors,
}: {
  data: Record<string, unknown>;
  colors: ReturnType<typeof useColors>;
}) {
  const years: [string, Record<string, number>][] = (
    ["year_1", "year_2", "year_3"] as const
  )
    .filter((y) => data[y])
    .map((y) => [y, data[y] as Record<string, number>]);

  return (
    <View style={{ gap: 0 }}>
      {years.map(([yearKey, yearData]) => (
        <Section key={yearKey} title={yearKey.replace("_", " ").toUpperCase()} colors={colors}>
          {Object.entries(yearData).map(([k, v]) => (
            <View key={k} style={resultStyles.kv}>
              <Text style={[resultStyles.kvKey, { color: colors.mutedForeground }]}>
                {k.replace(/_/g, " ")}
              </Text>
              <Text style={[resultStyles.kvVal, { color: colors.foreground }]}>
                {typeof v === "number" && k !== "paid_customers"
                  ? `$${v.toLocaleString()}`
                  : String(v)}
              </Text>
            </View>
          ))}
        </Section>
      ))}
      {Array.isArray(data.key_assumptions) && (
        <Section title="Key Assumptions" colors={colors}>
          <BulletList items={data.key_assumptions} colors={colors} />
        </Section>
      )}
    </View>
  );
}

function PitchDeckView({
  data,
  colors,
}: {
  data: Record<string, unknown>;
  colors: ReturnType<typeof useColors>;
}) {
  const slides = Array.isArray(data.slides)
    ? data.slides
    : Array.isArray((data as any)[Object.keys(data)[0]])
    ? (data as any)[Object.keys(data)[0]]
    : [];

  return (
    <View style={{ gap: 0 }}>
      {(slides as any[]).map((slide: any, i: number) => (
        <Section
          key={i}
          title={`Slide ${slide.slide_number ?? i + 1} — ${slide.title ?? ""}`}
          colors={colors}
        >
          {slide.headline && (
            <Text style={[resultStyles.pitchHeadline, { color: colors.foreground }]}>
              {slide.headline}
            </Text>
          )}
          {Array.isArray(slide.bullet_points) && (
            <BulletList items={slide.bullet_points} colors={colors} />
          )}
        </Section>
      ))}
    </View>
  );
}

function PrototypeSpecView({
  data,
  colors,
}: {
  data: Record<string, unknown>;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 0 }}>
      {Array.isArray(data.core_user_flow) && (
        <Section title="Core User Flow" colors={colors}>
          {(data.core_user_flow as string[]).map((step, i) => (
            <View key={i} style={resultStyles.bulletRow}>
              <Text style={[resultStyles.stepNumber, { color: colors.primary }]}>{i + 1}.</Text>
              <Text style={[resultStyles.bulletText, { color: colors.foreground }]}>{step}</Text>
            </View>
          ))}
        </Section>
      )}
      {Array.isArray(data.key_screens) && (
        <Section title="Key Screens" colors={colors}>
          {(data.key_screens as any[]).map((screen: any, i: number) => (
            <View
              key={i}
              style={[resultStyles.screenCard, { backgroundColor: colors.background, borderColor: colors.border }]}
            >
              <Text style={[resultStyles.screenTitle, { color: colors.primary }]}>
                {screen.title ?? `Screen ${i + 1}`}
              </Text>
              {screen.components && (
                <Text style={[resultStyles.valueText, { color: colors.foreground }]}>
                  {Array.isArray(screen.components)
                    ? screen.components.join(", ")
                    : String(screen.components)}
                </Text>
              )}
              {screen.key_actions && (
                <Text style={[resultStyles.valueText, { color: colors.mutedForeground }]}>
                  Actions:{" "}
                  {Array.isArray(screen.key_actions)
                    ? screen.key_actions.join(", ")
                    : String(screen.key_actions)}
                </Text>
              )}
            </View>
          ))}
        </Section>
      )}
    </View>
  );
}

function GtmCampaignView({
  data,
  colors,
}: {
  data: Record<string, unknown>;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ gap: 0 }}>
      {Boolean(data.ideal_customer_profile) && (
        <Section title="Ideal Customer Profile" colors={colors}>
          <Value text={data.ideal_customer_profile} colors={colors} />
        </Section>
      )}
      {Array.isArray(data.cold_email_sequence) && (
        <Section title="Cold Email Sequence" colors={colors}>
          {(data.cold_email_sequence as any[]).map((email: any, i: number) => (
            <View
              key={i}
              style={[resultStyles.screenCard, { backgroundColor: colors.background, borderColor: colors.border }]}
            >
              <Text style={[resultStyles.screenTitle, { color: colors.primary }]}>
                {email.Subject ?? email.subject ?? `Email ${i + 1}`}
              </Text>
              <Text style={[resultStyles.valueText, { color: colors.foreground }]}>
                {email.Body ?? email.body ?? ""}
              </Text>
            </View>
          ))}
        </Section>
      )}
      {Array.isArray(data.linkedin_outreach_sequence) && (
        <Section title="LinkedIn Outreach" colors={colors}>
          {(data.linkedin_outreach_sequence as any[]).map((msg: any, i: number) => (
            <View
              key={i}
              style={[resultStyles.screenCard, { backgroundColor: colors.background, borderColor: colors.border }]}
            >
              <Text style={[resultStyles.valueText, { color: colors.foreground }]}>
                {typeof msg === "string" ? msg : msg.message ?? msg.body ?? JSON.stringify(msg)}
              </Text>
            </View>
          ))}
        </Section>
      )}
      {Array.isArray(data.launch_channels) && (
        <Section title="Launch Channels" colors={colors}>
          <BulletList items={data.launch_channels} colors={colors} />
        </Section>
      )}
    </View>
  );
}

const resultStyles = StyleSheet.create({
  section: {
    borderBottomWidth: 1,
    paddingVertical: 14,
    gap: 8,
  },
  sectionTitle: {
    fontSize: 11,
    fontWeight: "600",
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 0.6,
  },
  valueText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 20,
  },
  bulletRow: {
    flexDirection: "row",
    gap: 8,
    alignItems: "flex-start",
  },
  bullet: {
    fontSize: 14,
    lineHeight: 20,
    fontFamily: "Inter_400Regular",
    flexShrink: 0,
  },
  stepNumber: {
    fontSize: 14,
    lineHeight: 20,
    fontFamily: "Inter_600SemiBold",
    flexShrink: 0,
    width: 18,
  },
  bulletText: {
    flex: 1,
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 20,
  },
  kv: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  kvKey: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    textTransform: "capitalize",
    flex: 1,
  },
  kvVal: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    textAlign: "right",
  },
  pitchHeadline: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    lineHeight: 22,
    marginBottom: 6,
  },
  screenCard: {
    borderRadius: 10,
    borderWidth: 1,
    padding: 12,
    gap: 6,
    marginBottom: 8,
  },
  screenTitle: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
});

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function VentureStudioScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  const [input, setInput] = useState<VentureInput>({
    company_name: "",
    business_description: "",
    target_market: "",
    pricing_tier: "Subscription SaaS",
  });

  const [phase, setPhase] = useState<"form" | "running" | "results">("form");
  const [activeTab, setActiveTab] = useState<TabKey>("businessModel");
  const [results, setResults] = useState<VentureResults>(makeDefaultResults());

  const canRun =
    input.company_name.trim().length > 1 &&
    input.business_description.trim().length > 5 &&
    input.target_market.trim().length > 1;

  const handleRun = async () => {
    if (!canRun) return;
    await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const fresh = makeDefaultResults();
    // Mark all as loading
    const all = makeDefaultResults();
    Object.keys(all).forEach((k) => {
      (all as any)[k] = { status: "loading", data: null };
    });
    setResults(all);
    setPhase("running");
    setActiveTab("businessModel");

    const baseBody = {
      company_name: input.company_name.trim(),
      business_description: input.business_description.trim(),
      target_market: input.target_market.trim(),
      pricing_tier: input.pricing_tier.trim() || "Subscription SaaS",
    };

    // Run all 5 endpoints in parallel
    const endpoints: [TabKey, string][] = [
      ["businessModel", "/api/venture/business-model"],
      ["financialModel", "/api/venture/financial-model"],
      ["pitchDeck", "/api/venture/pitch-deck"],
      ["prototypeSpec", "/api/venture/prototype-spec"],
      ["gtmCampaign", "/api/venture/gtm-campaign"],
    ];

    const settled = await Promise.allSettled(
      endpoints.map(([, path]) => callEndpoint(path, baseBody))
    );

    const final = makeDefaultResults();
    endpoints.forEach(([key], i) => {
      const r = settled[i];
      if (r.status === "fulfilled") {
        (final as any)[key] = { status: "done", data: r.value };
      } else {
        (final as any)[key] = {
          status: "error",
          data: null,
          error: r.reason?.message ?? "Failed",
        };
      }
    });

    setResults(final);
    setPhase("results");
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const styles = makeStyles(colors);

  // ── FORM ──────────────────────────────────────────────────────────────────
  if (phase === "form") {
    return (
      <ScrollView
        style={[styles.root, { paddingTop: topPad }]}
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 24 }]}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {/* Back button + header */}
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()} activeOpacity={0.7}>
          <Ionicons name="arrow-back" size={20} color={colors.foreground} />
        </TouchableOpacity>

        <View style={styles.header}>
          <View style={[styles.logoWrap, { borderColor: "#8B5CF6" + "40", backgroundColor: "#8B5CF6" + "15" }]}>
            <Ionicons name="flask-outline" size={26} color="#8B5CF6" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.appName}>Venture Studio</Text>
            <Text style={styles.tagline}>5-agent startup analysis pipeline</Text>
          </View>
        </View>

        <Text style={styles.heroTitle}>Build your venture{"\n"}intelligence report</Text>
        <Text style={styles.heroSub}>
          Business model, financials, pitch deck, prototype spec, and GTM campaign — generated in parallel.
        </Text>

        {/* Input card */}
        <View style={styles.card}>
          <InputField
            label="Company name"
            icon="business-outline"
            value={input.company_name}
            onChange={(v) => setInput((p) => ({ ...p, company_name: v }))}
            placeholder="e.g. AcmeCo, StealthAI…"
            colors={colors}
          />
          <InputField
            label="Business description"
            icon="document-text-outline"
            value={input.business_description}
            onChange={(v) => setInput((p) => ({ ...p, business_description: v }))}
            placeholder="What does the company do? Who does it serve?"
            multiline
            colors={colors}
          />
          <InputField
            label="Target market"
            icon="people-outline"
            value={input.target_market}
            onChange={(v) => setInput((p) => ({ ...p, target_market: v }))}
            placeholder="e.g. Series A SaaS founders in North America"
            colors={colors}
          />
          <InputField
            label="Pricing model (optional)"
            icon="pricetag-outline"
            value={input.pricing_tier}
            onChange={(v) => setInput((p) => ({ ...p, pricing_tier: v }))}
            placeholder="e.g. Subscription SaaS, Marketplace, Freemium"
            colors={colors}
          />

          <TouchableOpacity
            style={[styles.runBtn, !canRun && styles.runBtnDisabled]}
            onPress={handleRun}
            disabled={!canRun}
            activeOpacity={0.85}
          >
            <Ionicons name="flask" size={18} color="#fff" />
            <Text style={styles.runBtnText}>Run Venture Analysis</Text>
          </TouchableOpacity>
        </View>

        {/* Feature pills */}
        <View style={styles.pills}>
          {[
            { icon: "briefcase-outline" as const, label: "Business Model" },
            { icon: "trending-up-outline" as const, label: "Financials" },
            { icon: "easel-outline" as const, label: "Pitch Deck" },
            { icon: "phone-portrait-outline" as const, label: "Prototype" },
            { icon: "megaphone-outline" as const, label: "GTM Campaign" },
          ].map((f) => (
            <View key={f.label} style={styles.pill}>
              <Ionicons name={f.icon} size={13} color="#8B5CF6" />
              <Text style={styles.pillText}>{f.label}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    );
  }

  // ── RUNNING ───────────────────────────────────────────────────────────────
  if (phase === "running") {
    return (
      <ScrollView
        style={[styles.root, { paddingTop: topPad }]}
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 24 }]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.runningHeader}>
          <View style={[styles.logoWrap, { borderColor: "#8B5CF6" + "40", backgroundColor: "#8B5CF6" + "15" }]}>
            <Ionicons name="flask-outline" size={26} color="#8B5CF6" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.appName}>Venture Studio</Text>
            <Text style={[styles.tagline, { color: "#8B5CF6" }]}>
              Agents running in parallel…
            </Text>
          </View>
        </View>

        <Text style={[styles.companyLabel, { color: colors.foreground }]}>
          {input.company_name}
        </Text>

        <View style={{ gap: 0, marginTop: 8 }}>
          {TABS.map((tab) => (
            <AgentStatus
              key={tab.key}
              tabKey={tab.key}
              result={results[tab.key]}
              colors={colors}
            />
          ))}
        </View>

        <Text style={[styles.runningHint, { color: colors.mutedForeground }]}>
          This usually takes 30–60 seconds. Keep this screen open.
        </Text>
      </ScrollView>
    );
  }

  // ── RESULTS ───────────────────────────────────────────────────────────────
  const activeResult = results[activeTab];
  const accentColor = AGENT_COLORS[activeTab];

  return (
    <View style={[styles.root, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={[styles.resultsHeader, { paddingTop: 12 }]}>
        <TouchableOpacity
          onPress={() => setPhase("form")}
          style={styles.backBtn}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.appName} numberOfLines={1}>
            {input.company_name}
          </Text>
          <Text style={styles.tagline}>Venture Studio Report</Text>
        </View>
        <TouchableOpacity
          onPress={handleRun}
          style={[styles.rerunBtn, { borderColor: colors.border }]}
          activeOpacity={0.75}
        >
          <Ionicons name="refresh-outline" size={16} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      {/* Tab bar */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={[styles.tabBar, { borderColor: colors.border }]}
        contentContainerStyle={styles.tabBarContent}
      >
        {TABS.map((tab) => {
          const isActive = activeTab === tab.key;
          const tabColor = AGENT_COLORS[tab.key];
          const result = results[tab.key];
          return (
            <TouchableOpacity
              key={tab.key}
              style={[
                styles.tab,
                isActive && { borderBottomColor: tabColor, borderBottomWidth: 2 },
              ]}
              onPress={() => setActiveTab(tab.key)}
              activeOpacity={0.7}
            >
              <Ionicons
                name={tab.icon as any}
                size={14}
                color={isActive ? tabColor : colors.mutedForeground}
              />
              <Text
                style={[
                  styles.tabLabel,
                  { color: isActive ? tabColor : colors.mutedForeground },
                  isActive && { fontFamily: "Inter_600SemiBold" },
                ]}
              >
                {tab.label}
              </Text>
              {result.status === "error" && (
                <Ionicons name="warning-outline" size={12} color="#EF4444" />
              )}
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Content */}
      <ScrollView
        style={{ flex: 1, backgroundColor: colors.background }}
        contentContainerStyle={[
          styles.resultsContent,
          { paddingBottom: bottomPad + 24 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {activeResult.status === "error" ? (
          <View style={[styles.errorBox, { backgroundColor: "#EF444415", borderColor: "#EF444430" }]}>
            <Ionicons name="warning-outline" size={20} color="#EF4444" />
            <Text style={[styles.errorText, { color: "#EF4444" }]}>
              {activeResult.error ?? "Generation failed. Tap refresh to retry."}
            </Text>
          </View>
        ) : activeResult.status !== "done" ? (
          <View style={styles.loadingBox}>
            <ActivityIndicator color={accentColor} size="large" />
            <Text style={[styles.loadingText, { color: colors.mutedForeground }]}>Generating…</Text>
          </View>
        ) : (
          <ResultContent tabKey={activeTab} data={activeResult.data} colors={colors} />
        )}
      </ScrollView>
    </View>
  );
}

function ResultContent({
  tabKey,
  data,
  colors,
}: {
  tabKey: TabKey;
  data: unknown;
  colors: ReturnType<typeof useColors>;
}) {
  const d = (data ?? {}) as Record<string, unknown>;
  switch (tabKey) {
    case "businessModel":
      return <BusinessModelView data={d} colors={colors} />;
    case "financialModel":
      return <FinancialModelView data={d} colors={colors} />;
    case "pitchDeck":
      return <PitchDeckView data={d} colors={colors} />;
    case "prototypeSpec":
      return <PrototypeSpecView data={d} colors={colors} />;
    case "gtmCampaign":
      return <GtmCampaignView data={d} colors={colors} />;
  }
}

// ─── InputField helper ────────────────────────────────────────────────────────

function InputField({
  label,
  icon,
  value,
  onChange,
  placeholder,
  multiline,
  colors,
}: {
  label: string;
  icon: string;
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  multiline?: boolean;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={{ marginBottom: 14 }}>
      <Text style={[inputFieldStyles.label, { color: colors.mutedForeground }]}>{label}</Text>
      <View
        style={[
          inputFieldStyles.wrap,
          { backgroundColor: colors.background, borderColor: colors.border },
          multiline && inputFieldStyles.textAreaWrap,
        ]}
      >
        <Ionicons
          name={icon as any}
          size={17}
          color={colors.mutedForeground}
          style={[inputFieldStyles.icon, multiline && { marginTop: 3 }]}
        />
        <TextInput
          style={[inputFieldStyles.input, { color: colors.foreground }, multiline && inputFieldStyles.textArea]}
          value={value}
          onChangeText={onChange}
          placeholder={placeholder}
          placeholderTextColor={colors.mutedForeground}
          multiline={multiline}
          numberOfLines={multiline ? 3 : 1}
          textAlignVertical={multiline ? "top" : "center"}
          autoCapitalize={label === "Company name" ? "words" : "sentences"}
        />
      </View>
    </View>
  );
}

const inputFieldStyles = StyleSheet.create({
  label: {
    fontSize: 11,
    fontWeight: "600",
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 6,
  },
  wrap: {
    flexDirection: "row",
    alignItems: "center",
    borderRadius: 10,
    borderWidth: 1,
    paddingHorizontal: 12,
  },
  textAreaWrap: {
    alignItems: "flex-start",
    paddingTop: 10,
    paddingBottom: 10,
  },
  icon: {
    marginRight: 8,
    flexShrink: 0,
  },
  input: {
    flex: 1,
    fontSize: 15,
    fontFamily: "Inter_400Regular",
    paddingVertical: 12,
  },
  textArea: {
    minHeight: 72,
    paddingVertical: 2,
  },
});

// ─── Styles ───────────────────────────────────────────────────────────────────

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: {
      flex: 1,
      backgroundColor: colors.background,
    },
    scroll: {
      flexGrow: 1,
      paddingHorizontal: 20,
      paddingTop: 12,
    },
    backBtn: {
      width: 38,
      height: 38,
      alignItems: "center",
      justifyContent: "center",
      borderRadius: 10,
      marginBottom: 16,
    },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      marginBottom: 24,
    },
    logoWrap: {
      width: 48,
      height: 48,
      borderRadius: 14,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    },
    appName: {
      fontSize: 18,
      fontWeight: "700",
      color: colors.foreground,
      fontFamily: "Inter_700Bold",
    },
    tagline: {
      fontSize: 12,
      color: colors.mutedForeground,
      fontFamily: "Inter_400Regular",
    },
    heroTitle: {
      fontSize: 28,
      fontWeight: "800",
      color: colors.foreground,
      fontFamily: "Inter_700Bold",
      lineHeight: 34,
      marginBottom: 10,
    },
    heroSub: {
      fontSize: 14,
      color: colors.mutedForeground,
      fontFamily: "Inter_400Regular",
      lineHeight: 21,
      marginBottom: 24,
    },
    card: {
      backgroundColor: colors.card,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.border,
      padding: 20,
      marginBottom: 20,
    },
    runBtn: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "center",
      gap: 8,
      backgroundColor: "#8B5CF6",
      borderRadius: 12,
      paddingVertical: 15,
      marginTop: 4,
    },
    runBtnDisabled: {
      opacity: 0.35,
    },
    runBtnText: {
      fontSize: 16,
      fontWeight: "700",
      color: "#fff",
      fontFamily: "Inter_700Bold",
    },
    pills: {
      flexDirection: "row",
      gap: 8,
      flexWrap: "wrap",
    },
    pill: {
      flexDirection: "row",
      alignItems: "center",
      gap: 5,
      backgroundColor: colors.card,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 20,
      paddingHorizontal: 10,
      paddingVertical: 6,
    },
    pillText: {
      fontSize: 11,
      color: colors.mutedForeground,
      fontFamily: "Inter_500Medium",
    },
    // Running phase
    runningHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      marginBottom: 8,
    },
    companyLabel: {
      fontSize: 22,
      fontWeight: "700",
      fontFamily: "Inter_700Bold",
      marginBottom: 4,
    },
    runningHint: {
      fontSize: 13,
      fontFamily: "Inter_400Regular",
      textAlign: "center",
      marginTop: 16,
      lineHeight: 20,
    },
    // Results phase
    resultsHeader: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      paddingHorizontal: 16,
      paddingBottom: 12,
    },
    rerunBtn: {
      width: 36,
      height: 36,
      borderRadius: 10,
      borderWidth: 1,
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
    },
    tabBar: {
      flexGrow: 0,
      borderBottomWidth: 1,
    },
    tabBarContent: {
      paddingHorizontal: 16,
      gap: 0,
    },
    tab: {
      flexDirection: "row",
      alignItems: "center",
      gap: 6,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderBottomWidth: 2,
      borderBottomColor: "transparent",
    },
    tabLabel: {
      fontSize: 13,
      fontFamily: "Inter_500Medium",
    },
    resultsContent: {
      padding: 20,
    },
    errorBox: {
      flexDirection: "row",
      gap: 10,
      alignItems: "flex-start",
      padding: 16,
      borderRadius: 12,
      borderWidth: 1,
    },
    errorText: {
      flex: 1,
      fontSize: 14,
      fontFamily: "Inter_400Regular",
      lineHeight: 20,
    },
    loadingBox: {
      alignItems: "center",
      justifyContent: "center",
      paddingVertical: 60,
      gap: 16,
    },
    loadingText: {
      fontSize: 14,
      fontFamily: "Inter_400Regular",
    },
  });
}
