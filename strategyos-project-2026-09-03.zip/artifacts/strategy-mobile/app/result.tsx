import React, { useRef, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Dimensions,
  NativeScrollEvent,
  NativeSyntheticEvent,
} from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useReport } from "@/context/ReportContext";
import type { SwotItem, StrategicPriority, ActionPhase, RiskItem, CompetitiveMatrix, BusinessScore, CategoryScore, ScoreRating } from "@/types/report";

const SCREEN_W = Dimensions.get("window").width;

// ─── SWOT quadrant config ─────────────────────────────────────────────────────

const QUADRANT_CFG = {
  strengths:     { label: "Strengths",     letter: "S", icon: "shield-checkmark" as const,  color: "#10B981" },
  weaknesses:    { label: "Weaknesses",    letter: "W", icon: "warning" as const,             color: "#F59E0B" },
  opportunities: { label: "Opportunities", letter: "O", icon: "trending-up" as const,          color: "#3B82F6" },
  threats:       { label: "Threats",       letter: "T", icon: "flash" as const,                color: "#EF4444" },
} as const;

type QuadrantKey = keyof typeof QUADRANT_CFG;

// ─── Swipeable SWOT pager ─────────────────────────────────────────────────────

function SwotPager({ swot, colors }: {
  swot: { strengths: SwotItem[]; weaknesses: SwotItem[]; opportunities: SwotItem[]; threats: SwotItem[] };
  colors: ReturnType<typeof useColors>;
}) {
  const [activeIdx, setActiveIdx] = useState(0);
  const scrollRef = useRef<ScrollView>(null);
  const keys: QuadrantKey[] = ["strengths", "weaknesses", "opportunities", "threats"];
  const pageW = SCREEN_W - 40; // 20px padding each side

  const onMomentumEnd = (e: NativeSyntheticEvent<NativeScrollEvent>) => {
    const idx = Math.round(e.nativeEvent.contentOffset.x / pageW);
    setActiveIdx(idx);
  };

  const goTo = (idx: number) => {
    scrollRef.current?.scrollTo({ x: idx * pageW, animated: true });
    setActiveIdx(idx);
    Haptics.selectionAsync();
  };

  return (
    <View>
      {/* Tab bar */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={swotStyles.tabBar} contentContainerStyle={swotStyles.tabBarContent}>
        {keys.map((k, i) => {
          const cfg = QUADRANT_CFG[k];
          const active = i === activeIdx;
          return (
            <TouchableOpacity
              key={k}
              style={[
                swotStyles.tab,
                { backgroundColor: active ? cfg.color + "20" : "transparent", borderColor: active ? cfg.color + "50" : colors.border }
              ]}
              onPress={() => goTo(i)}
              activeOpacity={0.7}
            >
              <Text style={[swotStyles.tabLetter, { color: active ? cfg.color : colors.mutedForeground }]}>{cfg.letter}</Text>
              <Text style={[swotStyles.tabLabel, { color: active ? colors.foreground : colors.mutedForeground }]}>{cfg.label}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>

      {/* Pages */}
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onMomentumScrollEnd={onMomentumEnd}
        decelerationRate="fast"
        snapToInterval={pageW}
        style={{ width: pageW }}
      >
        {keys.map((k) => {
          const cfg = QUADRANT_CFG[k];
          const items = swot[k];
          return (
            <View key={k} style={[swotStyles.page, { width: pageW }]}>
              <View style={[swotStyles.quadrantHeader, { backgroundColor: cfg.color + "10", borderColor: cfg.color + "25" }]}>
                <Ionicons name={cfg.icon} size={18} color={cfg.color} />
                <Text style={[swotStyles.quadrantTitle, { color: cfg.color }]}>{cfg.label}</Text>
                <Text style={[swotStyles.quadrantCount, { color: cfg.color + "80" }]}>{items.length}</Text>
              </View>
              <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled style={swotStyles.itemsScroll}>
                {items.map((item, i) => (
                  <View key={i}>
                    <SwotItemRow item={item} color={cfg.color} colors={colors} />
                    {i < items.length - 1 && <View style={[swotStyles.divider, { backgroundColor: colors.border }]} />}
                  </View>
                ))}
              </ScrollView>
            </View>
          );
        })}
      </ScrollView>

      {/* Dot indicator */}
      <View style={swotStyles.dots}>
        {keys.map((_, i) => (
          <View
            key={i}
            style={[swotStyles.dot, {
              backgroundColor: i === activeIdx ? colors.primary : colors.border,
              width: i === activeIdx ? 16 : 6,
            }]}
          />
        ))}
      </View>
    </View>
  );
}

function SwotItemRow({ item, color, colors }: { item: SwotItem; color: string; colors: ReturnType<typeof useColors> }) {
  const [expanded, setExpanded] = useState(false);
  const confidenceColor = item.confidence_score === "high" ? "#10B981" : item.confidence_score === "medium" ? "#F59E0B" : "#EF4444";
  return (
    <TouchableOpacity style={swotStyles.itemRow} onPress={() => setExpanded((v) => !v)} activeOpacity={0.7}>
      <View style={swotStyles.itemTop}>
        <View style={[swotStyles.dot2, { backgroundColor: color }]} />
        <Text style={[swotStyles.itemPoint, { color: colors.foreground }]}>{item.point}</Text>
        <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={14} color={colors.mutedForeground} />
      </View>
      {expanded && (
        <View style={swotStyles.itemExpanded}>
          <Text style={[swotStyles.itemEvidence, { color: colors.mutedForeground }]}>{item.evidence}</Text>
          {item.strategic_impact !== "" && (
            <View style={[swotStyles.impactBox, { backgroundColor: color + "0A", borderColor: color + "25" }]}>
              <Text style={[swotStyles.impactLabel, { color: color + "90" }]}>Strategic impact</Text>
              <Text style={[swotStyles.impactText, { color: colors.mutedForeground }]}>{item.strategic_impact}</Text>
            </View>
          )}
          <View style={swotStyles.metaRow}>
            <View style={[swotStyles.confBadge, { backgroundColor: confidenceColor + "15", borderColor: confidenceColor + "30" }]}>
              <View style={[swotStyles.confDot, { backgroundColor: confidenceColor }]} />
              <Text style={[swotStyles.confText, { color: confidenceColor }]}>{item.confidence_score}</Text>
            </View>
            {item.citation !== "" && item.citation !== "Agent inference (low confidence)" && (
              <Text style={[swotStyles.citation, { color: colors.mutedForeground }]} numberOfLines={1}>{item.citation}</Text>
            )}
          </View>
        </View>
      )}
    </TouchableOpacity>
  );
}

const swotStyles = StyleSheet.create({
  tabBar: { marginBottom: 12 },
  tabBarContent: { gap: 8, paddingBottom: 2 },
  tab: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  tabLetter: { fontSize: 13, fontWeight: "800" as const, fontFamily: "Inter_700Bold" },
  tabLabel: { fontSize: 12, fontFamily: "Inter_500Medium" },
  page: { paddingRight: 0 },
  quadrantHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    marginBottom: 12,
  },
  quadrantTitle: { fontSize: 14, fontWeight: "700" as const, fontFamily: "Inter_700Bold", flex: 1 },
  quadrantCount: { fontSize: 13, fontFamily: "Inter_600SemiBold" },
  itemsScroll: { maxHeight: 340 },
  itemRow: { paddingVertical: 12 },
  itemTop: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  dot2: { width: 6, height: 6, borderRadius: 3, marginTop: 6, flexShrink: 0 },
  itemPoint: { flex: 1, fontSize: 13, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold", lineHeight: 19 },
  itemExpanded: { paddingLeft: 16, paddingTop: 8, gap: 8 },
  itemEvidence: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  impactBox: { borderWidth: 1, borderRadius: 8, padding: 10 },
  impactLabel: { fontSize: 10, fontWeight: "700" as const, fontFamily: "Inter_700Bold", textTransform: "uppercase" as const, letterSpacing: 0.5, marginBottom: 3 },
  impactText: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
  metaRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  confBadge: { flexDirection: "row", alignItems: "center", gap: 4, borderWidth: 1, borderRadius: 10, paddingHorizontal: 8, paddingVertical: 3 },
  confDot: { width: 5, height: 5, borderRadius: 3 },
  confText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
  citation: { fontSize: 10, fontFamily: "Inter_400Regular", flex: 1 },
  divider: { height: 1, opacity: 0.5 },
  dots: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, marginTop: 14 },
  dot: { height: 6, borderRadius: 3 },
});

// ─── Priority card ─────────────────────────────────────────────────────────────

function PriorityCard({ item, idx, colors }: { item: StrategicPriority; idx: number; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[priorityStyles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={[priorityStyles.num, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "25" }]}>
        <Text style={[priorityStyles.numText, { color: colors.primary }]}>{idx + 1}</Text>
      </View>
      <View style={priorityStyles.content}>
        <Text style={[priorityStyles.title, { color: colors.foreground }]}>{item.title}</Text>
        <Text style={[priorityStyles.rationale, { color: colors.mutedForeground }]}>{item.rationale}</Text>
        <View style={[priorityStyles.actionRow, { borderColor: colors.border }]}>
          <Ionicons name="flash-outline" size={12} color={colors.primary} />
          <Text style={[priorityStyles.action, { color: colors.mutedForeground }]}>{item.keyAction}</Text>
        </View>
      </View>
    </View>
  );
}

const priorityStyles = StyleSheet.create({
  card: { flexDirection: "row", borderWidth: 1, borderRadius: 14, padding: 14, gap: 12, marginBottom: 10 },
  num: { width: 30, height: 30, borderRadius: 8, borderWidth: 1, alignItems: "center", justifyContent: "center", flexShrink: 0, marginTop: 2 },
  numText: { fontSize: 14, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  content: { flex: 1, gap: 4 },
  title: { fontSize: 14, fontWeight: "700" as const, fontFamily: "Inter_700Bold", lineHeight: 19 },
  rationale: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  actionRow: { flexDirection: "row", alignItems: "flex-start", gap: 6, borderTopWidth: 1, paddingTop: 8, marginTop: 4 },
  action: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
});

// ─── Phase card ────────────────────────────────────────────────────────────────

function PhaseCard({ phase, colors }: { phase: ActionPhase; colors: ReturnType<typeof useColors> }) {
  return (
    <View style={[phaseStyles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={phaseStyles.header}>
        <View style={[phaseStyles.phaseBadge, { backgroundColor: "#3B82F6" + "15", borderColor: "#3B82F6" + "25" }]}>
          <Text style={[phaseStyles.phaseLabel, { color: "#3B82F6" }]}>{phase.phase}</Text>
        </View>
        <Text style={[phaseStyles.focus, { color: colors.foreground }]}>{phase.focus}</Text>
      </View>
      <View style={phaseStyles.actions}>
        {phase.actions.map((a, i) => (
          <View key={i} style={phaseStyles.actionRow}>
            <View style={[phaseStyles.bullet, { backgroundColor: "#3B82F6" }]} />
            <Text style={[phaseStyles.actionText, { color: colors.mutedForeground }]}>{a}</Text>
          </View>
        ))}
      </View>
      <View style={[phaseStyles.milestone, { backgroundColor: colors.muted, borderColor: colors.border }]}>
        <Ionicons name="flag-outline" size={12} color="#10B981" />
        <Text style={[phaseStyles.milestoneText, { color: colors.mutedForeground }]}>{phase.milestone}</Text>
      </View>
    </View>
  );
}

const phaseStyles = StyleSheet.create({
  card: { borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 10 },
  header: { flexDirection: "row", alignItems: "flex-start", gap: 10, marginBottom: 10 },
  phaseBadge: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, flexShrink: 0 },
  phaseLabel: { fontSize: 11, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  focus: { flex: 1, fontSize: 14, fontWeight: "700" as const, fontFamily: "Inter_700Bold", lineHeight: 19 },
  actions: { gap: 6, marginBottom: 10 },
  actionRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  bullet: { width: 5, height: 5, borderRadius: 3, marginTop: 6, flexShrink: 0 },
  actionText: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  milestone: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderRadius: 8, padding: 10 },
  milestoneText: { flex: 1, fontSize: 11, fontFamily: "Inter_400Regular", lineHeight: 16 },
});

// ─── Competitive Matrix section ───────────────────────────────────────────────

function CompetitiveMatrixSection({ matrix, colors }: { matrix: CompetitiveMatrix; colors: ReturnType<typeof useColors> }) {
  const [expanded, setExpanded] = useState(false);

  return (
    <View>
      {/* Target moats */}
      {matrix.targetMoats.length > 0 && (
        <View style={[matrixStyles.listCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={matrixStyles.listHeadRow}>
            <Ionicons name="shield-checkmark-outline" size={14} color="#10B981" />
            <Text style={[matrixStyles.listHeadText, { color: "#10B981" }]}>Target Moats</Text>
          </View>
          {matrix.targetMoats.map((m, i) => (
            <View key={i} style={matrixStyles.bulletRow}>
              <View style={[matrixStyles.bullet, { backgroundColor: "#10B981" }]} />
              <Text style={[matrixStyles.bulletText, { color: colors.mutedForeground }]}>{m}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Target vulnerabilities */}
      {matrix.targetVulnerabilities.length > 0 && (
        <View style={[matrixStyles.listCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={matrixStyles.listHeadRow}>
            <Ionicons name="warning-outline" size={14} color="#F59E0B" />
            <Text style={[matrixStyles.listHeadText, { color: "#F59E0B" }]}>Vulnerabilities</Text>
          </View>
          {matrix.targetVulnerabilities.map((v, i) => (
            <View key={i} style={matrixStyles.bulletRow}>
              <View style={[matrixStyles.bullet, { backgroundColor: "#F59E0B" }]} />
              <Text style={[matrixStyles.bulletText, { color: colors.mutedForeground }]}>{v}</Text>
            </View>
          ))}
        </View>
      )}

      {/* Benchmark summary */}
      {matrix.benchmarkSummary !== "" && (
        <View style={[matrixStyles.summaryCard, { backgroundColor: colors.muted, borderColor: colors.border }]}>
          <Text style={[matrixStyles.summaryText, { color: colors.mutedForeground }]}>{matrix.benchmarkSummary}</Text>
        </View>
      )}

      {/* Competitor comparison table */}
      {matrix.competitors.length > 0 && (
        <View>
          <TouchableOpacity
            style={[matrixStyles.tableToggle, { backgroundColor: colors.card, borderColor: colors.border }]}
            onPress={() => { setExpanded((v) => !v); Haptics.selectionAsync(); }}
            activeOpacity={0.7}
          >
            <Ionicons name="people-outline" size={14} color={colors.mutedForeground} />
            <Text style={[matrixStyles.tableToggleText, { color: colors.foreground }]}>
              Competitor Comparison ({matrix.competitors.length})
            </Text>
            <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={14} color={colors.mutedForeground} />
          </TouchableOpacity>

          {expanded && (
            <ScrollView horizontal showsHorizontalScrollIndicator style={matrixStyles.tableScroll} nestedScrollEnabled>
              <View>
                {/* Header row */}
                <View style={[matrixStyles.tableRow, matrixStyles.tableHeader, { backgroundColor: colors.muted, borderColor: colors.border }]}>
                  <Text style={[matrixStyles.colHeader, matrixStyles.colName, { color: colors.mutedForeground }]}>Competitor</Text>
                  <Text style={[matrixStyles.colHeader, matrixStyles.colWide, { color: colors.mutedForeground }]}>Key Moat</Text>
                  <Text style={[matrixStyles.colHeader, matrixStyles.colWide, { color: colors.mutedForeground }]}>Vulnerability</Text>
                  <Text style={[matrixStyles.colHeader, matrixStyles.colMid, { color: colors.mutedForeground }]}>Pricing</Text>
                  <Text style={[matrixStyles.colHeader, matrixStyles.colWide, { color: colors.mutedForeground }]}>vs. Target</Text>
                </View>
                {/* Data rows */}
                {matrix.competitors.map((c, i) => (
                  <View
                    key={i}
                    style={[
                      matrixStyles.tableRow,
                      { borderColor: colors.border, backgroundColor: i % 2 === 0 ? colors.card : colors.background },
                    ]}
                  >
                    <Text style={[matrixStyles.cellName, matrixStyles.colName, { color: colors.foreground }]} numberOfLines={2}>{c.name}</Text>
                    <Text style={[matrixStyles.cell, matrixStyles.colWide, { color: colors.mutedForeground }]} numberOfLines={3}>{c.keyMoat}</Text>
                    <Text style={[matrixStyles.cell, matrixStyles.colWide, { color: colors.mutedForeground }]} numberOfLines={3}>{c.keyVulnerability}</Text>
                    <Text style={[matrixStyles.cell, matrixStyles.colMid, { color: colors.mutedForeground }]} numberOfLines={2}>{c.pricingModel}</Text>
                    <Text style={[matrixStyles.cell, matrixStyles.colWide, { color: colors.mutedForeground }]} numberOfLines={3}>{c.vsTargetCompany}</Text>
                  </View>
                ))}
              </View>
            </ScrollView>
          )}
        </View>
      )}
    </View>
  );
}

const matrixStyles = StyleSheet.create({
  listCard: { borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 10, gap: 8 },
  listHeadRow: { flexDirection: "row", alignItems: "center", gap: 6, marginBottom: 4 },
  listHeadText: { fontSize: 12, fontWeight: "700" as const, fontFamily: "Inter_700Bold", textTransform: "uppercase" as const, letterSpacing: 0.5 },
  bulletRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  bullet: { width: 5, height: 5, borderRadius: 3, marginTop: 6, flexShrink: 0 },
  bulletText: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
  summaryCard: { borderWidth: 1, borderRadius: 12, padding: 14, marginBottom: 10 },
  summaryText: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  tableToggle: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    borderWidth: 1,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  tableToggleText: { flex: 1, fontSize: 13, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold" },
  tableScroll: { marginBottom: 4 },
  tableRow: { flexDirection: "row", borderBottomWidth: 1 },
  tableHeader: { borderTopWidth: 1, borderTopLeftRadius: 10, borderTopRightRadius: 10 },
  colHeader: { fontSize: 10, fontWeight: "700" as const, fontFamily: "Inter_700Bold", textTransform: "uppercase" as const, letterSpacing: 0.4, padding: 10 },
  colName: { width: 110 },
  colWide: { width: 160 },
  colMid: { width: 120 },
  cellName: { fontSize: 12, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold", padding: 10, lineHeight: 17 },
  cell: { fontSize: 11, fontFamily: "Inter_400Regular", padding: 10, lineHeight: 16 },
});

// ─── Risks section ─────────────────────────────────────────────────────────────

const IMPACT_CFG = {
  High:   { color: "#EF4444" },
  Medium: { color: "#F59E0B" },
  Low:    { color: "#10B981" },
} as const;

function RiskCard({ risk, colors }: { risk: RiskItem; colors: ReturnType<typeof useColors> }) {
  const [expanded, setExpanded] = useState(false);
  const impactColor = IMPACT_CFG[risk.impact]?.color ?? colors.mutedForeground;
  return (
    <TouchableOpacity
      style={[riskStyles.card, { backgroundColor: colors.card, borderColor: colors.border, borderLeftColor: impactColor }]}
      onPress={() => setExpanded((v) => !v)}
      activeOpacity={0.7}
    >
      <View style={riskStyles.top}>
        <View style={{ flex: 1, gap: 4 }}>
          <Text style={[riskStyles.title, { color: colors.foreground }]}>{risk.title}</Text>
          <Text style={[riskStyles.description, { color: colors.mutedForeground }]} numberOfLines={expanded ? undefined : 2}>{risk.description}</Text>
        </View>
        <View style={riskStyles.right}>
          <View style={[riskStyles.impactBadge, { backgroundColor: impactColor + "15", borderColor: impactColor + "30" }]}>
            <Text style={[riskStyles.impactText, { color: impactColor }]}>{risk.impact}</Text>
          </View>
          <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={13} color={colors.mutedForeground} style={{ marginTop: 4 }} />
        </View>
      </View>
      {expanded && risk.mitigation !== "" && (
        <View style={[riskStyles.mitigationBox, { backgroundColor: "#10B981" + "08", borderColor: "#10B981" + "25" }]}>
          <View style={riskStyles.mitigationHead}>
            <Ionicons name="shield-outline" size={12} color="#10B981" />
            <Text style={[riskStyles.mitigationLabel, { color: "#10B981" }]}>Mitigation</Text>
          </View>
          <Text style={[riskStyles.mitigationText, { color: colors.mutedForeground }]}>{risk.mitigation}</Text>
        </View>
      )}
    </TouchableOpacity>
  );
}

const riskStyles = StyleSheet.create({
  card: {
    borderWidth: 1,
    borderLeftWidth: 3,
    borderRadius: 12,
    padding: 14,
    marginBottom: 10,
    gap: 10,
  },
  top: { flexDirection: "row", gap: 10 },
  title: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold", lineHeight: 18 },
  description: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  right: { alignItems: "flex-end", gap: 4, flexShrink: 0 },
  impactBadge: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 9, paddingVertical: 3 },
  impactText: { fontSize: 10, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  mitigationBox: { borderWidth: 1, borderRadius: 8, padding: 10, gap: 6 },
  mitigationHead: { flexDirection: "row", alignItems: "center", gap: 5 },
  mitigationLabel: { fontSize: 10, fontWeight: "700" as const, fontFamily: "Inter_700Bold", textTransform: "uppercase" as const, letterSpacing: 0.5 },
  mitigationText: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
});

// ─── Business Score section ───────────────────────────────────────────────────

const RATING_CFG: Record<ScoreRating, { color: string; label: string }> = {
  Excellent: { color: "#10B981", label: "Excellent" },
  Strong:    { color: "#3B82F6", label: "Strong" },
  Moderate:  { color: "#F59E0B", label: "Moderate" },
  Weak:      { color: "#F97316", label: "Weak" },
  Critical:  { color: "#EF4444", label: "Critical" },
};

const GRADE_COLOR: Record<string, string> = {
  "A+": "#10B981", "A": "#10B981",
  "B+": "#3B82F6", "B": "#3B82F6",
  "C+": "#F59E0B", "C": "#F59E0B",
  "D":  "#F97316",
  "F":  "#EF4444",
};

function CategoryBar({ cat, colors }: { cat: CategoryScore; colors: ReturnType<typeof useColors> }) {
  const ratingCfg = RATING_CFG[cat.rating] ?? RATING_CFG.Moderate;
  const pct = Math.round((cat.score / 20) * 100);
  const [expanded, setExpanded] = useState(false);

  return (
    <TouchableOpacity
      style={scoreStyles.catRow}
      onPress={() => setExpanded((v) => !v)}
      activeOpacity={0.75}
    >
      {/* Label row */}
      <View style={scoreStyles.catLabelRow}>
        <Text style={[scoreStyles.catName, { color: colors.foreground }]} numberOfLines={1}>{cat.categoryName}</Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
          <View style={[scoreStyles.ratingBadge, { backgroundColor: ratingCfg.color + "18", borderColor: ratingCfg.color + "35" }]}>
            <Text style={[scoreStyles.ratingText, { color: ratingCfg.color }]}>{cat.rating}</Text>
          </View>
          <Text style={[scoreStyles.catScore, { color: ratingCfg.color }]}>{cat.score}<Text style={[scoreStyles.catScoreMax, { color: colors.mutedForeground }]}>/20</Text></Text>
          <Ionicons name={expanded ? "chevron-up" : "chevron-down"} size={12} color={colors.mutedForeground} />
        </View>
      </View>

      {/* Progress bar */}
      <View style={[scoreStyles.barTrack, { backgroundColor: colors.muted }]}>
        <View style={[scoreStyles.barFill, { width: `${pct}%` as any, backgroundColor: ratingCfg.color }]} />
      </View>

      {/* Expanded detail */}
      {expanded && (
        <View style={scoreStyles.catDetail}>
          <Text style={[scoreStyles.catRationale, { color: colors.mutedForeground }]}>{cat.rationale}</Text>
          {cat.subCriteria.length > 0 && (
            <View style={scoreStyles.subList}>
              {cat.subCriteria.map((sc, i) => (
                <View key={i} style={scoreStyles.subRow}>
                  <View style={[scoreStyles.subDot, { backgroundColor: ratingCfg.color }]} />
                  <View style={{ flex: 1 }}>
                    <Text style={[scoreStyles.subLabel, { color: colors.foreground }]}>{sc.label}</Text>
                    <Text style={[scoreStyles.subFinding, { color: colors.mutedForeground }]}>{sc.finding}</Text>
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
}

function BusinessScoreSection({ score, colors }: { score: BusinessScore; colors: ReturnType<typeof useColors> }) {
  const gradeColor = GRADE_COLOR[score.healthGrade] ?? "#F59E0B";

  return (
    <View>
      {/* Hero card — overall score + grade */}
      <View style={[scoreStyles.heroCard, { backgroundColor: colors.card, borderColor: gradeColor + "40" }]}>
        {/* Grade circle */}
        <View style={[scoreStyles.gradeCircle, { borderColor: gradeColor + "60", backgroundColor: gradeColor + "12" }]}>
          <Text style={[scoreStyles.gradeText, { color: gradeColor }]}>{score.healthGrade}</Text>
        </View>

        {/* Score + summary */}
        <View style={scoreStyles.heroRight}>
          <View style={scoreStyles.scoreRow}>
            <Text style={[scoreStyles.overallNum, { color: gradeColor }]}>{score.overallScore}</Text>
            <Text style={[scoreStyles.overallMax, { color: colors.mutedForeground }]}>/100</Text>
          </View>
          <Text style={[scoreStyles.heroSummary, { color: colors.mutedForeground }]}>{score.executiveSummary}</Text>
        </View>
      </View>

      {/* Category bars */}
      <View style={[scoreStyles.categoriesCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {score.categories.map((cat, i) => (
          <View key={i}>
            <CategoryBar cat={cat} colors={colors} />
            {i < score.categories.length - 1 && (
              <View style={[scoreStyles.catDivider, { backgroundColor: colors.border }]} />
            )}
          </View>
        ))}
      </View>

      {/* Quick Wins */}
      {score.quickWins.length > 0 && (
        <View style={[scoreStyles.quickWinsCard, { backgroundColor: "#10B981" + "08", borderColor: "#10B981" + "25" }]}>
          <View style={scoreStyles.quickWinsHead}>
            <Ionicons name="flash" size={14} color="#10B981" />
            <Text style={scoreStyles.quickWinsTitle}>Quick Wins</Text>
          </View>
          {score.quickWins.map((win, i) => (
            <View key={i} style={scoreStyles.quickWinRow}>
              <View style={[scoreStyles.quickWinNum, { backgroundColor: "#10B981" + "20", borderColor: "#10B981" + "35" }]}>
                <Text style={scoreStyles.quickWinNumText}>{i + 1}</Text>
              </View>
              <Text style={[scoreStyles.quickWinText, { color: colors.mutedForeground }]}>{win}</Text>
            </View>
          ))}
        </View>
      )}
    </View>
  );
}

const scoreStyles = StyleSheet.create({
  heroCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
    borderWidth: 1.5,
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
  },
  gradeCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    borderWidth: 2.5,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
  },
  gradeText: { fontSize: 28, fontWeight: "800" as const, fontFamily: "Inter_700Bold" },
  heroRight: { flex: 1, gap: 6 },
  scoreRow: { flexDirection: "row", alignItems: "baseline", gap: 3 },
  overallNum: { fontSize: 32, fontWeight: "800" as const, fontFamily: "Inter_700Bold", lineHeight: 36 },
  overallMax: { fontSize: 15, fontFamily: "Inter_400Regular" },
  heroSummary: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  categoriesCard: {
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 6,
    marginBottom: 12,
  },
  catRow: { paddingVertical: 12 },
  catLabelRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 8 },
  catName: { fontSize: 13, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold", flex: 1, marginRight: 10 },
  ratingBadge: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 7, paddingVertical: 2 },
  ratingText: { fontSize: 10, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  catScore: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  catScoreMax: { fontSize: 10, fontFamily: "Inter_400Regular" },
  barTrack: { height: 6, borderRadius: 3, overflow: "hidden" },
  barFill: { height: 6, borderRadius: 3 },
  catDetail: { paddingTop: 10, gap: 8 },
  catRationale: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  subList: { gap: 8 },
  subRow: { flexDirection: "row", alignItems: "flex-start", gap: 8 },
  subDot: { width: 5, height: 5, borderRadius: 3, marginTop: 5, flexShrink: 0 },
  subLabel: { fontSize: 11, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold", lineHeight: 16 },
  subFinding: { fontSize: 11, fontFamily: "Inter_400Regular", lineHeight: 16 },
  catDivider: { height: 1, opacity: 0.5 },
  quickWinsCard: {
    borderWidth: 1,
    borderRadius: 14,
    padding: 14,
    gap: 12,
  },
  quickWinsHead: { flexDirection: "row", alignItems: "center", gap: 6 },
  quickWinsTitle: { fontSize: 13, fontWeight: "700" as const, fontFamily: "Inter_700Bold", color: "#10B981" },
  quickWinRow: { flexDirection: "row", alignItems: "flex-start", gap: 10 },
  quickWinNum: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    flexShrink: 0,
    marginTop: 1,
  },
  quickWinNumText: { fontSize: 11, fontWeight: "700" as const, fontFamily: "Inter_700Bold", color: "#10B981" },
  quickWinText: { flex: 1, fontSize: 13, fontFamily: "Inter_400Regular", lineHeight: 19 },
});

// ─── Section header ────────────────────────────────────────────────────────────

function SectionHeader({ icon, label, color, count, colors: c }: {
  icon: keyof typeof Ionicons.glyphMap;
  label: string;
  color: string;
  count?: number;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <View style={sectionStyles.row}>
      <View style={[sectionStyles.iconWrap, { backgroundColor: color + "15", borderColor: color + "30" }]}>
        <Ionicons name={icon} size={16} color={color} />
      </View>
      <Text style={[sectionStyles.label, { color: c.foreground }]}>{label}</Text>
      {count !== undefined && (
        <View style={[sectionStyles.countBadge, { backgroundColor: c.muted, borderColor: c.border }]}>
          <Text style={[sectionStyles.countText, { color: c.mutedForeground }]}>{count}</Text>
        </View>
      )}
    </View>
  );
}

const sectionStyles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 14 },
  iconWrap: { width: 32, height: 32, borderRadius: 9, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  label: { flex: 1, fontSize: 17, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
  countBadge: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 3 },
  countText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
});

// ─── Main result screen ────────────────────────────────────────────────────────

export default function ResultScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { report, companyName } = useReport();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  if (!report) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>No report available</Text>
        <TouchableOpacity onPress={() => router.replace("/")} style={{ marginTop: 16 }}>
          <Text style={{ color: colors.primary, fontFamily: "Inter_500Medium" }}>Go home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const styles = makeStyles(colors);

  return (
    <View style={[styles.root, { paddingTop: topPad }]}>
      {/* Fixed header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <TouchableOpacity onPress={() => router.replace("/")} style={styles.backBtn} activeOpacity={0.7}>
          <Ionicons name="arrow-back" size={20} color={colors.foreground} />
        </TouchableOpacity>
        <View style={styles.headerCenter}>
          <Text style={[styles.headerCompany, { color: colors.foreground }]} numberOfLines={1}>{companyName}</Text>
          <View style={[styles.reportBadge, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "30" }]}>
            <Text style={[styles.reportBadgeText, { color: colors.primary }]}>Strategy Report</Text>
          </View>
        </View>
        <TouchableOpacity
          style={[styles.sourcesBtn, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => router.push("/sources")}
          activeOpacity={0.7}
        >
          <Ionicons name="document-text-outline" size={16} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 32 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Data quality banner */}
        {report.dataQuality !== "sufficient" && (
          <View style={[styles.qualityBanner, { backgroundColor: "#F59E0B" + "10", borderColor: "#F59E0B" + "30" }]}>
            <Ionicons name="information-circle-outline" size={16} color="#F59E0B" />
            <Text style={styles.qualityText}>{report.dataNote}</Text>
          </View>
        )}

        {/* Business Score */}
        {report.businessScore && (
          <View style={styles.section}>
            <SectionHeader icon="speedometer-outline" label="Business Score" color="#10B981" colors={colors} />
            <BusinessScoreSection score={report.businessScore} colors={colors} />
          </View>
        )}

        {/* Executive Summary */}
        <View style={styles.section}>
          <SectionHeader icon="newspaper-outline" label="Executive Summary" color={colors.primary} colors={colors} />
          <View style={[styles.summaryCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Text style={[styles.summaryText, { color: colors.mutedForeground }]}>{report.executiveSummary}</Text>
          </View>
        </View>

        {/* SWOT Grid */}
        <View style={styles.section}>
          <SectionHeader icon="grid-outline" label="SWOT Analysis" color="#8B5CF6" colors={colors} />
          <SwotPager swot={report.swot} colors={colors} />
        </View>

        {/* Strategic Priorities */}
        {report.strategicPriorities.length > 0 && (
          <View style={styles.section}>
            <SectionHeader icon="flash-outline" label="Strategic Priorities" color="#F59E0B" count={report.strategicPriorities.length} colors={colors} />
            {report.strategicPriorities.map((p, i) => (
              <PriorityCard key={i} item={p} idx={i} colors={colors} />
            ))}
          </View>
        )}

        {/* 90-Day Plan */}
        {report.actionPlan90Days.length > 0 && (
          <View style={styles.section}>
            <SectionHeader icon="calendar-outline" label="90-Day Action Plan" color="#3B82F6" count={report.actionPlan90Days.length} colors={colors} />
            {report.actionPlan90Days.map((phase, i) => (
              <PhaseCard key={i} phase={phase} colors={colors} />
            ))}
          </View>
        )}

        {/* Competitive Matrix */}
        {report.competitiveMatrix && (
          report.competitiveMatrix.competitors.length > 0 ||
          report.competitiveMatrix.targetMoats.length > 0 ||
          report.competitiveMatrix.targetVulnerabilities.length > 0 ||
          report.competitiveMatrix.benchmarkSummary !== ""
        ) && (
          <View style={styles.section}>
            <SectionHeader icon="stats-chart-outline" label="Competitive Matrix" color="#6366F1" count={report.competitiveMatrix.competitors.length} colors={colors} />
            <CompetitiveMatrixSection matrix={report.competitiveMatrix} colors={colors} />
          </View>
        )}

        {/* Major Risks */}
        {report.majorRisks && report.majorRisks.length > 0 && (
          <View style={styles.section}>
            <SectionHeader icon="alert-circle-outline" label="Major Risks" color="#EF4444" count={report.majorRisks.length} colors={colors} />
            {report.majorRisks.map((risk, i) => (
              <RiskCard key={i} risk={risk} colors={colors} />
            ))}
          </View>
        )}

        {/* Sources CTA */}
        <TouchableOpacity
          style={[styles.sourcesCta, { backgroundColor: colors.card, borderColor: colors.border }]}
          onPress={() => router.push("/sources")}
          activeOpacity={0.8}
        >
          <Ionicons name="document-text-outline" size={18} color={colors.mutedForeground} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.sourcesCtaTitle, { color: colors.foreground }]}>Evidence & Sources</Text>
            <Text style={[styles.sourcesCtaSub, { color: colors.mutedForeground }]}>SEC filings, news, financial metrics</Text>
          </View>
          <Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} />
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, backgroundColor: colors.background },
    header: {
      flexDirection: "row",
      alignItems: "center",
      paddingHorizontal: 16,
      paddingVertical: 12,
      borderBottomWidth: 1,
      gap: 10,
    },
    backBtn: { padding: 6 },
    headerCenter: { flex: 1, gap: 4 },
    headerCompany: { fontSize: 16, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
    reportBadge: {
      alignSelf: "flex-start",
      borderWidth: 1,
      borderRadius: 20,
      paddingHorizontal: 8,
      paddingVertical: 2,
    },
    reportBadgeText: { fontSize: 10, fontFamily: "Inter_600SemiBold" },
    sourcesBtn: { padding: 8, borderWidth: 1, borderRadius: 10 },
    scroll: { paddingHorizontal: 20, paddingTop: 20 },
    section: { marginBottom: 28 },
    qualityBanner: {
      flexDirection: "row",
      alignItems: "flex-start",
      gap: 8,
      borderWidth: 1,
      borderRadius: 10,
      padding: 12,
      marginBottom: 20,
    },
    qualityText: { flex: 1, fontSize: 12, color: "#F59E0B", fontFamily: "Inter_400Regular", lineHeight: 17 },
    summaryCard: { borderWidth: 1, borderRadius: 14, padding: 16 },
    summaryText: { fontSize: 14, fontFamily: "Inter_400Regular", lineHeight: 22 },
    sourcesCta: {
      flexDirection: "row",
      alignItems: "center",
      gap: 12,
      borderWidth: 1,
      borderRadius: 14,
      padding: 16,
      marginBottom: 8,
    },
    sourcesCtaTitle: { fontSize: 14, fontWeight: "600" as const, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
    sourcesCtaSub: { fontSize: 12, fontFamily: "Inter_400Regular" },
  });
}
