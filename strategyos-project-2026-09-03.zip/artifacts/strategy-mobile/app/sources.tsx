import React from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from "react-native";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useReport } from "@/context/ReportContext";

export default function SourcesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { report } = useReport();

  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  if (!report) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.card, padding: 24, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ color: colors.mutedForeground, fontFamily: "Inter_400Regular" }}>No sources available</Text>
      </View>
    );
  }

  const { sources } = report;
  const styles = makeStyles(colors);

  return (
    <View style={[styles.root, { backgroundColor: colors.card }]}>
      {/* Drag handle */}
      <View style={styles.handleWrap}>
        <View style={[styles.handle, { backgroundColor: colors.border }]} />
      </View>

      {/* Header */}
      <View style={[styles.header, { borderBottomColor: colors.border }]}>
        <Ionicons name="document-text-outline" size={20} color={colors.primary} />
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>Evidence & Sources</Text>
        <TouchableOpacity onPress={() => router.back()} style={styles.closeBtn} activeOpacity={0.7}>
          <Ionicons name="close" size={20} color={colors.mutedForeground} />
        </TouchableOpacity>
      </View>

      <ScrollView
        contentContainerStyle={[styles.scroll, { paddingBottom: bottomPad + 24 }]}
        showsVerticalScrollIndicator={false}
      >

        {/* Data quality */}
        <View style={[styles.qualityRow, { backgroundColor: colors.background, borderColor: colors.border }]}>
          <Text style={[styles.qualityKey, { color: colors.mutedForeground }]}>Data Quality</Text>
          <View style={[
            styles.qualityBadge,
            {
              backgroundColor: report.dataQuality === "sufficient" ? "#10B981" + "15" : "#F59E0B" + "15",
              borderColor: report.dataQuality === "sufficient" ? "#10B981" + "30" : "#F59E0B" + "30",
            }
          ]}>
            <Text style={[
              styles.qualityBadgeText,
              { color: report.dataQuality === "sufficient" ? "#10B981" : "#F59E0B" }
            ]}>
              {report.dataQuality}
            </Text>
          </View>
        </View>

        {/* SEC Filing */}
        <View style={styles.sectionWrap}>
          <View style={styles.sectionHeader}>
            <Ionicons name="library-outline" size={15} color="#8B5CF6" />
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>SEC Filings</Text>
            <View style={[styles.foundBadge, { backgroundColor: sources.agent1.secFound ? "#10B981" + "15" : colors.muted, borderColor: sources.agent1.secFound ? "#10B981" + "30" : colors.border }]}>
              <Text style={[styles.foundText, { color: sources.agent1.secFound ? "#10B981" : colors.mutedForeground }]}>
                {sources.agent1.secFound ? "Found" : "Not found"}
              </Text>
            </View>
          </View>
          {sources.agent1.secFiling !== "" && sources.agent1.secFiling !== "Not found" && (
            <View style={[styles.dataRow, { backgroundColor: colors.background, borderColor: colors.border }]}>
              <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>Latest filing</Text>
              <Text style={[styles.dataVal, { color: colors.foreground }]}>{sources.agent1.secFiling}</Text>
            </View>
          )}
        </View>

        {/* News */}
        {sources.agent1.newsItems.length > 0 && (
          <View style={styles.sectionWrap}>
            <View style={styles.sectionHeader}>
              <Ionicons name="newspaper-outline" size={15} color="#3B82F6" />
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Recent News</Text>
              <Text style={[styles.countText, { color: colors.mutedForeground }]}>{sources.agent1.newsItems.length}</Text>
            </View>
            {sources.agent1.newsItems.map((item, i) => (
              <View key={i} style={[styles.newsCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
                <Text style={[styles.newsHeadline, { color: colors.foreground }]}>{item.headline}</Text>
                <View style={styles.newsMeta}>
                  <Text style={[styles.newsDate, { color: colors.mutedForeground }]}>{item.date}</Text>
                  <Text style={[styles.newsSource, { color: colors.mutedForeground }]}>{item.source}</Text>
                </View>
              </View>
            ))}
          </View>
        )}

        {/* Sentiment */}
        <View style={styles.sectionWrap}>
          <View style={styles.sectionHeader}>
            <Ionicons name="chatbubbles-outline" size={15} color="#F59E0B" />
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Market Sentiment</Text>
          </View>
          <View style={[styles.dataRow, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>Overall</Text>
            <Text style={[styles.dataVal, { color: colors.foreground }]}>{sources.agent1.dataQuality}</Text>
          </View>
        </View>

        {/* Competitors */}
        {sources.agent1.competitors.length > 0 && (
          <View style={styles.sectionWrap}>
            <View style={styles.sectionHeader}>
              <Ionicons name="git-compare-outline" size={15} color="#EF4444" />
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Competitors</Text>
              <Text style={[styles.countText, { color: colors.mutedForeground }]}>{sources.agent1.competitors.length}</Text>
            </View>
            {sources.agent1.competitors.map((c, i) => (
              <View key={i} style={[styles.compCard, { backgroundColor: colors.background, borderColor: colors.border }]}>
                <Text style={[styles.compName, { color: colors.foreground }]}>{c.name}</Text>
                <Text style={[styles.compPos, { color: colors.mutedForeground }]}>{c.positioning}</Text>
              </View>
            ))}
          </View>
        )}

        {/* Financial metrics */}
        {sources.agent2.metrics.length > 0 && (
          <View style={styles.sectionWrap}>
            <View style={styles.sectionHeader}>
              <Ionicons name="bar-chart-outline" size={15} color="#10B981" />
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Financial Metrics</Text>
              <View style={[styles.foundBadge, { backgroundColor: colors.muted, borderColor: colors.border }]}>
                <Text style={[styles.foundText, { color: colors.mutedForeground }]}>{sources.agent2.companyType}</Text>
              </View>
            </View>
            {sources.agent2.metrics.map((m, i) => (
              <View key={i} style={[styles.dataRow, { backgroundColor: colors.background, borderColor: colors.border }]}>
                <Text style={[styles.dataLabel, { color: colors.mutedForeground }]}>{m.label}</Text>
                <View style={{ flex: 1, alignItems: "flex-end", gap: 2 }}>
                  <Text style={[styles.dataVal, { color: colors.foreground }]}>{m.value}</Text>
                  {m.source !== "" && <Text style={[styles.newsSource, { color: colors.mutedForeground }]}>{m.source}</Text>}
                </View>
              </View>
            ))}
            {sources.agent2.notes !== "" && (
              <View style={[styles.notesBox, { backgroundColor: colors.muted, borderColor: colors.border }]}>
                <Text style={[styles.notesText, { color: colors.mutedForeground }]}>{sources.agent2.notes}</Text>
              </View>
            )}
          </View>
        )}
      </ScrollView>
    </View>
  );
}

function makeStyles(colors: ReturnType<typeof useColors>) {
  return StyleSheet.create({
    root: { flex: 1, borderTopLeftRadius: 20, borderTopRightRadius: 20 },
    handleWrap: { alignItems: "center", paddingTop: 10, paddingBottom: 6 },
    handle: { width: 36, height: 4, borderRadius: 2 },
    header: {
      flexDirection: "row",
      alignItems: "center",
      gap: 10,
      paddingHorizontal: 20,
      paddingVertical: 12,
      borderBottomWidth: 1,
    },
    headerTitle: { flex: 1, fontSize: 16, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
    closeBtn: { padding: 4 },
    scroll: { paddingHorizontal: 20, paddingTop: 16 },
    qualityRow: {
      flexDirection: "row",
      alignItems: "center",
      justifyContent: "space-between",
      borderWidth: 1,
      borderRadius: 10,
      paddingHorizontal: 14,
      paddingVertical: 10,
      marginBottom: 20,
    },
    qualityKey: { fontSize: 12, fontFamily: "Inter_500Medium" },
    qualityBadge: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 10, paddingVertical: 3 },
    qualityBadgeText: { fontSize: 11, fontFamily: "Inter_700Bold" },
    sectionWrap: { marginBottom: 24 },
    sectionHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 10 },
    sectionTitle: { flex: 1, fontSize: 14, fontWeight: "700" as const, fontFamily: "Inter_700Bold" },
    foundBadge: { borderWidth: 1, borderRadius: 20, paddingHorizontal: 9, paddingVertical: 3 },
    foundText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
    countText: { fontSize: 12, fontFamily: "Inter_500Medium" },
    dataRow: {
      flexDirection: "row",
      alignItems: "flex-start",
      borderWidth: 1,
      borderRadius: 10,
      paddingHorizontal: 14,
      paddingVertical: 10,
      marginBottom: 6,
      gap: 10,
    },
    dataLabel: { fontSize: 12, fontFamily: "Inter_500Medium", width: 90, flexShrink: 0 },
    dataVal: { flex: 1, fontSize: 12, fontFamily: "Inter_400Regular", textAlign: "right" as const, lineHeight: 18 },
    newsCard: {
      borderWidth: 1,
      borderRadius: 10,
      padding: 12,
      marginBottom: 6,
    },
    newsHeadline: { fontSize: 13, fontFamily: "Inter_500Medium", lineHeight: 18, marginBottom: 6 },
    newsMeta: { flexDirection: "row", gap: 8 },
    newsDate: { fontSize: 11, fontFamily: "Inter_400Regular" },
    newsSource: { fontSize: 11, fontFamily: "Inter_400Regular" },
    compCard: {
      borderWidth: 1,
      borderRadius: 10,
      padding: 12,
      marginBottom: 6,
    },
    compName: { fontSize: 13, fontFamily: "Inter_600SemiBold", marginBottom: 4 },
    compPos: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
    notesBox: { borderWidth: 1, borderRadius: 10, padding: 12, marginTop: 6 },
    notesText: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
  });
}
