/**
 * Dark navy theme derived from the StrategyOS web app (strategy-app/src/index.css).
 * Palette: Deep Midnight Blue background + Electric Violet primary.
 */

const colors = {
  light: {
    // Legacy aliases
    text: "#EEF0F5",
    tint: "#7D53F8",

    // Core surfaces
    background: "#07091A",
    foreground: "#EEF0F5",

    // Cards / elevated surfaces
    card: "#0C1020",
    cardForeground: "#EEF0F5",

    // Primary action color (Electric Violet — matches web --primary)
    primary: "#7D53F8",
    primaryForeground: "#FFFFFF",

    // Secondary
    secondary: "#1A2032",
    secondaryForeground: "#EEF0F5",

    // Muted
    muted: "#111828",
    mutedForeground: "#8A96B0",

    // Accent
    accent: "#7D53F8",
    accentForeground: "#FFFFFF",

    // Destructive
    destructive: "#EF4343",
    destructiveForeground: "#FFFFFF",

    // Borders and inputs
    border: "#1A2032",
    input: "#1A2032",

    // Semantic colours for SWOT quadrants
    emerald: "#10B981",
    amber: "#F59E0B",
    blue: "#3B82F6",
    red: "#EF4444",
    violet: "#8B5CF6",
  },

  radius: 12,
};

export default colors;
