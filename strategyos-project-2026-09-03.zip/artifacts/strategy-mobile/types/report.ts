// Mirrored from artifacts/strategy-app/src/types/report.ts

export type ConfidenceScore = "high" | "medium" | "low";

export interface SwotItem {
  point: string;
  evidence: string;
  strategic_impact: string;
  confidence_score: ConfidenceScore;
  citation: string;
}

export interface StrategicPriority {
  title: string;
  rationale: string;
  keyAction: string;
  citation: string;
}

export interface RiskItem {
  title: string;
  description: string;
  impact: "High" | "Medium" | "Low";
  mitigation: string;
  citation: string;
  confidence_score: ConfidenceScore;
}

export interface OpportunityItem {
  title: string;
  description: string;
  advantage: string;
  timeframe: string;
  citation: string;
  confidence_score: ConfidenceScore;
}

export interface ActionPhase {
  phase: string;
  focus: string;
  actions: string[];
  milestone: string;
}

export interface CompetitorProfile {
  name: string;
  pricingModel: string;
  marketShareEstimate: string;
  techStackIndicators: string;
  hiringTrends: string;
  keyMoat: string;
  keyVulnerability: string;
  vsTargetCompany: string;
}

export interface CompetitiveMatrix {
  targetMoats: string[];
  targetVulnerabilities: string[];
  benchmarkSummary: string;
  competitors: CompetitorProfile[];
}

// ─── Business Score ───────────────────────────────────────────────────────────

export type ScoreRating = "Excellent" | "Strong" | "Moderate" | "Weak" | "Critical";
export type HealthGrade = "A+" | "A" | "B+" | "B" | "C+" | "C" | "D" | "F";

export interface SubCriterion {
  label: string;
  finding: string;
}

export interface CategoryScore {
  categoryName: string;
  score: number;       // 0-20
  rating: ScoreRating;
  rationale: string;
  subCriteria: SubCriterion[];
}

export interface BusinessScore {
  overallScore: number;        // 0-100
  healthGrade: HealthGrade;
  executiveSummary: string;
  categories: CategoryScore[]; // exactly 5
  quickWins: string[];         // exactly 3
}

export interface MetricItem {
  label: string;
  value: string;
  source: string;
}

export interface ReportSources {
  agent1: {
    secFound: boolean;
    secFiling: string;
    newsItems: Array<{ headline: string; date: string; source: string; url?: string }>;
    sentimentSummary: string;
    competitors: Array<{ name: string; positioning: string }>;
    dataQuality: string;
  };
  agent2: {
    companyType: string;
    metrics: MetricItem[];
    dataAvailability: string;
    notes: string;
  };
}

export interface FullReport {
  companyName: string;
  dataQuality: "sufficient" | "partial" | "insufficient";
  dataNote: string;
  swot: {
    strengths: SwotItem[];
    weaknesses: SwotItem[];
    opportunities: SwotItem[];
    threats: SwotItem[];
  };
  executiveSummary: string;
  strategicPriorities: StrategicPriority[];
  majorRisks: RiskItem[];
  keyOpportunities: OpportunityItem[];
  actionPlan90Days: ActionPhase[];
  competitiveMatrix: CompetitiveMatrix;
  businessScore?: BusinessScore;
  sources: ReportSources;
}

export type SSEEvent =
  | { type: "agent_start"; agent: 1 | 2 | 3; label: string; role: string }
  | { type: "agent_update"; agent: 1 | 2 | 3; detail: string }
  | { type: "agent_complete"; agent: 1 | 2 | 3; summary: Record<string, string> }
  | { type: "report"; data: FullReport }
  | { type: "error"; message: string };
